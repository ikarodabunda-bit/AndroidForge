# SkinLab 7.3 — validação

- Mapeamento de prévias AKR, AKR12, M4, M4A1-S, Karambit e Kukri para seis malhas.
- Mensagem catalogo → painel validada por janela de origem e listas de modelos aceitos.
- Mensagem laboratório → painel validada por janela de origem.
- Feedback separado para visualização local de textura-base ASTC e acabamentos demonstrativos.
- Mini 69% x 74%; bolha 48 dp; menu 46 dp; minSdk 30.

**Pendente:** compilação Android e execução no aparelho. Testes locais no Chromium não equivalem a compilação APK.
