package dev.skinforgex;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;
import org.json.JSONObject;

/** Only Android package discovery and foreground usage events. NOT a process attach. */
public final class GameDetector {
    private GameDetector() {}
    public static final String GAME = "com.axlebolt.standoff2";

    public static boolean hasUsageAccess(Context context) {
        AppOpsManager ops = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public static boolean installed(Context context) {
        try { context.getPackageManager().getPackageInfo(GAME, 0); return true; }
        catch (PackageManager.NameNotFoundException ex) { return false; }
    }

    private static long scanEnd=0,lastCheck=0;
    private static String foregroundPackage="";
    private static boolean known=false;
    private static final long CACHE_MS=3000L;

    /** Look at foreground transitions of ALL apps to avoid a stale 'connected' indicator. */
    public static synchronized boolean inForeground(Context context) {
        if(!hasUsageAccess(context)) {
            scanEnd=0; lastCheck=0; known=false; foregroundPackage="";
            return false;
        }
        long now=System.currentTimeMillis();
        if(now>=lastCheck && now-lastCheck<CACHE_MS) return known && GAME.equals(foregroundPackage);
        UsageStatsManager mgr=(UsageStatsManager)context.getSystemService(Context.USAGE_STATS_SERVICE);
        if(mgr==null)return false;
        boolean cold=scanEnd==0 || now<scanEnd || now-scanEnd>60000L;
        long start=cold?Math.max(0,now-5*60*1000L):Math.max(0,scanEnd-2000L);
        UsageEvents events=mgr.queryEvents(start,now);
        if(events==null)return known && GAME.equals(foregroundPackage);
        if(cold){known=false;foregroundPackage="";}
        UsageEvents.Event event=new UsageEvents.Event();
        while(events.hasNextEvent()) {
            events.getNextEvent(event);
            int t=event.getEventType();
            String pkg=event.getPackageName();
            if(t==UsageEvents.Event.MOVE_TO_FOREGROUND || t==UsageEvents.Event.ACTIVITY_RESUMED) {
                if(pkg!=null && !pkg.isEmpty()) {foregroundPackage=pkg;known=true;}
            } else if(t==UsageEvents.Event.MOVE_TO_BACKGROUND ||
                      t==UsageEvents.Event.ACTIVITY_PAUSED || t==UsageEvents.Event.ACTIVITY_STOPPED) {
                if(GAME.equals(pkg) && GAME.equals(foregroundPackage)) {
                    foregroundPackage="";known=true;
                }
            }
        }
        scanEnd=now;lastCheck=now;
        return known && GAME.equals(foregroundPackage);
    }

    public static String statusJson(Context context) {
        JSONObject data=new JSONObject();
        try {
            boolean permit=hasUsageAccess(context), found=installed(context);
            data.put("permission",permit);
            data.put("installed",found);
            data.put("running",found && permit && inForeground(context));
            data.put("kind","foreground-usage-signal");
        } catch(Exception ignored) {}
        return data.toString();
    }
}
