package dev.skinforgex;

/** Native local visualization state. Never attaches to a game process. */
public final class NativeCore {
    static { System.loadLibrary("skinforge"); }
    private NativeCore() {}
    public static native String applyLocalPreview(int itemId);
    public static native void clearSelections();
    public static native String summary();
}
