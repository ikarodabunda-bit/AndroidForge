package dev.skinforgex;

import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;

/** Keep the JS bridge on bundled local content only. Never navigate to third-party pages. */
public final class AssetOnlyWebViewClient extends WebViewClient {
    private static boolean isLocal(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if ("about".equalsIgnoreCase(scheme)) return "about:blank".equals(uri.toString());
        if (!"file".equalsIgnoreCase(scheme)) return false;
        String path = uri.getPath();
        return (uri.getAuthority() == null || uri.getAuthority().isEmpty())
            && path != null && (path.equals("/android_asset") || path.startsWith("/android_asset/"));
    }
    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return !isLocal(request.getUrl());
    }
    @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return !isLocal(Uri.parse(url));
    }
    @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
        if (!isLocal(Uri.parse(url))) { view.stopLoading(); return; }
        super.onPageStarted(view,url,favicon);
    }
    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        String scheme = request.getUrl().getScheme();
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme))
            return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
        return super.shouldInterceptRequest(view,request);
    }
}
