# Auditoria estática do arquivo Flux @Ace_Crack (1).sh

**Procedimento:** leitura offline do arquivo fornecido, sem executá-lo ou instalar os artefatos internos.

**Tipo de arquivo:** ELF64 PIE, processador AArch64/ARM64, vinculador Android `/system/bin/linker64`, 103.170.048 bytes (~98,4 MiB). A extensão `.sh` é enganosa: não se trata de Shell Script.

**SHA-256 do arquivo recebido:** `f408a335abb115b08d9840633040aabed964959564bcaf05cc6042728d5a8382`

**Bibliotecas dinâmicas declaradas:** `libandroid.so`, `libjnigraphics.so`, `libEGL.so`, `libGLESv1_CM.so`, `libGLESv2.so`, `libGLESv3.so`, `libz.so`, `libdl.so`, `libc.so`, `libm.so`. Compatível com componentes de interface gráfica e renderização nativa.

**Recurso interno encontrado:** um ZIP/APK pequeno embutido, com `AndroidManifest.xml`, `classes.dex`, certificados e recursos. As strings indicam um auxiliar `Flux Overlay Helper` com pacote `com.flux.overlay.helper`, classe/provedor `FluxOverlayHost`/`com.flux.overlay.helper.provider` e chamadas de `SurfaceControl`.

**Permissões declaradas no manifesto binário do auxiliar:** `android.permission.SYSTEM_ALERT_WINDOW` e `android.permission.WRITE_SECURE_SETTINGS`. A primeira pode ser concedida pelo usuário para sobreposição; a segunda é privilegiada e não é normalmente concedida a um aplicativo instalado de forma comum.

**Outras strings observadas:** `applyTrustedOverlay`, `overlayRootSurfaceControl`, `setOverlayVisibleForCapture`, `Authorization verified`, e comando para abrir um link Telegram. Isso não prova que as funções operam no dispositivo, nem que o binário é seguro ou malicioso.

**Conclusão:** é possível fazer sobreposição gráfica Android sem root, como no SkinLab, mas não há neste artefato uma API pública documentada do Standoff 2 que permita mudar as skins da arma. Decompilar um binário proprietário não fornece automaticamente seu código-fonte original nem torna operações privilegiadas compatíveis com aplicativos comuns. Não foi verificado que o Flux original aplique skins em partidas.

**Recomendação de segurança:** não executar binários desconhecidos ou instalar seu auxiliar embutido sem auditoria aprofundada. O projeto SkinLab 8.0 usa somente código do SkinLab anterior e APIs Android públicas.
