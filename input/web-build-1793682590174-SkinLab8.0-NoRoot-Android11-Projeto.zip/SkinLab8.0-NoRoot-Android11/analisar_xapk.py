#!/usr/bin/env python3
"""Inventário somente-leitura para XAPK/ZIP/APK, sem extrair nem alterar conteúdo.

Uso no Android Termux: python analisar_xapk.py /sdcard/Download/Standoff2.xapk
Saída: arquivo .inventario.txt no diretório corrente.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import sys
import zipfile

EXTS = ('.apk','.obb','.unity3d','.assets','.bundle','.ress','.resource','.resS','.dll','.dat')
NAMES = ('libil2cpp.so','libunity.so','global-metadata.dat','main.', 'patch.', 'AndroidManifest.xml')


def friendly(size):
    return f'{size / (1024 * 1024):,.2f} MiB'


def scan(filepath):
    source = Path(filepath).expanduser()
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f'Arquivo não encontrado: {source}')
    print(f'Analisando o índice ZIP de {source.name} (não extrai os dados).')
    with zipfile.ZipFile(source, 'r') as zf:
        entries = zf.infolist()
        lines = [
            'Inventário local do XAPK / APK — somente leitura',
            f'Gerado: {datetime.datetime.now(datetime.timezone.utc).isoformat()}',
            f'Arquivo: {source.name}',
            f'Tamanho físico: {source.stat().st_size} bytes ({friendly(source.stat().st_size)})',
            f'Arquivos dentro: {sum(not x.is_dir() for x in entries)}',
            f'Tamanho interno descompactado: {friendly(sum(x.file_size for x in entries))}',
            '', 'ARQUIVOS MAIS IMPORTANTES (nome, comprimido, descompactado):',
        ]
        relevant=[]
        for e in entries:
            n=e.filename
            basename=n.rsplit('/',1)[-1].lower()
            if n.lower().endswith(tuple(v.lower() for v in EXTS)) or any(
                basename.startswith(v.lower()) if v.endswith('.') else basename==v.lower()
                for v in NAMES):
                relevant.append(e)
        relevant.sort(key=lambda x: x.file_size, reverse=True)
        for e in relevant[:150]:
            lines.append(f'{e.filename}\tcompactado={friendly(e.compress_size)}\toriginal={friendly(e.file_size)}')
        if len(relevant)>150:
            lines.append(f'... mais {len(relevant)-150} arquivos relevantes omitidos')
        for name in ('manifest.json','info.json'):
            match=next((x for x in entries if x.filename==name),None)
            if match and match.file_size<2*1024*1024:
                lines.extend(['',f'{name} (conteúdo):'])
                raw=zf.read(match).decode('utf-8','replace')
                try: lines.append(json.dumps(json.loads(raw),ensure_ascii=False,indent=2)[:10000])
                except json.JSONDecodeError: lines.append(raw[:10000])
    out=source.with_suffix('.inventario.txt')
    out.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Relatório criado: {out} ({out.stat().st_size} bytes)')
    print('Envie só o relatório .inventario.txt para análise.')
    return out


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('arquivo',help='Caminho para o arquivo XAPK / APK')
    options=parser.parse_args()
    try:scan(options.arquivo)
    except (FileNotFoundError,zipfile.BadZipFile,PermissionError) as error:
        print(f'Erro: {error}',file=sys.stderr)
        sys.exit(1)
