# Teste Android 11+ — SkinLab 7.3

1. Instale o novo `app-debug.apk` da compilação de GitHub Actions.
2. Conceda sobreposição e, se desejar detecção, acesso de uso.
3. Abra o painel sobre o Standoff 2 e confirme o tamanho Mini.
4. No catálogo original, procure `AKR_Scylla_Preview`; toque em Ver modelo 3D.
5. Confirme que o modelo do AKM aparece, mas com a **textura-base AKR_D**, não com a skin Scylla.
6. Se o indicador registrar erro ASTC, envie o diagnóstico do aparelho.
7. Selecione acabamento Gold no LAB e confira a confirmação “demonstrativo”.

Não altere nem substitua os arquivos originais do jogo. Se atualizar um APK já instalado por assinatura diferente, será necessário instalar o novo aplicativo após backup de preferências.
