# SkinLab 8.0 NoRoot — Android 11+

Projeto de aplicativo Android independente, derivado do SkinLab 7.3, com painel flutuante sobre jogos, detecção de execução por UsageStats (quando autorizada), catálogo de prévias e laboratório 3D. O código é fonte aberta neste ZIP e **não incorpora nem executa o binário Flux** recebido.

## O que funciona sem root

- Janela Android `TYPE_APPLICATION_OVERLAY`, com permissão concedida pelo usuário.
- Minimizar/restaurar, arrastar, ocultar e restaurar pela notificação.
- Abrir o Standoff 2 instalado; detectar atividade em primeiro plano (quando acesso de uso está autorizado).
- Selecionar miniaturas e salvar favoritos/configurações **no SkinLab**.
- Inspecionar modelos e texturas no renderizador independente.
- Android 11/API 30 mínimo; API 35 como alvo; ARM64.

## O que NÃO faz

- Não aplica skins ao renderizador do Standoff 2 e não modifica inventário/partidas.
- Não tem hooks, acesso a `/proc/<pid>/mem`, alteração do APK do jogo, acesso privilegiado `WRITE_SECURE_SETTINGS`, nem APIs ocultas de `SurfaceControl`.
- Não executa, embute ou verifica licenças do binário `Flux @Ace_Crack (1).sh`.

## Compilar

Importe o diretório no Android Studio com SDK 35, JDK 17 e NDK 27, depois execute `assembleDebug`. Também existe o fluxo **Actions → Build SkinLab 8.0 NoRoot APK** no GitHub Actions; o APK aparecerá como artifact da execução bem-sucedida. O APK não foi compilado neste ambiente (sem Android SDK).

Para instalar, desinstale o aplicativo de mesmo `applicationId` caso tenha uma assinatura diferente. Este projeto usa `dev.skinlab.noroot`, podendo coexistir com o SkinLab anterior.

## Sobre o arquivo Flux

Ver `AUDITORIA-FLUX.md` para os resultados da análise estática, incluindo as permissões não disponíveis normalmente a apps Android sem root.
