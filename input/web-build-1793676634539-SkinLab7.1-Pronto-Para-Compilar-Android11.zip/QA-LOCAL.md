# SkinLab 7.1 — verificações executadas

- `python3 tools/verify.py`: PASS. Versão 7.1, API 30+, Android target 35, manifesto, arquivos HTML, bridge, detector e workflow.
- `node --check` nos scripts embutidos em `index.html`, `catalogo.html` e `lab3d.html`: PASS.
- `clang++ -std=c++17 -fsyntax-only` para `native-lib.cpp` usando headers JNI da máquina: PASS.
- Playwright/Chromium: PASS na página principal para coleção 268 itens, 20 conceitos locais, seleção de Karambit, loadout, alternância modo compacto, painel de diagnósticos e navegação LAB 3D. Nenhum erro JavaScript na página pai.
- Integridade do ZIP final: validada após geração.

**Não validado:** build Gradle com Android SDK, execução real Android, fluxo de sobreposição, detecção por eventos de uso no celular, WebGL/ASTC nos iframes ou qualquer alteração de skins no Standoff 2.
