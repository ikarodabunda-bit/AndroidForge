#!/usr/bin/env python3
"""Static checks; not an APK compilation or on-device test."""
from pathlib import Path
import re, xml.etree.ElementTree as ET, json
root=Path(__file__).resolve().parents[1]
assets=root/'app/src/main/assets'; java=root/'app/src/main/java/dev/skinforgex'
build=(root/'app/build.gradle').read_text()
assert re.search(r'\bminSdk 30\b',build)
assert re.search(r'\btargetSdk 35\b',build)
assert re.search(r"versionName '7\.1\.0'",build)
assert "arm64-v8a" in build
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert manifest.find('application').attrib[ns+'label'].startswith('SkinLab 7.1')
assert manifest.find('application/service').attrib[ns+'foregroundServiceType']=='specialUse'
for file in ['index.html','catalogo.html','lab3d.html']:
    path=assets/file
    assert path.is_file() and path.stat().st_size>1500, file
html=(assets/'index.html').read_text()
assert '268 RECURSOS' in html
assert 'data-nav="original"' in html
assert 'diagnosticBtn' in html and 'function exportDiagnostics()' in html
assert 'loadUrl("file:///android_asset/index.html")' in (java/'MainActivity.java').read_text()
assert 'AssetOnlyWebViewClient' in (java/'OverlayService.java').read_text()
assert 'getDiagnostics()' in (java/'StudioBridge.java').read_text()
assert 'shareDiagnostics(String report)' in (java/'StudioBridge.java').read_text()
assert 'GAME.equals(foregroundPackage)' in (java/'GameDetector.java').read_text()
assert (root/'app/src/main/cpp/native-lib.cpp').is_file()
assert 'workflow_dispatch' in (root/'.github/workflows/build-android.yml').read_text()
print('PASS: SkinLab 7.1 | SDK 30+, Android assets, JNI, overlay, diagnostics and CI')
