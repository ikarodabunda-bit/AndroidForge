# SkinLab 7.1 — Android 11+ | compilação automatizada

Este pacote é o **projeto-fonte completo**, não um APK já compilado. Ele usa Android 11 como mínimo (`minSdk 30`) e Android 15 como alvo (`targetSdk 35`).

## O que está pronto

- Catálogo visual de 268 referências de recursos Unity extraídos de amostras enviadas pelo usuário.
- Laboratório 3D com seis modelos originais e troca de acabamento **apenas no visualizador independente**.
- Painel flutuante Android: abrir jogo + painel, bolha arrastável, ocultação e restauração pela notificação.
- Detecção de jogo: por evento de primeiro plano do Android, **não** por conexão ao processo.
- Novo **Exportar diagnóstico** em Compatibilidade: reúne versão Android/WebView, permissão de sobreposição, detecção, WebGL e ASTC. Não coleta IDs de conta, localização ou dados pessoais.
- Verificação de eventos de todos os apps para evitar mostrar jogo ativo quando outro aplicativo recebeu o foco.
- GitHub Actions manual para construir `app-debug.apk` e gerar `BUILD-RESULTADOS.txt` com SHA-256 e requisitos de SDK.

## Gerar APK usando GitHub Actions (sem PC)

1. Descompacte este ZIP. Crie um repositório GitHub **privado**, com arquivos da raiz do projeto (`app`, `.github`, `tools`, `settings.gradle`, etc.). O ZIP sozinho não executa o workflow.
2. Abra a aba **Actions** do repositório e selecione **Build SkinLab 7.1 APK**.
3. Selecione **Run workflow**. Se o build ficar verde, abra **Artifacts → SkinLab-7.1-Android11-APK**.
4. Baixe o artefato e abra o `app-debug.apk` dentro dele no celular. Instale, habilite **Exibir sobre outros apps** e teste o painel com o Standoff 2.
5. No SkinLab, abra **Compatibilidade → EXPORTAR DIAGNÓSTICO** e compartilhe o JSON se algum recurso falhar.

## Compilar no Android Studio

- JDK 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1 e Gradle 8.10.2.
- Abra a pasta do projeto e compile `assembleDebug`.
- O pacote não contém `gradlew` nem o Android SDK. O workflow instala o Gradle no runner.

## Garantias e limites

Foram efetuadas validações estáticas e de sintaxe no ambiente disponível. **Nenhum APK foi compilado ou instalado neste ambiente**. É necessário um Android SDK local ou o workflow do GitHub.

**SkinLab não altera arquivos, memória, inventário ou skins efetivamente equipadas no Standoff 2.** O Android Overlay mostra o painel sobre o jogo e o laboratório modifica somente modelos independentes. Os testes de integração real com o jogo permanecem não implementados.
