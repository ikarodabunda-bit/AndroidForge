package dev.skinforgex;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;

/** User-controlled, movable, resizable overlay window; no game process access. */
public class OverlayService extends Service {
    private WindowManager manager;
    private WindowManager.LayoutParams params;
    private WebView web;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private static final String CHANNEL="skinlab5_overlay";
    public static final String ACTION_HIDE="dev.skinforgex.action.HIDE";
    public static final String ACTION_SHOW="dev.skinforgex.action.SHOW";
    private boolean tiny=false,compact=false,keyboardEnabled=false,hidden=false;
    private final AtomicInteger dragDx=new AtomicInteger();
    private final AtomicInteger dragDy=new AtomicInteger();
    private final AtomicBoolean dragPosted=new AtomicBoolean();
    private final Runnable dragFlush=new Runnable() {
        @Override public void run() {
            int dx=dragDx.getAndSet(0),dy=dragDy.getAndSet(0);
            if(web!=null && params!=null && (dx!=0 || dy!=0)) {
                params.x=Math.max(0,Math.min(Math.max(0,screenWidth()-params.width),params.x+dp(dx)));
                params.y=Math.max(0,Math.min(Math.max(0,screenHeight()-params.height),params.y+dp(dy)));
                refresh();
            }
            dragPosted.set(false);
            if((dragDx.get()!=0 || dragDy.get()!=0) && dragPosted.compareAndSet(false,true))
                ui.postDelayed(this,16L);
        }
    };
    private void setWebPaused(boolean paused) {
        if(web==null)return;
        if(paused) {
            web.evaluateJavascript("window.skinlabPause && window.skinlabPause(true)",null);
            // A bolha ainda precisa receber eventos de toque: não pausar o WebView minimizado.
            if(hidden) web.onPause();
        } else {
            web.onResume();
            web.evaluateJavascript("window.skinlabPause && window.skinlabPause(false)",null);
        }
    }


    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        String action=intent==null?null:intent.getAction();
        if(ACTION_HIDE.equals(action)) hidden=true;
        else if(ACTION_SHOW.equals(action)) hidden=false;
        makeForeground();
        if(!Settings.canDrawOverlays(this)) {stopSelf();return START_NOT_STICKY;}
        ui.post(()->{
            if(web==null) createOverlay();
            if(web!=null) {
                web.setVisibility(hidden ? View.GONE : View.VISIBLE);
                setWebPaused(hidden);
            }
        });
        return START_STICKY;
    }
    private void makeForeground() {
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"SkinLab · painel flutuante",NotificationManager.IMPORTANCE_LOW));
        Intent activity=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,activity,
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent switchIntent=new Intent(this, OverlayService.class);
        switchIntent.setAction(hidden ? ACTION_SHOW : ACTION_HIDE);
        PendingIntent action=PendingIntent.getService(this,hidden?2:1,switchIntent,
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification note=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle(hidden?"SkinLab 7.1 · oculto":"SkinLab 7.1 · sobreposição ativa")
            .setContentText(hidden?"Jogo recebe todos os toques; toque em Mostrar para voltar":"O painel não altera o inventário do Standoff 2")
            .setContentIntent(pi)
            .addAction(new Notification.Action.Builder(
                android.R.drawable.ic_menu_view,hidden?"Mostrar painel":"Ocultar painel",action).build())
            .setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=34)
            startForeground(1500,note,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1500,note);
    }
    private int dp(int amount) {return Math.round(amount*getResources().getDisplayMetrics().density);}
    private int screenWidth(){return getResources().getDisplayMetrics().widthPixels;}
    private int screenHeight(){return getResources().getDisplayMetrics().heightPixels;}
    private int getPanelWidth() {
        int w=screenWidth(), padding=dp(12);
        int max=dp(compact?760:1200);
        return Math.max(dp(200),Math.min(Math.min(w-padding*2,max),Math.round(w*.94f)));
    }
    private int getPanelHeight() {
        int h=screenHeight();
        int max=dp(compact?490:810);
        return Math.max(dp(200),Math.min(Math.min(h-dp(12),max),Math.round(h*.9f)));
    }
    private void createOverlay() {
        if(web!=null)return;
        manager=(WindowManager)getSystemService(WINDOW_SERVICE);
        params=new WindowManager.LayoutParams(getPanelWidth(),getPanelHeight(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_TOUCH_MODAL: touches outside this small panel reach the game.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        params.x=Math.max(0,(screenWidth()-params.width)/2);
        params.y=Math.max(0,(screenHeight()-params.height)/2);
        web=new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new AssetOnlyWebViewClient());
        web.addJavascriptInterface(new StudioBridge(this,this),"Android");
        manager.addView(web,params);
        web.setVisibility(hidden ? View.GONE : View.VISIBLE);
        web.loadUrl("file:///android_asset/index.html?overlay=1");
    }
    public void hideForGame() {
        ui.post(()->{
            hidden=true;
            keyboardEnabled=false;
            updateFocusFlags();
            if(web!=null){web.clearFocus();setWebPaused(true);web.setVisibility(View.GONE);}
            makeForeground();
        });
    }
    public void showForGame() {
        ui.post(()->{
            hidden=false;
            if(web==null)createOverlay();
            if(web!=null){web.setVisibility(View.VISIBLE);setWebPaused(false);}
            makeForeground();
        });
    }
    public void moveBy(int dx,int dy) {
        // WindowManager layout coalesced at ~60 updates per second.
        dragDx.addAndGet(dx);
        dragDy.addAndGet(dy);
        if(dragPosted.compareAndSet(false,true)) ui.postDelayed(dragFlush,16L);
    }
    public void minimize(boolean minimized) {
        ui.post(()->{
            tiny=minimized;
            if(web==null)return;
            params.width=tiny?dp(68):getPanelWidth();
            params.height=tiny?dp(68):getPanelHeight();
            params.x=Math.max(0,Math.min(Math.max(0,screenWidth()-params.width),params.x));
            params.y=Math.max(0,Math.min(Math.max(0,screenHeight()-params.height),params.y));
            // In normal mode the game keeps keyboard focus. Focus is opted in only
            // when the user explicitly selects the search field.
            if(tiny) keyboardEnabled=false;
            updateFocusFlags();
            setWebPaused(tiny || hidden);
            refresh();
        });
    }
    /** Search mode is temporary; normal floating panels never request focus. */
    public void setKeyboardEnabled(boolean enabled) {
        ui.post(()->{
            if(web==null || params==null)return;
            keyboardEnabled=enabled && !tiny;
            updateFocusFlags();
            refresh();
            android.view.inputmethod.InputMethodManager imm=
                (android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null){
                if(keyboardEnabled){
                    web.setFocusableInTouchMode(true);
                    web.requestFocus();
                    web.postDelayed(()->imm.showSoftInput(web,
                        android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT),120);
                } else {
                    imm.hideSoftInputFromWindow(web.getWindowToken(),0);
                    web.clearFocus();
                }
            }
        });
    }
    private void updateFocusFlags() {
        if(params==null)return;
        params.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
            ((!keyboardEnabled || tiny)?WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE:0);
    }
    public void setSizeMode(boolean isCompact) {
        ui.post(()->{compact=isCompact;rescale();});
    }
    private void rescale() {
        if(web==null||params==null)return;
        params.width=tiny?dp(68):getPanelWidth();
        params.height=tiny?dp(68):getPanelHeight();
        params.x=Math.max(0,Math.min(Math.max(0,screenWidth()-params.width),params.x));
        params.y=Math.max(0,Math.min(Math.max(0,screenHeight()-params.height),params.y));
        refresh();
    }
    private void refresh() {
        try{manager.updateViewLayout(web,params);}catch(Exception ignored){}
    }
    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        ui.post(this::rescale);
    }
    @Override public void onDestroy() {
        ui.removeCallbacks(dragFlush);
        if(web!=null){try{manager.removeView(web);}catch(Exception ignored){}web.destroy();web=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
