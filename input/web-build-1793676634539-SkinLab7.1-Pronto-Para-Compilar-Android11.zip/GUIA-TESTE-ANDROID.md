# Guia rápido — validação em Android 11+

1. Instale o `app-debug.apk` gerado pelo GitHub Actions.
2. Abra SkinLab e conceda a permissão **Exibir sobre outros apps**.
3. Escolha **JOGO + PAINEL** e confirme a abertura do Standoff 2.
4. Minimize o painel para a bolha e restaure. Abra **Modo invisível** e use a notificação para voltar.
5. Abra **Compatibilidade** e autorize o acesso de uso, se quiser indicador de jogo em primeiro plano.
6. Toque em **Exportar diagnóstico**. Compartilhe o relatório se ocorrer qualquer falha. O relatório não captura contas nem informações identificadoras.
7. No **LAB 3D**, teste AKR e Karambit em modos com e sem ASTC (se disponível).

Quando relatar falha, inclua: operação que falhou, mensagem mostrada, versão Android e relatório exportado.
