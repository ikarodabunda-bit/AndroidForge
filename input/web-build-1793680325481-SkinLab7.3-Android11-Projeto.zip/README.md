# SkinLab 7.3 — Bridge do catálogo para o laboratório 3D

**Android mínimo: 11 (API 30)** · ARM64 · C++17 · painel flutuante Mini.

## Novo no 7.3
- No **Acervo original**, a inspeção de itens das famílias AKR, AKR12, M4, M4A1-S, Karambit e Kukri oferece **VER MODELO 3D (TEXTURA-BASE)**.
- O botão abre o modelo correspondente diretamente no **LAB 3D**; não é preciso procurar a arma novamente.
- O laboratório tenta usar a **textura-base original ASTC** da arma. Ele relata se foi renderizada ou se a GPU/WebView recusou o formato.
- O painel recebe essa confirmação e diferencia claramente textura-base e acabamento demonstrativo.
- Preserva os modos de janela Mini/Compacto/Amplo, o painel de ícones, os 268 itens, a bolha de 48 dp e a detecção de primeiro plano.

## Como testar
1. Abra **Acervo original** e busque `AKR_Scylla`, `M4` ou `Kukri`.
2. Selecione a prévia e toque em **VER MODELO 3D (TEXTURA-BASE)**.
3. Veja o aviso acima do visualizador e a confirmação/erro de ASTC.
4. Troque entre `Base original ASTC` e acabamento demonstrativo. A seleção afeta **somente o renderizador do SkinLab**.
5. Teste o Mini sobre o jogo, ocultar, minimizar e restaurar.

## Compilar
Use Android Studio (Java 17, SDK 35, NDK 27.2) ou GitHub Actions > Build SkinLab 7.3 APK > Run workflow. O artefato contém `app-debug.apk`.

## Limite técnico
**Este projeto não altera a aparência da arma renderizada pelo Standoff 2 nem concede acesso a skins não possuídas.** Nem o catálogo nem o LAB 3D possuem conexão ao inventário ou ao renderizador do jogo. Esta versão cria uma ponte verificável entre os recursos 2D e a malha 3D no visualizador independente.
