# SkinLab 5.1 — correção para AndroidForge

## Falha anterior
AndroidForge scripts/self_heal.py interpretava incorretamente a sintaxe Groovy `namespace 'com.skinlab.cppoverlay'` e adicionava `package=...` ao AndroidManifest. O Android Gradle Plugin 8.7 recusava esse atributo.

## Correção
`app/build.gradle` agora usa `namespace = 'com.skinlab.cppoverlay'`, reconhecida pelo detector do AndroidForge; o Manifest permanece sem atributo `package`.

## Compilar pelo AndroidForge
1. Envie ESTE ZIP no AndroidForge.
2. Escolha variante `debug` (assembleDebug).
3. Baixe o APK gerado.
4. Instale-o no Android e autorize a sobreposição se solicitada.

O APK exibe um catálogo/overlay independente. Ele **não altera skins do CounterFlame**, nem contorna o anticheat.
