# ChargeSkin Cyber Purple v4.0 — AndroidForge

## Build

Upload this ZIP by itself to AndroidForge. The ZIP root contains `settings.gradle.kts`, `build.gradle.kts` and `app/build.gradle.kts`.

Recommended AndroidForge variant: **debug** for first testing.

Toolchain pinned in the project:
- Android Gradle Plugin 8.7.3
- Kotlin Gradle Plugin 2.0.21
- Java source/target 17
- Kotlin JVM target 17
- compileSdk 34 / minSdk 23 / targetSdk 32

The matching Java/Kotlin target is intentional: the previous AndroidForge log showed Java 8 vs Kotlin 17, which caused `Inconsistent JVM-target compatibility`.

## Install and try

1. Build a debug APK in AndroidForge.
2. Install the APK on the Android device.
3. Generate a test key in KEY NOUK v3.0.
4. Paste it into ChargeSkin and validate.
5. Grant the Android "Display over other apps" permission.
6. Tap the circular crown bubble to open the catalog. Drag it to move it; long-press to close the overlay service.

## Scope and safety

The 45-item catalog and its thumbnails are a visual reference using the images supplied for this project. This app does not inject code, modify game memory, replace game assets, or apply skins in Counter Flame. Actual in-game integration needs an officially supported mechanism from the game developer.

The offline signature is suitable for local testing only. The signing private key is embedded in the separate generator app, so it is extractable by a technically capable person. Do not distribute this build as a secure paid-license system. A server-side signer or private administrative signing tool is needed for production.
