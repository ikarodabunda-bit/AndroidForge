# SkinLab 5.1 — Fundo corrigido

O fundo da versão 5.0 era somente um degradê escuro. Agora a prévia apresenta o cenário do próprio jogo com desfoque, vinheta e luzes vermelhas/azuis.

## Teste no celular

1. Extraia o novo ZIP em Downloads.
2. Abra `Preview_Standalone.html` no Chrome, ou execute `bash preview_termux.sh` dentro da pasta do projeto.
3. Confira se há cenário desfocado atrás do painel e se a lista de skins permanece legível.
4. Em overlay Android, o fundo fora da janela não deve congelar a imagem do jogo.

O pacote contém código-fonte, não um APK instalável. O comando Termux é `bash preview_termux.sh`.
