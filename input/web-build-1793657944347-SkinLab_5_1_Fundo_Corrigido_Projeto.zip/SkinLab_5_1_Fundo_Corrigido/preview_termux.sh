#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")/app/src/main/assets/panel"
echo 'SkinLab 5.0: abra http://127.0.0.1:8989/ no navegador'
python -m http.server 8989 --bind 127.0.0.1
