#include "skin_core.h"
#include <mutex>
#include <sstream>
namespace skinlab {
namespace {
std::mutex stateMutex;
std::string active="ak-default";
const std::vector<Skin> skins={
  {"ak-default","AK-47","Padrão","Armas"},
  {"ak-vulcan","AK-47","Vulcan","Armas"},
  {"ak-gold","AK-47","Gold Arabesque","Armas"},
  {"ak-neon","AK-47","Neon Revolution","Armas"},
  {"ak-aquamarine","AK-47","Aquamarine","Armas"},
  {"ak-fireserpent","AK-47","Fire Serpent","Armas"},
  {"ak-wild","AK-47","Wild Lotus","Armas"},
  {"ak-fuel","AK-47","Fuel Injector","Armas"},
  {"ak-empress","AK-47","Empress","Armas"},
  {"m4a4-how1","M4A4","Howl","Armas"},
  {"m4a4-neo","M4A4","Neo-Noir","Armas"},
  {"m4s-print","M4A1-S","Printstream","Armas"},
  {"m4s-hotrod","M4A1-S","Hot Rod","Armas"},
  {"awp-dragon","AWP","Dragon Lore","Armas"},
  {"awp-gungnir","AWP","Gungnir","Armas"},
  {"deagle-print","Desert Eagle","Printstream","Armas"},
  {"deagle-blaze","Desert Eagle","Blaze","Armas"},
  {"glove-vice","Luvas","Vice","Luvas"},
  {"glove-pandora","Luvas","Pandora Box","Luvas"},
  {"knife-butterfly","Butterfly Knife","Emerald","Facas"},
};
std::string escape(const std::string& val) {
 std::ostringstream o;
 for(char c:val) { if(c=='\\')o<<"\\\\";else if(c=='"')o<<"\\\"";else if(c=='\n')o<<"\\n";else o<<c;}
 return o.str();
}
}
const std::vector<Skin>& catalog(){return skins;}
bool isValid(const std::string& id){for(const auto& item:skins)if(item.id==id)return true;return false;}
bool select(const std::string& id){if(!isValid(id))return false;std::lock_guard<std::mutex> lock(stateMutex);active=id;return true;}
std::string selected(){std::lock_guard<std::mutex> lock(stateMutex);return active;}
void restore(){std::lock_guard<std::mutex> lock(stateMutex);active="ak-default";}
std::string catalogJson(){std::ostringstream out;out<<'[';for(size_t i=0;i<skins.size();++i){if(i)out<<',';const auto& v=skins[i];out<<"{\"id\":\""<<escape(v.id)<<"\",\"weapon\":\""<<escape(v.weapon)<<"\",\"skin\":\""<<escape(v.title)<<"\",\"group\":\""<<escape(v.category)<<"\"}";}out<<']';return out.str();}
}
