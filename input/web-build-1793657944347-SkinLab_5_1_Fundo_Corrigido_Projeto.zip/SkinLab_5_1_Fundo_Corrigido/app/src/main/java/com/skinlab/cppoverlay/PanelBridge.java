package com.skinlab.cppoverlay;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

/** API restrita para a interface local em file:///android_asset/panel/. */
public final class PanelBridge {
    private final SkinStore store;
    private final Runnable onMinimize;
    private final Handler main = new Handler(Looper.getMainLooper());

    public PanelBridge(SkinStore store, Runnable onMinimize) {
        this.store = store;
        this.onMinimize = onMinimize;
    }

    @JavascriptInterface public String selected() {
        try { return store == null ? "ak-default" : store.selection(); }
        catch (Throwable ignored) { return "ak-default"; }
    }

    @JavascriptInterface public boolean apply(String id) {
        try { return store != null && store.apply(id); }
        catch (Throwable ignored) { return false; }
    }

    @JavascriptInterface public void restore() {
        try { if (store != null) store.restore(); }
        catch (Throwable ignored) { /* não finalizar o painel */ }
    }

    @JavascriptInterface public void minimize() {
        if (onMinimize != null) main.post(onMinimize);
    }
}
