package com.skinlab.cppoverlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    private WebView preview;
    private SkinStore store;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // A Activity sempre mostra a interface antes de tentar carregar o módulo nativo.
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xff080b13);
        layout.setPadding(dp(9), dp(9), dp(9), dp(9));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button activate = new Button(this);
        activate.setText("ATIVAR OVERLAY");
        activate.setAllCaps(false);
        actions.addView(activate, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button stop = new Button(this);
        stop.setText("DESATIVAR");
        stop.setAllCaps(false);
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(48), 1));
        layout.addView(actions);
        status = new TextView(this);
        status.setTextColor(0xffb7c3d6);
        status.setTextSize(12);
        status.setPadding(dp(8), dp(4), dp(8), dp(8));
        status.setText("Painel pronto. Solicite a sobreposição manualmente.");
        layout.addView(status);
        preview = new WebView(this);
        preview.setBackgroundColor(Color.TRANSPARENT);
        preview.getSettings().setJavaScriptEnabled(true);
        preview.getSettings().setDomStorageEnabled(true);
        preview.getSettings().setAllowFileAccess(true);
        preview.getSettings().setAllowFileAccessFromFileURLs(false);
        preview.getSettings().setAllowUniversalAccessFromFileURLs(false);
        preview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        preview.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/panel/");
            }
        });
        layout.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(layout);
        try {
            store = new SkinStore(this);
            status.setText("C++ ativo · " + store.items().length() + " skins · sem alteração do jogo");
        } catch (Throwable e) {
            status.setText("Modo prévia disponível · C++ indisponível: " + e.getClass().getSimpleName());
        }
        preview.addJavascriptInterface(new PanelBridge(store, null), "SkinLabAndroid");
        preview.loadUrl("file:///android_asset/panel/index.html");
        activate.setOnClickListener(v -> activateOverlay());
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            status.setText("Sobreposição desativada.");
        });
    }

    private void activateOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            status.setText("Autorize ‘Exibir sobre outros apps’ e volte ao SkinLab.");
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try { startActivity(intent); }
            catch (Exception e) { Toast.makeText(this, "Abra o acesso especial para sobreposição nas Configurações", Toast.LENGTH_LONG).show(); }
            return;
        }
        try {
            Intent intent = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            status.setText("Menu solicitado · Abra o CounterFlame e procure a bolha SL.");
        } catch (Throwable t) {
            status.setText("Não foi possível iniciar o overlay: " + t.getClass().getSimpleName());
        }
    }

    private int dp(float x) { return (int) (getResources().getDisplayMetrics().density * x + .5f); }
    @Override protected void onDestroy() {
        if (preview != null) { preview.removeJavascriptInterface("SkinLabAndroid"); preview.destroy(); preview = null; }
        super.onDestroy();
    }
}
