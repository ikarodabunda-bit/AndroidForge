package com.skinlab.cppoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class OverlayService extends Service {
    private static final String TAG = "SkinLab";
    private static final String CHANNEL = "skinlab5_overlay";
    private static final String ACTION_STOP = "com.skinlab.cppoverlay.STOP";
    private WindowManager manager;
    private View bubble;
    private WebView panel;
    private SkinStore store;
    private WindowManager.LayoutParams bubbleParams;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        try {
            manager = (WindowManager) getSystemService(WINDOW_SERVICE);
            store = new SkinStore(this);
        } catch (Throwable e) {
            Log.e(TAG, "Núcleo indisponível", e);
            stopSelf();
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (store == null || (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))) {
            stopSelf(); return START_NOT_STICKY;
        }
        try {
            startForeground(5050, notification());
            if (bubble == null && panel == null) showBubble();
        } catch (Throwable t) {
            Log.e(TAG, "Falha ao iniciar overlay", t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Notification notification() {
        NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            n.createNotificationChannel(new NotificationChannel(CHANNEL, "SkinLab 5.0", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent action = PendingIntent.getService(this, 5050, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentTitle("SkinLab 5.0 · Menu flutuante")
                .setContentText("Overlay independente: não modifica o jogo")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar overlay", action)
                .build();
    }

    private WindowManager.LayoutParams layout(int width, int height, boolean focusable) {
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        if (!focusable) flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width, height, type, flags, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        return p;
    }

    private void showBubble() {
        removePanel();
        if (bubble != null) return;
        TextView b = new TextView(this);
        b.setText("◈  SL");
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(0xffa32442);
        bubbleParams = layout(dp(80), dp(49), false);
        bubbleParams.x = dp(12);
        bubbleParams.y = dp(125);
        final float[] start = new float[2];
        final int[] coords = new int[2];
        b.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = event.getRawX();start[1] = event.getRawY();
                    coords[0] = bubbleParams.x;coords[1] = bubbleParams.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(event.getRawX()-start[0]) > dp(7) || Math.abs(event.getRawY()-start[1]) > dp(7)) {
                        bubbleParams.x = Math.max(0, coords[0] - Math.round(event.getRawX()-start[0]));
                        bubbleParams.y = Math.max(0, coords[1] + Math.round(event.getRawY()-start[1]));
                        try { manager.updateViewLayout(b, bubbleParams); } catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(event.getRawX()-start[0]) < dp(7) && Math.abs(event.getRawY()-start[1]) < dp(7)) showPanel();
                    return true;
                default: return false;
            }
        });
        manager.addView(b, bubbleParams);
        bubble = b;
    }

    private void showPanel() {
        removeBubble();
        if (panel != null) return;
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.TRANSPARENT);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.getSettings().setAllowFileAccess(true);
        w.getSettings().setAllowFileAccessFromFileURLs(false);
        w.getSettings().setAllowUniversalAccessFromFileURLs(false);
        w.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/panel/");
            }
        });
        w.addJavascriptInterface(new PanelBridge(store, this::minimize), "SkinLabAndroid");
        DisplayMetrics display = getResources().getDisplayMetrics();
        WindowManager.LayoutParams p = layout(
                Math.min(display.widthPixels - dp(18), dp(1250)),
                Math.min(display.heightPixels - dp(30), dp(735)), true);
        p.x = dp(9);p.y = dp(12);
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        try {
            manager.addView(w, p);
            panel = w;
            w.loadUrl("file:///android_asset/panel/index.html");
        } catch (Throwable t) {
            Log.e(TAG, "Falha ao abrir painel", t);
            try { w.destroy(); } catch (Exception ignored) {}
            panel = null;
            showBubble();
        }
    }

    private void minimize() { removePanel(); try { showBubble(); } catch (Throwable t) { Log.e(TAG,"Falha na bolha",t);stopSelf(); } }
    private void removeBubble() {
        if (bubble != null) { try { manager.removeView(bubble); } catch(Exception ignored) {} bubble = null; }
    }
    private void removePanel() {
        if (panel != null) {
            WebView w = panel;panel = null;
            try { manager.removeView(w); } catch(Exception ignored) {}
            try { w.removeJavascriptInterface("SkinLabAndroid");w.destroy(); } catch(Exception ignored) {}
        }
    }
    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density * n + .5f); }
    @Override public void onDestroy() { removePanel();removeBubble();super.onDestroy(); }
}
