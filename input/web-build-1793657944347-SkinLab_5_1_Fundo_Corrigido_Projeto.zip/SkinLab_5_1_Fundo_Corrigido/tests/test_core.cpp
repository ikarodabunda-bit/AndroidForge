#include "../app/src/main/cpp/skin_core.h"
#include <cassert>
#include <iostream>
int main() {
 assert(skinlab::catalog().size()==20);
 assert(skinlab::isValid("ak-vulcan"));
 assert(!skinlab::isValid("invalid"));
 assert(skinlab::selected()=="ak-default");
 assert(skinlab::select("awp-gungnir"));
 assert(skinlab::selected()=="awp-gungnir");
 assert(!skinlab::select("invalid"));
 assert(skinlab::selected()=="awp-gungnir");
 assert(skinlab::catalogJson().find("AK-47")!=std::string::npos);
 skinlab::restore();
 assert(skinlab::selected()=="ak-default");
 std::cout<<"PASS: catalog=20, selection, invalid id, restore, JSON"<<std::endl;
}
