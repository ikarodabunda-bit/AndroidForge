# Pacote conjunto — ChargeSkin + KEY NOUK

Os projetos são independentes e devem ser compilados separadamente.

- `KEY_NOUK_v3/`: gerador de licenças.
- `ChargeSkin_CyberPurple_v4/`: validador e catálogo flutuante.

**AndroidForge:** use os ZIPs individuais `KEY_NOUK_AndroidForge_v3.zip` e `ChargeSkin_CyberPurple_AndroidForge_v4.zip`, um por vez. Não envie este pacote combinado como se fosse um único projeto.

O relatório anterior indicava conflito entre Java 8 e Kotlin 17. Nos dois projetos, Java e Kotlin estão agora configurados para alvo 17. O compileSdk foi ajustado para 34, disponível na imagem documentada do AndroidForge.

Não foi possível executar a compilação neste ambiente porque ele não contém Gradle nem Android SDK. Portanto, estes são projetos-fonte ajustados e verificados estruturalmente, não APKs já compilados.
