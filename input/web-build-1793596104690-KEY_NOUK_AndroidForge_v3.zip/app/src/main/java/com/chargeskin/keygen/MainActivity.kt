package com.chargeskin.keygen

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private data class DurationOption(val title: String, val days: Int, val subtitle: String, val icon: String)
    private val options = listOf(
        DurationOption("1 DIA", 1, "Acesso por 24 horas", "◷"),
        DurationOption("7 DIAS", 7, "Acesso por uma semana", "▦"),
        DurationOption("31 DIAS", 31, "Acesso por 31 dias", "▣"),
        DurationOption("PERMANENTE", 0, "Sem data de expiração", "∞")
    )
    private val purple = Color.rgb(190, 83, 255)
    private val pink = Color.rgb(234, 100, 255)
    private val panel = Color.rgb(20, 14, 32)
    private val soft = Color.rgb(171, 157, 194)
    private var selectedDays = 1
    private lateinit var optionsGrid: LinearLayout
    private lateinit var keyValue: TextView
    private lateinit var expiryValue: TextView
    private lateinit var historyBox: LinearLayout
    private var currentKey: String? = null
    private val prefs by lazy { getSharedPreferences("keynouk_v2", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 6, 17)
        window.navigationBarColor = Color.rgb(9, 6, 17)
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Color.rgb(9, 6, 17)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            background = gradient(Color.rgb(9, 6, 17), Color.rgb(24, 9, 39))
        }
        scroll.addView(root)

        val top = row()
        top.addView(text("♛", 28f, pink, true).apply {
            gravity = Gravity.CENTER
            background = round(Color.rgb(43, 17, 64), dp(15), dp(1), purple)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        })
        val brand = column().apply { setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("KEY NOUK", 19f, Color.WHITE, true))
        brand.addView(text("LICENSING CONSOLE  /  v3.0", 10f, purple, true).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("OFFLINE", 9f, Color.rgb(109, 239, 162), true).apply {
            gravity = Gravity.CENTER
            background = round(Color.rgb(17, 47, 36), dp(20), dp(1), Color.rgb(38, 155, 99))
            setPadding(dp(11), dp(7), dp(11), dp(7))
        })
        root.addView(top)
        root.addView(text("Gere acessos.\nDo seu jeito.", 30f, Color.WHITE, true).apply { setPadding(0, dp(28), 0, dp(8)) })
        root.addView(text("Crie uma licença exclusiva para o ChargeSkin Cyber Purple e escolha por quanto tempo ela ficará ativa.", 13f, soft).apply {
            setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(20))
        })

        val durationCard = card()
        durationCard.addView(text("01  /  PERÍODO DA LICENÇA", 11f, purple, true).apply { setPadding(0, 0, 0, dp(14)) })
        optionsGrid = column()
        durationCard.addView(optionsGrid)
        root.addView(durationCard)
        renderOptions()

        root.addView(actionButton("✦     GERAR NOVA KEY", true) { generateKey() }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(14) })

        val output = card().apply { setPadding(dp(17), dp(17), dp(17), dp(17)) }
        output.addView(text("02  /  SUA LICENÇA", 11f, purple, true))
        keyValue = text("Sua KEY aparecerá aqui", 13f, Color.WHITE, true).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(13), dp(16), dp(13), dp(16))
            background = round(Color.rgb(10, 8, 17), dp(12), dp(1), Color.rgb(87, 45, 119))
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        output.addView(keyValue, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        expiryValue = text("Aguardando geração", 11f, soft).apply { setPadding(0, dp(10), 0, dp(2)) }
        output.addView(expiryValue)
        val actions = row().apply { setPadding(0, dp(12), 0, 0) }
        actions.addView(actionButton("COPIAR KEY", false) { copyCurrent() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(View(this), LinearLayout.LayoutParams(dp(9), 1))
        actions.addView(actionButton("COMPARTILHAR", false) { shareCurrent() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        output.addView(actions)
        root.addView(output, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val historyCard = card()
        val historyHead = row()
        historyHead.addView(text("03  /  HISTÓRICO RECENTE", 11f, purple, true), LinearLayout.LayoutParams(0, -2, 1f))
        historyHead.addView(text("LIMPAR", 10f, soft, true).apply {
            setPadding(dp(8), dp(4), dp(2), dp(4))
            setOnClickListener { prefs.edit().remove("history").apply(); renderHistory() }
        })
        historyCard.addView(historyHead)
        historyBox = column().apply { setPadding(0, dp(12), 0, 0) }
        historyCard.addView(historyBox)
        root.addView(historyCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(text("KEY NOUK  •  BUILT FOR CHARGESKIN\nLicenças offline de demonstração. Consulte o README antes de distribuir.", 10f, Color.rgb(119, 108, 139)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(22), 0, 0); setLineSpacing(dp(3).toFloat(), 1f)
        })
        setContentView(scroll)
        renderHistory()
    }

    private fun renderOptions() {
        optionsGrid.removeAllViews()
        for (i in options.indices step 2) {
            val r = row()
            for (j in i until minOf(i + 2, options.size)) {
                val opt = options[j]
                val selected = opt.days == selectedDays
                val tile = column().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(13), dp(13), dp(10), dp(13))
                    background = round(if (selected) Color.rgb(49, 20, 73) else Color.rgb(23, 17, 34), dp(15), dp(1), if (selected) pink else Color.rgb(65, 48, 83))
                    setOnClickListener { selectedDays = opt.days; renderOptions() }
                }
                tile.addView(text(opt.icon, 23f, if (selected) pink else soft, true))
                tile.addView(text(opt.title, 14f, Color.WHITE, true).apply { setPadding(0, dp(7), 0, dp(3)) })
                tile.addView(text(opt.subtitle, 10f, soft))
                r.addView(tile, LinearLayout.LayoutParams(0, dp(104), 1f).apply {
                    if (j % 2 == 0) marginEnd = dp(7) else marginStart = dp(7)
                })
            }
            optionsGrid.addView(r, LinearLayout.LayoutParams(-1, -2).apply { if (i > 0) topMargin = dp(10) })
        }
    }

    private fun generateKey() {
        try {
            val now = System.currentTimeMillis()
            val expires = if (selectedDays == 0) 0L else now + selectedDays * 24L * 60L * 60L * 1000L
            val id = UUID.randomUUID().toString().replace("-", "").uppercase(Locale.US).take(16)
            val payload = "KN1|$id|$now|$expires|$selectedDays"
            val payloadEncoded = b64(payload.toByteArray(Charsets.UTF_8))
            val signature = Signature.getInstance("SHA256withECDSA")
            val privateBytes = Base64.decode(PRIVATE_KEY_B64, Base64.DEFAULT)
            val privateKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(privateBytes))
            signature.initSign(privateKey)
            signature.update(payload.toByteArray(Charsets.UTF_8))
            val sigEncoded = b64(signature.sign())
            val key = "KN1.$payloadEncoded.$sigEncoded"
            currentKey = key
            keyValue.text = key
            expiryValue.text = if (expires == 0L) "♛  Licença permanente  •  ID $id" else "◷  Expira em ${formatDate(expires)}  •  ID $id"
            val label = options.first { it.days == selectedDays }.title
            val record = "$label\t$expires\t$key"
            val old = prefs.getString("history", "").orEmpty().split("\n").filter { it.isNotBlank() }
            prefs.edit().putString("history", (listOf(record) + old).take(12).joinToString("\n")).apply()
            renderHistory()
            Toast.makeText(this, "KEY $label gerada com sucesso", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível gerar a KEY: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderHistory() {
        historyBox.removeAllViews()
        val records = prefs.getString("history", "").orEmpty().split("\n").filter { it.isNotBlank() }.take(6)
        if (records.isEmpty()) {
            historyBox.addView(text("Nenhuma licença criada nesta instalação.", 11f, soft))
            return
        }
        records.forEachIndexed { index, record ->
            val parts = record.split("\t", limit = 3)
            if (parts.size < 3) return@forEachIndexed
            val line = row().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
            val desc = column()
            desc.addView(text(parts[0], 12f, Color.WHITE, true))
            val expiry = parts[1].toLongOrNull() ?: 0L
            desc.addView(text(if (expiry == 0L) "Sem expiração" else "Até ${formatDate(expiry)}", 10f, soft).apply { setPadding(0, dp(3), 0, 0) })
            line.addView(desc, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(text("COPIAR", 10f, pink, true).apply {
                setPadding(dp(10), dp(8), 0, dp(8)); setOnClickListener { copy(parts[2]) }
            })
            historyBox.addView(line)
            if (index != records.lastIndex) historyBox.addView(View(this).apply {
                setBackgroundColor(Color.rgb(48, 38, 59)); layoutParams = LinearLayout.LayoutParams(-1, dp(1))
            })
        }
    }

    private fun copyCurrent() { currentKey?.let { copy(it) } ?: Toast.makeText(this, "Gere uma KEY primeiro", Toast.LENGTH_SHORT).show() }
    private fun copy(value: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("KEY NOUK", value))
        Toast.makeText(this, "KEY copiada", Toast.LENGTH_SHORT).show()
    }
    private fun shareCurrent() {
        val key = currentKey ?: run { Toast.makeText(this, "Gere uma KEY primeiro", Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, key) }, "Compartilhar KEY"))
    }
    private fun formatDate(value: Long) = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(value))
    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    private fun card() = column().apply { setPadding(dp(16), dp(16), dp(16), dp(16)); background = round(panel, dp(20), dp(1), Color.rgb(78, 47, 103)) }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun actionButton(label: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
        background = round(if (primary) Color.rgb(116, 38, 177) else Color.rgb(43, 29, 58), dp(14), dp(1), if (primary) pink else Color.rgb(105, 72, 133))
        setOnClickListener { action() }
    }
    private fun round(color: Int, radius: Int, stroke: Int, strokeColor: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke > 0) setStroke(stroke, strokeColor)
    }
    private fun gradient(a: Int, b: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b))

    companion object {
        // Prototype only: this private signing key is embedded in the generator APK.
        private const val PRIVATE_KEY_B64 = "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgZSPf2fufXyNoD+mH8u3MXtRyAgHELvUxL9pbwgeHbWahRANCAATv17KRsSu+nEn6j5EK39R3GSRMDKnpM2tk7zJfh/p8wfxdpYlr3jVI7L78fXuV9+388DT7pLN6GrvkTr0uyy+B"
    }
}
