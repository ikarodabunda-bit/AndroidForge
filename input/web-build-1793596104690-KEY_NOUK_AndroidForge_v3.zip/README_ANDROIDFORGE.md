# KEY NOUK v3.0 — AndroidForge

## Build

Upload this ZIP by itself to AndroidForge. The ZIP root contains `settings.gradle.kts`, `build.gradle.kts` and `app/build.gradle.kts`.

Recommended AndroidForge variant: **debug** for first testing.

Toolchain pinned in the project:
- Android Gradle Plugin 8.7.3
- Kotlin Gradle Plugin 2.0.21
- Java source/target 17
- Kotlin JVM target 17
- compileSdk 34 / minSdk 23 / targetSdk 32

The previous AndroidForge failure was a Java 8 vs Kotlin 17 target mismatch. Both are explicitly set to 17 in this project.

## Functions

- Choose 1 day, 7 days, 31 days or permanent.
- Generate a signed, unique license.
- Copy or share the key.
- See and clear a local recent-key history.

## Security note

This is an offline test generator. Its signing private key is packaged in the APK and can be extracted. Do not use it as a production license system or distribute it as tamper-proof. For production, issue signatures from a private server or a controlled administrative tool and keep the private key outside the client APK.
