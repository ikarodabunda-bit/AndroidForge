# ChargeSkin Cyber Red v6 — SKIN LAB | By:Noukzxx

**Projeto Android importável diretamente no AndroidForge.** Este arquivo é código-fonte Gradle, **não é um APK**. Compile com Java 17, Android SDK 34, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.

## Recursos
- Laboratório 3D independente (WebGL 1 e renderizador 3D alternativo por software).
- Rotação por arraste, zoom por pinça e slider, animação de inspeção de 2,5 segundos, simulação de câmera em primeira pessoa com braço e mão ilustrativos.
- Modelos 3D **procedurais e simplificados**, de 4 famílias: facas, rifles/snipers, pistolas e luvas. **Não são malhas/rigs originais do Counter Flame**, nem réplicas exatas dos modelos.
- 296 registros encontrados na pesquisa anterior de arquivos e prints; 93 miniaturas recortadas dos prints enviados. Quando falta miniatura, o app sinaliza.
- Pesquisa com normalização de pontuação e acentos, cartões, favoritos persistentes.
- Licenças ECDSA do KEY NOUK v6: pareamento por deep-link ou copiar/colar, emissor Android Keystore. Acesso ao laboratório visual NÃO exige licença; a licença é verificada para abrir o catálogo de sobreposição Android.
- Identificador Android: `com.noukzxx.chargeskin.red.standalone26`. Atualiza versões v4/v5 do mesmo projeto; NÃO conflita com `com.noukzxx.keynouk.issuer.standalone26`.

## Uso
1. Importe este ZIP **individualmente** no AndroidForge, compilando o app em debug.
2. Instale o APK gerado e abra **ChargeSkin Skin Lab**.
3. Selecione uma skin no laboratório ou no catálogo em **INSPECIONAR NO SKIN LAB**; arraste para girar, deslize o zoom, toque em INSPECIONAR ou 1ª PESSOA.
4. Opcional para flutuante: instale o KEY NOUK, pareie o emissor em Acesso, emita uma licença e ative-a. Conceda a permissão de sobreposição Android.

## Limites claros
- Não equipa skins no jogo, não altera inventário, nem injeta códigos, não contorna anti-cheat ou proteções.
- Os bundles Unity originais enviados NÃO estão incluídos neste ZIP (total ~250 MB); as malhas originais ainda não foram decodificadas/validadas e seus materiais não foram mapeados. Os modelos 3D não podem ser chamados de extração fiel dos bundles.
- A função de laboratório 3D funciona offline. O WebGL precisa de suporte no dispositivo, mas existe fallback 3D por software; a compatibilidade real com o celular deve ser testada no Android.
- Licenças offline são para testes; não existe servidor para revogação, antifraude ou controle comercial.
- Não foi possível compilar o APK neste ambiente por ausência de Android SDK e Gradle. Os testes de interface ocorreram no Chromium em modo software e os arquivos passaram na validação estática.
