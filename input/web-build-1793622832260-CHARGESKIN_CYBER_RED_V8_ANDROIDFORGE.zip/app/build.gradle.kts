plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.noukzxx.charge"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.noukzxx.chargeskin.red.standalone26"
        minSdk = 23
        targetSdk = 32
        versionCode = 8
        versionName = "8.0.0-skinchanger-lab"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
