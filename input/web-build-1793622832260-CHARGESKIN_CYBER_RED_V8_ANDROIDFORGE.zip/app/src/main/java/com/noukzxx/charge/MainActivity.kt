package com.noukzxx.charge

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    /** CounterFlame package, identified independently. No process inspection or game patching. */
    companion object { private const val GAME_PACKAGE = "com.ScarletWork.CounterFlame" }

    private fun launcher(): Intent? = try {
        packageManager.getLaunchIntentForPackage(GAME_PACKAGE)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
    } catch (_: Exception) { null }

    private fun licenseOk(): Boolean = LicenseVerifier.check(
        prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: ""
    ).optBoolean("ok")

    private fun canOverlay(): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    private fun gameStatusJson(): String = JSONObject()
        .put("package", GAME_PACKAGE)
        .put("installed", launcher() != null)
        .put("overlayAllowed", canOverlay())
        .put("licenseValid", licenseOk())
        .put("compatibility", prefs.getBoolean("compatibility", false))
        .put("android", Build.VERSION.SDK_INT)
        .toString()

    /** Open the installed game with a user-initiated explicit launcher intent. */
    private fun showGame(withOverlay: Boolean): String {
        val game = launcher() ?: return "GAME_MISSING"
        if (withOverlay) {
            if (!licenseOk()) return "LICENSE_REQUIRED"
            if (prefs.getBoolean("compatibility", false)) return "COMPATIBILITY"
            if (!canOverlay()) return "PERMISSION"
        }
        runOnUiThread {
            try {
                if (withOverlay) {
                    val service = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                }
                // Slight delay lets Android promote the overlay to foreground service.
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startActivity(game) }
                    catch (_: Exception) {
                        web.post { web.evaluateJavascript("window.onGameLaunchFailure && window.onGameLaunchFailure()", null) }
                    }
                }, if (withOverlay) 380L else 0L)
            } catch (_: Exception) {
                web.post { web.evaluateJavascript("window.onGameLaunchFailure && window.onGameLaunchFailure()", null) }
            }
        }
        return "OK"
    }

    private val prefs by lazy { getSharedPreferences("charge_v2", MODE_PRIVATE) }
    private lateinit var web: WebView
    private var pendingKind: String? = null
    private var pendingValue: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 7, 8)
        window.navigationBarColor = Color.rgb(7, 7, 8)
        receiveTransfer(intent)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 7, 8))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowContentAccess = false
            settings.allowFileAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                    url?.startsWith("file:///android_asset/") != true
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    deliverTransfer()
                }
            }
            addJavascriptInterface(Bridge(), "Charge")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        receiveTransfer(newIntent)
        deliverTransfer()
    }

    private fun receiveTransfer(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_VIEW) return
        val uri = incoming.data ?: return
        if (uri.scheme != "noukchargeskin") return
        val kind = uri.host ?: return
        if (kind != "pair" && kind != "activate") return
        val param = if (kind == "pair") "issuer" else "token"
        val value = uri.getQueryParameter(param)?.trim() ?: return
        if (value.length !in 30..4096) return
        pendingKind = kind
        pendingValue = value
    }

    private fun deliverTransfer() {
        if (!::web.isInitialized) return
        val kind = pendingKind ?: return
        val value = pendingValue ?: return
        pendingKind = null
        pendingValue = null
        val script = "window.onNoukTransfer && window.onNoukTransfer(" +
            JSONObject.quote(kind) + "," + JSONObject.quote(value) + ")"
        web.post { web.evaluateJavascript(script, null) }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.post {
            web.evaluateJavascript("window.onPermissionUpdate && window.onPermissionUpdate()", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun gameStatus(): String = gameStatusJson()
        @JavascriptInterface fun openGame(): String = showGame(false)
        @JavascriptInterface fun openGameWithOverlay(): String = showGame(true)

        @JavascriptInterface fun appIdentity(): String = packageName
        @JavascriptInterface fun equipSkin(id: String): String {
            if (!licenseOk()) return "LICENSE_REQUIRED"
            if (!id.matches(Regex("[A-Za-z0-9_-]{1,96}"))) return "INVALID_SKIN"
            prefs.edit().putString("lab_skin", id).apply()
            return "OK"
        }
        @JavascriptInterface fun applyFinish(finish: String): String {
            if (!licenseOk()) return "LICENSE_REQUIRED"
            if (finish !in setOf("original", "ruby", "emerald", "sapphire", "gold", "chrome")) return "INVALID_FINISH"
            prefs.edit().putString("lab_finish", finish).apply()
            return "OK"
        }
        @JavascriptInterface fun labSelection(): String = JSONObject()
            .put("skin", prefs.getString("lab_skin", ""))
            .put("finish", prefs.getString("lab_finish", "original"))
            .toString()
        @JavascriptInterface fun hasValidKey(): Boolean = licenseOk()
        @JavascriptInterface fun status(): String {
            val token = prefs.getString("token", "") ?: ""
            val issuer = prefs.getString("issuer", "") ?: ""
            val result = if (token.isEmpty()) JSONObject().put("ok", false).put("error", "Nenhuma licença ativada.")
                         else LicenseVerifier.check(token, issuer)
            return JSONObject().put("paired", issuer.isNotEmpty())
                .put("valid", result.optBoolean("ok"))
                .put("expires", result.optLong("expires"))
                .put("days", result.optInt("days"))
                .put("error", result.optString("error"))
                .put("overlayAllowed", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
                .put("compatibility", prefs.getBoolean("compatibility", false))
                .toString()
        }

        @JavascriptInterface fun clipboardText(): String = try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (!clipboard.hasPrimaryClip()) "" else
                clipboard.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()?.take(4096) ?: ""
        } catch (_: Exception) { "" }

        @JavascriptInterface fun pairIssuer(text: String): String {
            if (text.length > 1024) return "Chave pública excessivamente longa."
            if (LicenseVerifier.parseIssuer(text) == null) return "Emissor inválido. Copie a chave pública do KEY NOUK."
            prefs.edit().putString("issuer", text.trim()).remove("token").apply()
            return "OK"
        }

        @JavascriptInterface fun activate(token: String): String {
            if (token.length > 4096) return JSONObject().put("ok", false).put("error", "KEY excessivamente longa.").toString()
            val result = LicenseVerifier.check(token.trim(), prefs.getString("issuer", "") ?: "")
            if (result.optBoolean("ok")) prefs.edit().putString("token", token.trim()).apply()
            return result.toString()
        }

        @JavascriptInterface fun setCompatibility(enabled: Boolean) {
            prefs.edit().putBoolean("compatibility", enabled).apply()
            if (enabled) runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }

        @JavascriptInterface fun requestOverlay() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else launchOverlay()
            }
        }

        @JavascriptInterface fun openOverlay(): String {
            if (prefs.getBoolean("compatibility", false)) return "Desative o Modo Compatibilidade para abrir a sobreposição."
            val result = LicenseVerifier.check(prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: "")
            if (!result.optBoolean("ok")) return result.optString("error", "Licença inválida")
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) return "PERMISSION"
            runOnUiThread { launchOverlay() }
            return "OK"
        }

        private fun launchOverlay() {
            val result = LicenseVerifier.check(prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: "")
            if (!result.optBoolean("ok") || prefs.getBoolean("compatibility", false)) return
            try {
                val i = Intent(this@MainActivity, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } catch (e: Exception) {
                if (::web.isInitialized) web.evaluateJavascript(
                    "window.onOverlayLaunchFailure && window.onOverlayLaunchFailure()", null
                )
            }
        }

        @JavascriptInterface fun closeOverlay() {
            runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }

        @JavascriptInterface fun resetPairing() {
            prefs.edit().remove("issuer").remove("token").apply()
            closeOverlay()
        }
        @JavascriptInterface fun copy(text: String) {
            if (text.length > 4096) return
            runOnUiThread {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("ChargeSkin", text))
            }
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.removeJavascriptInterface("Charge"); web.destroy() }
        super.onDestroy()
    }
}
