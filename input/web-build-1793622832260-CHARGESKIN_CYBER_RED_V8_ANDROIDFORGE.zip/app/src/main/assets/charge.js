(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const catalog=window.NOUK_CATALOG||[];
  const native=!!window.Charge;
  const categories=['Todas',...new Set(catalog.map(x=>x.category))];
  try{ $('installedPackage').textContent=native&&typeof Charge.appIdentity==='function'?'ID: '+Charge.appIdentity():'Prévia do catálogo';}catch(e){}
  let storedFavorites=[];try{storedFavorites=JSON.parse(localStorage.getItem('nouk_favorites')||'[]')}catch(e){}
  const favs=new Set(Array.isArray(storedFavorites)?storedFavorites:[]);
  let active='Todas',timer=0;
  const normalizeSearch=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const src=x=>x.source==='print+bundle'?'PRINT + BUNDLE':x.source==='print-only'?'CONFIRMADO POR PRINT':x.source==='bundle+previous-catalog'?'CATÁLOGO + BUNDLE':'RECURSO UNITY';
  const img=x=>x.image?`<img loading="lazy" src="${esc(x.image)}" alt="${esc(x.name)}">`:'<div class="placeholder" aria-label="Imagem ainda não disponível">◈</div>';
  function displayCard(x){return `<article class="tile" tabindex="0" data-view="${esc(x.id)}">${img(x)}<button class="star ${favs.has(x.id)?'on':''}" data-fav="${esc(x.id)}" aria-label="Favoritar">${favs.has(x.id)?'★':'☆'}</button><h3>${esc(x.name)}</h3><div class="src">${src(x)}</div></article>`;}
  function bindCards(box){box.querySelectorAll('[data-fav]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const id=b.dataset.fav;favs.has(id)?favs.delete(id):favs.add(id);localStorage.setItem('nouk_favorites',JSON.stringify([...favs]));render();window.dispatchEvent(new Event('nouk:lab-favorites-sync'));}));box.querySelectorAll('[data-view]').forEach(b=>{b.addEventListener('click',()=>detail(b.dataset.view));b.addEventListener('keydown',e=>{if(e.key==='Enter')detail(b.dataset.view)})});}
  function detail(id){const x=catalog.find(s=>s.id===id);if(!x)return;const container=$('detailBody');container.innerHTML=`<div class="row"><span class="section-name">DETALHES DO RECURSO</span><button class="btn small secondary" id="dismiss">FECHAR</button></div><div style="height:150px;margin:11px 0">${img(x)}</div><h2>${esc(x.name)}</h2><p class="soft">${esc(x.category)} • ${src(x)}</p><p class="soft">Identificador técnico: <code>${esc(x.id)}</code></p><p class="soft">Bundles localizados: ${x.bundles} ${x.bundleZip?'• '+esc(x.bundleZip):''}</p><div class="buttons"><button class="btn" id="previewLab">◈ INSPECIONAR NO SKIN LAB</button></div><p class="notice">Visualização de catálogo: não altera arquivos, equipamentos ou inventário do jogo.</p>`;$('detail').classList.remove('hide');$('dismiss').onclick=()=>$('detail').classList.add('hide');$('previewLab').onclick=()=>{ $('detail').classList.add('hide'); window.openLabItem && window.openLabItem(x.id); };}
  $('detail').addEventListener('click',e=>{if(e.target===$('detail'))$('detail').classList.add('hide')});
  function render(){let text=normalizeSearch($('search').value);const found=catalog.filter(x=>(active==='Todas'||x.category===active)&&normalizeSearch(`${x.name} ${x.id} ${x.category}`).includes(text));$('grid').innerHTML=found.length?found.map(displayCard).join(''):'<p class="nfound">Nenhum resultado para essa busca.</p>';$('resultCount').textContent=found.length+' itens';bindCards($('grid'));const bookmarked=catalog.filter(x=>favs.has(x.id));$('favgrid').innerHTML=bookmarked.map(displayCard).join('');bindCards($('favgrid'));$('emptyFav').classList.toggle('hide',bookmarked.length>0);$('favcount').textContent=bookmarked.length;}
  $('total').textContent=catalog.length;
  $('chips').innerHTML=categories.map(c=>`<button class="chip ${c==='Todas'?'selected':''}" data-category="${esc(c)}">${esc(c)}</button>`).join('');$('chips').addEventListener('click',e=>{const b=e.target.closest('[data-category]');if(!b)return;active=b.dataset.category;[...$('chips').children].forEach(x=>x.classList.toggle('selected',x===b));render()});
  $('search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(render,100)});
  [...document.querySelectorAll('#nav button')].forEach(b=>b.onclick=()=>{document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x===b));['lab','catalog','favorites','access','settings','game'].forEach(x=>$('page-'+x).classList.toggle('hide',x!==b.dataset.page));if(b.dataset.page==='access')refreshStatus()});
  function message(text,isError){$('licenseStatus').textContent=text;$('licenseStatus').className=isError?'error':'good';}
  const gate=$('licenseGate');
  let previouslyValid=false;
  function gotoAccess(){
    document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x.dataset.page==='access'));
    ['lab','catalog','favorites','access','settings','game'].forEach(x=>$('page-'+x).classList.toggle('hide',x!=='access'));
  }
  function enforceGate(reason){
    if(!native){gate.classList.add('hide');return true;}
    let ok=false;try{ok=!!Charge.hasValidKey();}catch(e){}
    const active=document.querySelector('#nav button.active');
    const inAccess=active && active.dataset.page==='access';
    if(ok){if(!previouslyValid && window.SkinLab)window.SkinLab.activate();previouslyValid=true;gate.classList.add('hide');return true;}
    previouslyValid=false;
    if(reason)$('gateReason').textContent=reason;
    if(!inAccess)gate.classList.remove('hide');else gate.classList.add('hide');
    return false;
  }
  $('gateAccess').onclick=()=>{gate.classList.add('hide');gotoAccess();};
  window.NoukGate={lock:reason=>{gotoAccess();gate.classList.add('hide');message(reason||'Ative a KEY obrigatória.',true);},check:enforceGate};
  const initialNav=document.querySelector('#nav button.active');
  [...document.querySelectorAll('#nav button')].forEach(b=>b.addEventListener('click',()=>{if(b.dataset.page!=='access')enforceGate();}));
  function refreshStatus(){if(!native){$('licenseMini').textContent='DEMO';message('Prévia no navegador: instale o APK para validar licenças.',false);return};try{const s=JSON.parse(Charge.status());$('licenseMini').textContent=s.valid?'ATIVA':s.paired?'PAREADA':'OFF';enforceGate();if(s.valid)message(`Licença válida • ${s.days===0?'Permanente':s.days+' dia(s)'} ${s.expires? '• até '+new Date(s.expires).toLocaleString('pt-BR'):''}`,false);else message(s.paired?(s.error||'Informe sua KEY'): 'Faça o pareamento com o emissor.',!!s.paired)}catch(e){message('Falha na leitura do estado.',true)}}
  window.onPermissionUpdate=()=>{refreshStatus();refreshGameStatus();enforceGate();};
  window.onOverlayLaunchFailure=()=>message('O Android bloqueou o início do flutuante. Verifique permissões e economia de bateria.',true);
  function openAccess(){const btn=document.querySelector('#nav button[data-page="access"]');if(btn)btn.click();}
  window.onNoukTransfer=(kind,value)=>{
    openAccess();
    if(!native){message('Transferência disponível somente no Android.',true);return}
    if(kind==='pair'){
      $('issuerInput').value=value;
      if(!confirm('KEY NOUK quer configurar este emissor. Você confia neste aplicativo e confirma o pareamento?')){
        message('Pareamento cancelado pelo usuário.',true);return;
      }
      const res=Charge.pairIssuer(value);refreshStatus();
      if(res!=='OK')message(res,true);else message('Emissor pareado. Agora ative uma KEY.',false);
    } else if(kind==='activate'){
      $('tokenInput').value=value;
      if(!confirm('Recebeu uma licença do KEY NOUK. Deseja verificar a assinatura e ativar?')){
        message('Ativação cancelada.',true);return;
      }
      try{const r=JSON.parse(Charge.activate(value));refreshStatus();message(r.ok?'Licença validada e ativada!':r.error,!r.ok)}
      catch(e){message('Falha na ativação.',true)}
    }
  };
  function pasteInto(id){if(!native){message('Disponível somente no Android.',true);return}const val=Charge.clipboardText();if(val)$(id).value=val;else message('Área de transferência vazia ou inacessível.',true)}
  $('pasteIssuer').onclick=()=>pasteInto('issuerInput');
  $('pasteToken').onclick=()=>pasteInto('tokenInput');
  $('pair').onclick=()=>{if(!native){message('Pareamento exige o aplicativo Android.',true);return}if(!confirm('Confirma confiar neste emissor? Isso substitui o emissor anterior e invalida a KEY antiga.'))return;const result=Charge.pairIssuer($('issuerInput').value);refreshStatus();message(result==='OK'?'Emissor associado. Agora informe uma KEY.':result,result!=='OK')};
  $('activate').onclick=()=>{if(!native){message('Ativação exige o aplicativo Android.',true);return}try{const result=JSON.parse(Charge.activate($('tokenInput').value));refreshStatus();message(result.ok?'Licença ativada!':result.error,!result.ok)}catch(e){message('KEY inválida.',true)}};
  $('openOverlay').onclick=()=>{if(!native){message('Flutuante disponível no aplicativo Android.',true);return}let result=Charge.openOverlay();if(result==='PERMISSION'){Charge.requestOverlay();message('Conceda a permissão de sobreposição no Android e toque em ABRIR novamente.',false)}else message(result==='OK'?'Solicitação de abertura enviada ao Android.':'Não foi possível abrir: '+result,result!=='OK')};
  $('stopOverlay').onclick=()=>{if(native)Charge.closeOverlay();message('Flutuante encerrado.',false)};
  let compatSaved=localStorage.getItem('nouk_compat')==='1';if(native){try{compatSaved=!!JSON.parse(Charge.status()).compatibility}catch(e){}}$('compat').checked=compatSaved;$('compat').onchange=e=>{const on=e.target.checked;localStorage.setItem('nouk_compat',on?'1':'0');if(native)Charge.setCompatibility(on)};
  $('reduced').checked=localStorage.getItem('nouk_reduce')==='1';function reduce(on){document.body.classList.toggle('reduce-motion',on)} reduce($('reduced').checked);$('reduced').onchange=e=>{reduce(e.target.checked);localStorage.setItem('nouk_reduce',e.target.checked?'1':'0')};
  $('goGamePage').onclick=()=>{['lab','catalog','favorites','access','settings','game'].forEach(x=>$('page-'+x).classList.toggle('hide',x!=='game'));document.querySelectorAll('#nav button').forEach(b=>b.classList.remove('active'));};
  $('resetPairing').onclick=()=>{if(!native)return;if(confirm('Remover o emissor e a licença salva?')){Charge.resetPairing();refreshStatus()}};

  function gameMessage(text, bad){$('gameMessage').textContent=text;$('gameMessage').className=bad?'notice error':'notice'}
  function refreshGameStatus(){
    if(!native){$('gameStatus').textContent='Prévia no navegador • Verificação disponível no Android';return}
    try {
      const s=JSON.parse(Charge.gameStatus());
      const flags=[s.installed?'Jogo instalado':'Jogo não localizado',s.overlayAllowed?'Sobreposição permitida':'Permissão pendente',s.licenseValid?'KEY ativa':'KEY pendente'];
      $('gameStatus').textContent=flags.join(' · ');
    } catch(e){$('gameStatus').textContent='Não foi possível consultar o dispositivo.'}
  }
  function handleGameResult(result){
    const msgs={
      OK:'Comando enviado ao Android. Abra o catálogo pela bolha vermelha quando o jogo aparecer.',
      GAME_MISSING:'Counter Flame não foi localizado. Instale o jogo de fonte oficial; identificador procurado: com.ScarletWork.CounterFlame.',
      LICENSE_REQUIRED:'Ative uma licença válida na aba Acesso para usar o flutuante.',
      COMPATIBILITY:'O Modo Compatibilidade está ativo. Desative-o em Ajustes para usar a sobreposição.',
      PERMISSION:'É necessário permitir exibição sobre outros apps nas configurações do Android.'
    };
    const bad=result!=='OK';gameMessage(msgs[result]||('Não foi possível iniciar o jogo: '+result),bad);
    if(result==='PERMISSION') Charge.requestOverlay();
    refreshGameStatus();
  }
  $('checkGame').onclick=refreshGameStatus;
  $('playGame').onclick=()=>{
    if(!native){gameMessage('Esta função exige o aplicativo instalado no Android.',true);return}
    handleGameResult(Charge.openGame());
  };
  $('playWithOverlay').onclick=()=>{
    if(!native){gameMessage('Esta função exige o aplicativo instalado no Android.',true);return}
    handleGameResult(Charge.openGameWithOverlay());
  };
  $('gamePermission').onclick=()=>{
    if(!native){gameMessage('Permissões são configuradas no Android.',true);return}
    Charge.requestOverlay();refreshGameStatus();
  };
  window.onGameLaunchFailure=()=>gameMessage('O Android não permitiu iniciar o jogo ou o serviço. Confira a instalação e as restrições de bateria.',true);

  window.addEventListener('nouk:favorites-changed',()=>{try{const raw=JSON.parse(localStorage.getItem('nouk_favorites')||'[]');favs.clear();raw.forEach(id=>favs.add(id));render();}catch(e){}});
  render();refreshStatus();refreshGameStatus();enforceGate();
  if(native)window.setInterval(()=>enforceGate(),12000);
})();
