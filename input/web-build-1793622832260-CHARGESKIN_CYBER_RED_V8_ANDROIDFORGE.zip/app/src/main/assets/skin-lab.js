/* Skin Lab v6 — WebGL ES 2 compatible, offline, procedural demonstration models.
   Game-authentic thumbnails are displayed separately and never represented as meshes.
   Built with raw WebGL 1; requires no CDN or third-party JavaScript. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const all = window.NOUK_CATALOG || [];
  const faved = () => { try { return new Set(JSON.parse(localStorage.getItem('nouk_favorites') || '[]')); } catch (_) { return new Set(); } };
  const esc = s => String(s || '').replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
  const sourceName = v => v.source === 'print+bundle' ? 'Print e pasta de bundle identificados' : v.source === 'print-only' ? 'Captura de tela do jogo' : v.image ? 'Miniatura de captura de tela' : 'Recurso de bundle, sem miniatura validada';
  let selected = null, yaw = -0.28, pitch = -0.15, zoom = 48, firstPerson = false, inspectUntil = 0, lastFrame = 0;
  let finish = 'original';
  const android = typeof Charge !== 'undefined' && typeof Charge.hasValidKey === 'function';
  const allowed = () => !android || Charge.hasValidKey();
  function equipMessage(msg, bad=false){ const box=$('labEquipMessage');if(box){box.textContent=msg;box.style.color=bad?'#ff647f':'#d5dee3';} }
  function updateFinishUI(){document.querySelectorAll('[data-finish]').forEach(b=>b.classList.toggle('active',b.dataset.finish===finish));}
  let gl = null, softCtx = null, meshData = null, shader = null, buffers = {}, vertexCount = 0, positionLoc = -1, normalLoc = -1, colorLoc = -1, materialLoc = -1, uniforms = {};
  let renderError = '';
  const vert = `attribute vec3 a_pos; attribute vec3 a_normal; attribute vec3 a_color; attribute float a_mat;
  uniform mat4 u_proj; uniform float u_yaw; uniform float u_pitch; uniform float u_roll;
  uniform vec3 u_offset; varying vec3 v_normal; varying vec3 v_color; varying vec3 v_pos; varying float v_mat;
  vec3 turn(vec3 p){
    float cy=cos(u_yaw),sy=sin(u_yaw); p=vec3(cy*p.x+sy*p.z,p.y,-sy*p.x+cy*p.z);
    float cx=cos(u_pitch),sx=sin(u_pitch); p=vec3(p.x,cx*p.y-sx*p.z,sx*p.y+cx*p.z);
    float cz=cos(u_roll),sz=sin(u_roll); return vec3(cz*p.x-sz*p.y,sz*p.x+cz*p.y,p.z);
  }
  void main(){v_normal=normalize(turn(a_normal));v_color=a_color;v_pos=a_pos;v_mat=a_mat;
  gl_Position=u_proj*vec4(turn(a_pos)+u_offset,1.0);}`;
  const frag = `precision mediump float; varying vec3 v_normal; varying vec3 v_color; varying vec3 v_pos; varying float v_mat;
  uniform float u_time; uniform float u_pattern;
  void main(){vec3 n=normalize(v_normal); vec3 light=normalize(vec3(-0.45,0.85,0.85));
    float diffuse=max(dot(n,light),0.0); float rim=pow(1.0-max(dot(n,vec3(0.,0.,1.)),0.0),2.0);
    float stripes=sin(v_pos.x*29.0+v_pos.y*11.0+u_pattern)*sin(v_pos.y*18.0+v_pos.z*23.0);
    float wave=sin(v_pos.x*10.0+v_pos.y*8.0+u_pattern)*cos(v_pos.y*19.0-v_pos.x*5.0);
    vec3 color=v_color; if(v_mat>0.4 && v_mat<1.4) color*=0.76+0.15*stripes;
    if(v_mat>1.4 && v_mat<2.4) color*=0.84+0.22*wave;
    if(v_mat>2.4) color*=0.83+0.10*stripes;
    float metallic=(v_mat<0.4)?1.0:0.30;
    vec3 halfvector=normalize(light+vec3(0.,0.,1.));
    float spec=pow(max(dot(n,halfvector),0.0),metallic>0.5?25.0:10.0)*metallic;
    color=color*(0.30+0.83*diffuse)+vec3(spec*0.65)+vec3(0.28,0.032,0.055)*rim;
    gl_FragColor=vec4(color,1.0);}`;

  function makeShader(type, source) {
    const o = gl.createShader(type); gl.shaderSource(o, source); gl.compileShader(o);
    if (!gl.getShaderParameter(o,gl.COMPILE_STATUS)) { throw Error(gl.getShaderInfoLog(o)); }
    return o;
  }
  function initializeGL(){
    try {
      const canvas=$('labCanvas'); gl=canvas.getContext('webgl',{alpha:true,antialias:true,depth:true,preserveDrawingBuffer:false}) || canvas.getContext('experimental-webgl');
      if(!gl) throw Error('WebGL indisponível');
      shader=gl.createProgram(); gl.attachShader(shader,makeShader(gl.VERTEX_SHADER,vert));gl.attachShader(shader,makeShader(gl.FRAGMENT_SHADER,frag));gl.linkProgram(shader);
      if(!gl.getProgramParameter(shader,gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(shader));
      gl.useProgram(shader); positionLoc=gl.getAttribLocation(shader,'a_pos');normalLoc=gl.getAttribLocation(shader,'a_normal');colorLoc=gl.getAttribLocation(shader,'a_color');materialLoc=gl.getAttribLocation(shader,'a_mat');
      for(const k of ['proj','yaw','pitch','roll','offset','time','pattern']) uniforms[k]=gl.getUniformLocation(shader,'u_'+k);
      buffers.mesh=gl.createBuffer();gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);
      canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();renderError='Contexto WebGL perdido. Reabra o aplicativo para tentar novamente.';fallback(renderError);});
      return true;
    } catch(e) { renderError=String(e.message || e); gl=null;softCtx=$('labCanvas').getContext('2d');if(softCtx){$('labViewLabel').textContent='3D SOFTWARE';renderError='';return true;}fallback('Renderização 3D não suportada neste aparelho. A imagem original segue disponível.');return false; }
  }
  function fallback(text){$('labFallback').textContent=text;$('labFallback').classList.remove('hide');}
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const rgb=(r,g,b)=>[r/255,g/255,b/255];
  const mult=(c,f)=>c.map(n=>clamp(n*f,0,1));
  function colors(item){
    const name=(item.name||'').toLowerCase();
    const themes=[
      [/gamma|emerald|hot rod/, [35,230,135],[15,85,56]],
      [/fade|marble/, [255,95,92],[65,81,245]],
      [/lore|dragon|gold|tiger|arabesque|blaze/, [255,187,64],[111,65,17]],
      [/ultraviolet|purple|freehand|pandora|lightning/, [189,90,248],[64,34,120]],
      [/bright water|water|gugnir|gungnir|sapphire|ice/, [75,165,255],[34,75,148]],
      [/crimson|red|autotronic|slaughter|ruby/, [255,61,77],[95,27,39]],
      [/printstream|white|vanilla|black laminate|black tie/, [215,219,222],[50,54,63]],
      [/aquamarine|vice|neon|chromatic|wild lotus/, [51,235,221],[165,66,180]]
    ];
    let pick=themes.find(a=>a[0].test(name)); if(!pick)pick=[null,[206,97,81],[64,75,88]];
    const finishes={ruby:[[230,31,65],[108,14,44]],emerald:[[22,232,136],[12,82,60]],sapphire:[[51,128,250],[22,40,130]],gold:[[248,192,43],[132,71,18]],chrome:[[214,224,239],[69,88,110]]};
    const theme=finishes[finish]||[pick[1],pick[2]];
    return {metal:rgb(...theme[0]), accent:rgb(...theme[1]), handle:rgb(42,43,51), edge:rgb(200,210,216)};
  }
  class Mesh {
    constructor(palette){this.data=[];this.p=palette;}
    tri(a,b,c,color,material=0){
      const u=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],v=[c[0]-a[0],c[1]-a[1],c[2]-a[2]];
      let n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];
      const len=Math.hypot(...n)||1; n=n.map(x=>x/len);
      for(const pt of [a,b,c])this.data.push(...pt,...n,...color,material);
    }
    quad(a,b,c,d,color,material){this.tri(a,b,c,color,material);this.tri(a,c,d,color,material);}
    prism(polygon,z,depth,color,material=0){
      if(polygon.length<3)return;
      const f=z+depth/2,k=z-depth/2;
      for(let i=1;i<polygon.length-1;i++){
        this.tri([polygon[0][0],polygon[0][1],f],[polygon[i][0],polygon[i][1],f],[polygon[i+1][0],polygon[i+1][1],f],color,material);
        this.tri([polygon[i+1][0],polygon[i+1][1],k],[polygon[i][0],polygon[i][1],k],[polygon[0][0],polygon[0][1],k],mult(color,.77),material);
      }
      for(let i=0;i<polygon.length;i++){
        const a=polygon[i],b=polygon[(i+1)%polygon.length];
        this.quad([a[0],a[1],f],[a[0],a[1],k],[b[0],b[1],k],[b[0],b[1],f],mult(color,.69),material);
      }
    }
    box(x,y,z,w,h,d,color,mat=0){this.prism([[x-w/2,y-h/2],[x+w/2,y-h/2],[x+w/2,y+h/2],[x-w/2,y+h/2]],z,d,color,mat);}
    ring(x,y,outer,inner,z,depth,color){for(let i=0;i<20;i++){const a=i*Math.PI/10,b=(i+1)*Math.PI/10;this.prism([[x+outer*Math.cos(a),y+outer*Math.sin(a)],[x+outer*Math.cos(b),y+outer*Math.sin(b)],[x+inner*Math.cos(b),y+inner*Math.sin(b)],[x+inner*Math.cos(a),y+inner*Math.sin(a)]],z,depth,color,0);}}
    barrel(x,y,w,h,color){this.box(x,y,0,w,h,.13,color,0);this.box(x,y+h*.4,.05,w,h*.22,.17,mult(color,1.2),0);}
  }
  function bladeFor(name,metal){
    const lower=name.toLowerCase();
    if(/karambit|talon/.test(lower))return [[-0.05,.10],[.45,.27],[1.05,.37],[1.48,.18],[1.72,-.07],[1.56,-.10],[1.32,.06],[.84,.05],[.42,-.13],[.04,-.16]];
    if(/gut|flip|nomad/.test(lower))return [[.00,-.13],[.25,.28],[1.17,.30],[1.54,.12],[1.75,-.06],[1.31,-.16],[.81,-.25],[.20,-.22]];
    if(/skeleton|stiletto|paracord/.test(lower))return [[-.05,-.13],[.10,.15],[1.58,.18],[1.95,0],[1.57,-.14],[.15,-.18]];
    if(/shadow/.test(lower))return [[.03,-.14],[.24,.15],[1.19,.24],[1.57,0],[1.2,-.19],[.24,-.21]];
    return [[-.05,-.14],[.16,.23],[.49,.27],[1.60,.15],[1.92,-.02],[1.54,-.13],[.55,-.22]];
  }
  function buildKnife(mesh,name){
    const p=mesh.p, l=name.toLowerCase();
    if(/shadow/.test(l)){
      for(const dz of [-.25,.25]){
        const b=bladeFor(name);mesh.prism(b.map(([x,y])=>[x*.82+.05,y+dz]),dz*.40,.09,p.metal,2);
        mesh.box(-.69,dz,.02,1.15,.18,.18,p.handle,1);
        mesh.ring(-1.28,dz,.14,.08,.03,.20,p.edge);
      }
      return;
    }
    mesh.prism(bladeFor(name),0,.115,p.metal,2);
    mesh.prism([[.10,-.10],[.38,.05],[1.70,-.008],[1.49,-.12]],.063,.016,mult(p.edge,.83),0);
    // handle with inset textured stripe and angular grip
    const handle=/karambit|talon/.test(l)?[[-1.43,-.23],[-.13,-.22],[.18,-.09],[-.17,.16],[-1.35,.21]]:
      [[-1.52,-.20],[-.10,-.17],[.01,.07],[-.17,.22],[-1.50,.17]];
    mesh.prism(handle,0,.21,p.handle,1);
    mesh.box(-.82,-.028,.113,.96,.045,.015,p.accent,2);
    for(let i=0;i<4;i++)mesh.box(-1.29+i*.29,-.15,.117,.055,.12,.028,mult(p.edge,.65),0);
    mesh.box(-.08,.06,.03,.11,.49,.27,p.edge,0); // crossguard
    if(/karambit|talon/.test(l))mesh.ring(-1.51,-.07,.20,.12,0,.16,p.edge);
    if(/butterfly/.test(l)){
      mesh.box(-.68,.205,-.15,1.38,.12,.12,p.edge,0);
      mesh.box(-.68,-.205,-.15,1.38,.12,.12,p.edge,0);
      mesh.ring(-.08,.02,.092,.045,.09,.18,p.edge);
    }
    if(/skeleton/.test(l))for(let i=0;i<3;i++)mesh.ring(-1.26+i*.39,.015,.088,.050,.114,.027,p.edge);
  }
  function buildRifle(m,name){
    const p=m.p, sniper=/awp|sniper|ssg|scout|scar/.test(name.toLowerCase());
    m.box(.40,.025,0,1.72,.32,.25,p.metal,2); // receiver
    m.box(1.40,.055,-.02,1.23,.10,.13,p.edge,0); // barrel
    m.box(1.95,.055,0,.13,.17,.19,p.accent,0); // muzzle
    m.prism([[-.47,.12],[-1.24,.22],[-1.79,.03],[-1.69,-.28],[-1.10,-.31],[-.46,-.10]],-.01,.25,p.handle,1);
    m.box(-1.63,-.10,-.05,.25,.42,.30,p.accent,0);
    m.prism([[-.08,-.10],[.10,-.19],[.23,-.67],[-.16,-.74],[-.28,-.42]],-.02,.23,p.handle,1); // grip
    m.prism([[.35,-.18],[.86,-.16],[.75,-.58],[.51,-.58]],-.02,.13,p.accent,0); // magazine
    if(sniper){
      m.box(.14,.34,0,1.25,.085,.20,p.handle,1);m.box(.1,.49,0,.65,.20,.17,p.metal,0);
      m.box(-.47,.34,0,.22,.28,.17,p.edge,0);m.box(.75,.34,0,.12,.26,.17,p.edge,0);
      m.box(-1.20,-.04,.17,.8,.035,.025,p.accent,2);
    }else{
      m.box(.33,.31,.01,.89,.10,.19,p.handle,1);
      m.prism([[.2,.37],[.42,.36],[.56,.57],[.31,.56]],.01,.08,p.edge,0);
      m.box(.80,-.04,.135,.60,.09,.045,p.accent,0);
    }
    for(let i=0;i<6;i++)m.box(.05+i*.20,.14,.145,.09,.07,.03,mult(p.accent,1.05),2);
  }
  function buildPistol(m,name){
    const p=m.p;
    m.box(.24,.19,0,1.95,.35,.30,p.metal,2);
    m.box(1.28,.12,.01,.30,.15,.18,p.edge,0);
    m.prism([[-.50,.04],[.04,.00],[-.12,-1.11],[-.65,-1.10]],-.02,.26,p.handle,1);
    m.box(-.36,-.44,.145,.30,.08,.02,p.accent,2);
    m.box(-.48,.44,.01,.24,.11,.18,p.edge,0);
    m.box(.63,.39,.02,.16,.06,.16,p.edge,0);
    m.ring(.15,-.18,.22,.15,.02,.12,p.edge);
    for(let i=0;i<5;i++)m.box(-.52+i*.33,.28,.17,.045,.09,.04,mult(p.accent,.86),2);
  }
  function buildGloves(m,name){
    const p=m.p;
    for(const side of [-1,1]){
      const cx=side*.72;
      m.prism([[cx-.48,-.63],[cx+.44,-.61],[cx+.53,.32],[cx+.28,.62],[cx-.24,.60],[cx-.52,.30]],.04,.32,p.metal,3);
      for(let i=0;i<4;i++){
        const x=cx-.39+i*.23;
        m.box(x,.78+(i===1?.08:0),.03,.18,.51+(i===1?.16:0),.23,mult(p.metal,1+.04*i),3);
        m.box(x,.91+(i===1?.09:0),.16,.14,.13,.04,p.accent,2);
      }
      m.box(cx+side*.48,.10,.14,.22,.49,.22,p.metal,3);
      m.box(cx,-.39,.24,.78,.18,.04,p.accent,2);
      m.box(cx,-.70,.03,.77,.20,.25,p.handle,1);
      for(let i=0;i<3;i++)m.box(cx-.29+i*.27,.19,.22,.18,.17,.04,p.edge,0);
    }
  }
  function addFirstPersonHands(m,category){
    // Deliberately stylized first-person sleeve and glove; no original game rig.
    const glove=rgb(31,37,44),gloveTrim=rgb(133,45,56),sleeve=rgb(53,57,66);
    if(category.includes('luva'))return;
    m.prism([[-1.55,-.35],[-.72,-.27],[-.50,-.68],[-1.55,-1.48]],.12,.29,sleeve,3);
    m.prism([[-1.36,-.34],[-.77,-.26],[-.53,-.54],[-1.10,-.78]],.24,.30,glove,3);
    m.box(-1.16,-.65,.39,.57,.13,.04,gloveTrim,2);
    for(let i=0;i<3;i++)m.box(-.80+i*.12,-.39-i*.07,.41,.10,.28,.10,glove,3);
  }
  function geometry(item){
    const name=item.name||'';const m=new Mesh(colors(item));
    const category=(item.category||'').toLowerCase();
    if(category.includes('luva')||name.toLowerCase().includes('glove'))buildGloves(m,name);
    else if(category.includes('faca')||/knife|bayonet|dagger|karambit|talon/.test(name.toLowerCase()))buildKnife(m,name);
    else if(/pistol|desert|usp|glock|p250|tec-9|five-seven|cz75|revolver/.test(name.toLowerCase())||category.includes('pistola'))buildPistol(m,name);
    else buildRifle(m,name);
    if(firstPerson)addFirstPersonHands(m,category);
    return new Float32Array(m.data);
  }
  function updateMesh(){ if(!selected)return;const data=geometry(selected);meshData=data;vertexCount=data.length/10;if(!gl)return;gl.bindBuffer(gl.ARRAY_BUFFER,buffers.mesh);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);
    for(const [loc,size,offset] of [[positionLoc,3,0],[normalLoc,3,12],[colorLoc,3,24],[materialLoc,1,36]]){
      if(loc<0)continue;gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,40,offset);
    }
  }
  function selectSkin(id){
    const item=all.find(it=>it.id===id);if(!item)return;
    if(!allowed()){window.NoukGate && window.NoukGate.lock('Ative sua KEY antes de selecionar uma skin.');return;}
    selected=item;localStorage.setItem('nouk_lab_selection',item.id);
    $('labName').textContent=item.name;
    $('labCategory').textContent=`${item.category} • Modelo 3D ilustrativo (não é o objeto original)`;
    $('labSource').textContent=sourceName(item);
    const ref=$('labReference');if(item.image){ref.src=item.image;ref.classList.remove('hide');}else{ref.removeAttribute('src');ref.classList.add('hide');$('labSource').textContent='Sem imagem confirmada — apenas renderização ilustrativa.';}
    yaw=-.29;pitch=-.16;zoom=48;$('labZoom').value='48';$('labZoomValue').textContent='48%';
    updateMesh();updateFav();searchResults(false);
    $('labEquipState').textContent='PRONTA PARA EQUIPAR';
    equipMessage('Skin selecionada. Toque em EQUIPAR NO LABORATÓRIO para confirmar a troca visual.');
  }
  function updateFav(){if(!selected)return;const on=faved().has(selected.id);$('labFav').textContent=on?'★ FAVORITA':'☆ FAVORITAR';$('labFav').classList.toggle('secondary',!on);}
  function toggleFav(){if(!selected)return;const set=faved();if(set.has(selected.id))set.delete(selected.id);else set.add(selected.id);localStorage.setItem('nouk_favorites',JSON.stringify([...set]));updateFav();window.dispatchEvent(new Event('nouk:favorites-changed'));}
  function normalizeSearch(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
  function searchResults(focus){
    const q=normalizeSearch($('labSearch').value),list=q?all.filter(x=>normalizeSearch(`${x.name} ${x.id} ${x.category}`).includes(q)).slice(0,35):[];
    $('labResults').innerHTML=q?(list.length?list.map(x=>`<button class="lab-result ${selected&&selected.id===x.id?'selected':''}" data-lab-id="${esc(x.id)}">${x.image?`<img src="${esc(x.image)}" loading="lazy" alt="">`:'<span style="display:grid;place-items:center;width:62px;height:45px">◈</span>'}<span>${esc(x.name)}<small>${esc(x.category)}</small></span></button>`).join(''):'<p class="soft">Nenhuma skin encontrada.</p>'):'';
    if(focus) $('labResults').scrollTop=0;
  }
  function cameraProjection(aspect){const f=1/Math.tan(Math.PI/6),near=.1,far=100;return new Float32Array([f/aspect,0,0,0, 0,f,0,0, 0,0,(far+near)/(near-far),-1, 0,0,(2*far*near)/(near-far),0]);}
  function drawSoftware(time,w,h){
    if(!softCtx||!meshData)return;
    const ctx=softCtx;ctx.clearRect(0,0,w,h);
    const dist=8.3-(zoom/100)*4.6,ya=yaw+(firstPerson?.45:0),pi=pitch+(firstPerson?-.25:0),ro=firstPerson?-.20:0;
    const cy=Math.cos(ya),sy=Math.sin(ya),cx=Math.cos(pi),sx=Math.sin(pi),cz=Math.cos(ro),sz=Math.sin(ro);
    function transform(x,y,z,normal){let a=cy*x+sy*z,b=y,c=-sy*x+cy*z;let ny=cx*b-sx*c,nz=sx*b+cx*c;return [cz*a-sz*ny,sz*a+cz*ny,nz];}
    const project=(p)=>{const q=transform(...p);q[0]+=firstPerson?.72:0;q[1]+=firstPerson?-.44:0;
      const d=Math.max(0.5,dist-q[2]),factor=Math.min(w,h)*1.68/d;return [w*.5+q[0]*factor,h*.50-q[1]*factor,d];};
    let faces=[];
    for(let i=0;i<meshData.length;i+=30){
      const pts=[],a=[];for(let k=0;k<3;k++){const off=i+k*10;const v=[meshData[off],meshData[off+1],meshData[off+2]];pts.push(project(v));a.push(v);}
      const na=transform(meshData[i+3],meshData[i+4],meshData[i+5],true);
      const diffuse=Math.max(0,na[0]*-.40+na[1]*.70+na[2]*.70);
      let shade=.41+diffuse*.70;
      const color=[meshData[i+6],meshData[i+7],meshData[i+8]].map(c=>Math.min(255,Math.max(0,Math.round(c*255*shade))));
      faces.push({pts,color,z:(pts[0][2]+pts[1][2]+pts[2][2])/3});
    }
    faces.sort((a,b)=>b.z-a.z);
    for(const f of faces){ctx.beginPath();ctx.moveTo(f.pts[0][0],f.pts[0][1]);ctx.lineTo(f.pts[1][0],f.pts[1][1]);ctx.lineTo(f.pts[2][0],f.pts[2][1]);ctx.closePath();ctx.fillStyle=`rgb(${f.color.join(',')})`;ctx.fill();ctx.strokeStyle='rgba(255,255,255,.065)';ctx.lineWidth=.5;ctx.stroke();}
  }
  function draw(time){
    if((!gl&&!softCtx) || !selected)return;
    if($('page-lab').classList.contains('hide') || document.hidden)return;
    const cvs=$('labCanvas'),rect=cvs.getBoundingClientRect();if(rect.width<1||rect.height<1)return;
    const dpr=clamp(window.devicePixelRatio||1,1,2);const w=Math.floor(rect.width*dpr),h=Math.floor(rect.height*dpr);
    if(cvs.width!==w||cvs.height!==h){cvs.width=w;cvs.height=h;}
    if(time<inspectUntil)yaw+=Math.min((time-lastFrame)/1000,.05)*1.45;
    if(!gl){drawSoftware(time,w,h);lastFrame=time;return;}gl.viewport(0,0,w,h);
    gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(shader);
    gl.uniformMatrix4fv(uniforms.proj,false,cameraProjection(w/h));
    const zoomDistance=8.3-(zoom/100)*4.6;
    gl.uniform1f(uniforms.yaw,yaw+(firstPerson?.45:0));
    gl.uniform1f(uniforms.pitch,pitch+(firstPerson?-.25:0));
    gl.uniform1f(uniforms.roll,firstPerson?-.20:0);
    gl.uniform3f(uniforms.offset,firstPerson?.72:0,firstPerson?-.44:0,-zoomDistance);
    gl.uniform1f(uniforms.time,time/1000);gl.uniform1f(uniforms.pattern,(selected.name.length*1.47)%12.0);
    gl.drawArrays(gl.TRIANGLES,0,vertexCount);
    lastFrame=time;
  }
  function frame(t){try{draw(t);}catch(e){if(!renderError){renderError=String(e);fallback('Falha na renderização 3D; veja a miniatura original abaixo.')}}requestAnimationFrame(frame);}
  function bindTouch(){
    const c=$('labCanvas');const positions=new Map();let lastPinch=null;
    c.addEventListener('pointerdown',e=>{
      positions.set(e.pointerId,[e.clientX,e.clientY]);
      if(c.setPointerCapture)c.setPointerCapture(e.pointerId);
    });
    c.addEventListener('pointermove',e=>{
      if(!positions.has(e.pointerId))return;
      const old=positions.get(e.pointerId);positions.set(e.pointerId,[e.clientX,e.clientY]);
      const pts=[...positions.values()];
      if(pts.length===1){yaw+=(e.clientX-old[0])*.009;pitch=clamp(pitch+(e.clientY-old[1])*.008,-1.25,1.25);lastPinch=null;}
      else if(pts.length>=2){
        const d=Math.hypot(pts[0][0]-pts[1][0],pts[0][1]-pts[1][1]);
        if(lastPinch!==null){zoom=clamp(zoom+(d-lastPinch)*.22,1,100);$('labZoom').value=zoom;$('labZoomValue').textContent=Math.round(zoom)+'%';}
        lastPinch=d;
      }
    });
    const finish=e=>{positions.delete(e.pointerId);lastPinch=null;};
    c.addEventListener('pointerup',finish);c.addEventListener('pointercancel',finish);
    c.addEventListener('wheel',e=>{e.preventDefault();zoom=clamp(zoom-(e.deltaY*.08),1,100);$('labZoom').value=zoom;$('labZoomValue').textContent=Math.round(zoom)+'%';},{passive:false});
  }
  function chooseFirst(){
    const prev=localStorage.getItem('nouk_lab_selection');
    const item=all.find(x=>x.id===prev)||all.find(x=>/butterfly.*marble/.test(x.id))||all.find(x=>x.image)||all[0];
    if(item)selectSkin(item.id);
  }
  function init(){
    if(!$('labCanvas'))return;
    initializeGL();bindTouch();chooseFirst();
    $('labFav').onclick=toggleFav;
    try{const stored=android?JSON.parse(Charge.labSelection()):null;finish=(stored&&stored.finish)||localStorage.getItem('nouk_lab_finish')||'original';}catch(e){finish='original'}
    updateFinishUI();updateMesh();
    document.querySelectorAll('[data-finish]').forEach(b=>b.addEventListener('click',()=>{
      if(!allowed()){window.NoukGate && window.NoukGate.lock('A KEY venceu ou não foi ativada.');return;}
      const newFinish=b.dataset.finish;
      if(android){const result=Charge.applyFinish(newFinish);if(result!=='OK'){equipMessage('Falha ao aplicar: '+result,true);return;}}
      finish=newFinish;localStorage.setItem('nouk_lab_finish',finish);updateFinishUI();updateMesh();
      equipMessage('Material aplicado ao modelo 3D: '+b.textContent+'. Alteração feita apenas no laboratório.');
    }));
    $('labEquip').onclick=()=>{
      if(!selected)return;
      if(!allowed()){window.NoukGate && window.NoukGate.lock('Ative a KEY NOUK antes de equipar.');return;}
      if(android){const result=Charge.equipSkin(selected.id);if(result!=='OK'){equipMessage('Falha ao equipar: '+result,true);return;}}
      localStorage.setItem('nouk_equipped_skin',selected.id);$('labEquipState').textContent='EQUIPADA NO LAB';
      equipMessage('EQUIPADA NO LAB: '+selected.name+' ('+finish.toUpperCase()+'). A visualização 3D foi atualizada.');
    };
    $('labSearch').addEventListener('input',()=>searchResults(true));
    $('labResults').addEventListener('click',e=>{const target=e.target.closest('[data-lab-id]');if(!target)return;selectSkin(target.dataset.labId);$('labSearch').value='';searchResults(false);$('labCanvas').scrollIntoView({behavior:'smooth',block:'center'});});
    const quick=['butterfly_marblefade','karambit_lore','awp_dragonlore','gloves_pandorabox','bayonet_gammadoppler','skeleton_fade','m9bayonet_lore'];
    const examples=quick.map(id=>all.find(x=>x.id===id||x.id.includes(id))).filter(Boolean);
    if(examples.length<4)examples.push(...all.filter(x=>x.image).slice(0,6-examples.length));
    $('labQuick').innerHTML=examples.map(x=>`<button data-quick-id="${esc(x.id)}">${esc(x.name)}</button>`).join('');
    $('labQuick').onclick=e=>{const b=e.target.closest('[data-quick-id]');if(b)selectSkin(b.dataset.quickId);};
    $('labZoom').oninput=e=>{zoom=+e.target.value;$('labZoomValue').textContent=zoom+'%'};
    $('labFirstPerson').onclick=()=>{firstPerson=!firstPerson;updateMesh();$('labFirstPerson').textContent=firstPerson?'◉ VISÃO LIVRE':'◉ 1ª PESSOA';$('labViewLabel').textContent=firstPerson?'1ª PESSOA · SIMULAÇÃO':(gl?'3D LIVRE':'3D SOFTWARE');};
    $('labInspect').onclick=()=>{inspectUntil=performance.now()+2500;};
    $('labReset').onclick=()=>{yaw=-.28;pitch=-.16;zoom=48;firstPerson=false;inspectUntil=0;$('labZoom').value='48';$('labZoomValue').textContent='48%';$('labFirstPerson').textContent='◉ 1ª PESSOA';$('labViewLabel').textContent=gl?'3D LIVRE':'3D SOFTWARE';updateMesh();};
    window.addEventListener('nouk:lab-favorites-sync',updateFav);
    requestAnimationFrame(frame);
  }
  window.openLabItem=id=>{const tab=document.querySelector('#nav button[data-page="lab"]');if(tab)tab.click();selectSkin(id);window.scrollTo({top:0,behavior:'smooth'});};
  window.SkinLab={select:selectSkin,activate:()=>{if(!selected)chooseFirst();},get selected(){return selected},hasWebGL:()=>!!gl};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
