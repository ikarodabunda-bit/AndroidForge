// SkinLab 5.1 — C++17 local-preview state ONLY.
// No reading, injecting, changing offsets, or modifying a third-party process.
#include <jni.h>
#include <array>
#include <mutex>
#include <string>
#include <sstream>

namespace {
constexpr int kCount=20;
std::array<bool,kCount> recentlyApplied{};
std::mutex stateLock;
int mostRecent=-1;
unsigned int edits=0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_skinforgex_NativeCore_applyLocalPreview(JNIEnv* env, jclass, jint itemId) {
    std::lock_guard<std::mutex> guard(stateLock);
    if(itemId<0 || itemId>=kCount) return env->NewStringUTF("INVALID_ITEM");
    mostRecent=itemId;
    recentlyApplied[static_cast<size_t>(itemId)]=true;
    ++edits;
    std::ostringstream stream;
    stream << "LOCAL_PREVIEW_OK:" << itemId;
    return env->NewStringUTF(stream.str().c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_dev_skinforgex_NativeCore_clearSelections(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> guard(stateLock);
    recentlyApplied.fill(false);
    mostRecent=-1;
    ++edits;
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_skinforgex_NativeCore_summary(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> guard(stateLock);
    std::ostringstream stream;
    stream << "C++17 / JNI · " << edits << " operações locais";
    return env->NewStringUTF(stream.str().c_str());
}
