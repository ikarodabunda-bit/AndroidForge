package dev.skinforgex;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;
import org.json.JSONObject;

/** Only Android package discovery and foreground usage events. NOT a process attach. */
public final class GameDetector {
    private GameDetector() {}
    public static final String GAME = "com.axlebolt.standoff2";

    public static boolean hasUsageAccess(Context context) {
        AppOpsManager ops = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public static boolean installed(Context context) {
        try { context.getPackageManager().getPackageInfo(GAME, 0); return true; }
        catch (PackageManager.NameNotFoundException ex) { return false; }
    }

    public static boolean inForeground(Context context) {
        if (!hasUsageAccess(context)) return false;
        UsageStatsManager mgr=(UsageStatsManager)context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (mgr==null) return false;
        // Search a recent period, using the most recent resume/pause event of this package.
        long now=System.currentTimeMillis();
        UsageEvents events=mgr.queryEvents(now-10*60*1000L, now);
        if(events==null) return false;
        UsageEvents.Event event=new UsageEvents.Event();
        boolean foreground=false, seen=false;
        while(events.hasNextEvent()) {
            events.getNextEvent(event);
            if(!GAME.equals(event.getPackageName())) continue;
            int t=event.getEventType();
            if(t==UsageEvents.Event.MOVE_TO_FOREGROUND || t==UsageEvents.Event.ACTIVITY_RESUMED) {
                foreground=true;seen=true;
            } else if (t==UsageEvents.Event.MOVE_TO_BACKGROUND || t==UsageEvents.Event.ACTIVITY_PAUSED
                    || t==UsageEvents.Event.ACTIVITY_STOPPED) {
                foreground=false;seen=true;
            }
        }
        return seen && foreground;
    }

    public static String statusJson(Context context) {
        JSONObject data=new JSONObject();
        try {
            boolean permit=hasUsageAccess(context), found=installed(context);
            data.put("permission",permit);
            data.put("installed",found);
            data.put("running",found && permit && inForeground(context));
            data.put("kind","foreground-usage-signal");
        } catch(Exception ignored) {}
        return data.toString();
    }
}
