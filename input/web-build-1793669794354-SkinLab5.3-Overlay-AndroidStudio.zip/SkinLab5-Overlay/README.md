# SkinLab 5.3 — sobreposição para Standoff 2 (versão de teste)

## O que funciona no código
- **JOGO + PAINEL**: solicita permissão de sobreposição caso necessário, inicia o serviço flutuante e abre o pacote `com.axlebolt.standoff2` se instalado.
- **Detecção de jogo**: com permissão *Acesso de uso*, exibe quando o Android relata o Standoff 2 em primeiro plano. **Não significa injeção/conexão a um processo.**
- **Ocultar sem bloquear**: remove a superfície visível do overlay com `View.GONE`, deixando os toques chegarem ao jogo. Restaure pela ação **Mostrar painel** na notificação persistente ou reabra o SkinLab e toque em **ABRIR OVERLAY**, mesmo que tenha negado notificações.
- **Bolha**: minimizar/restaurar, arrastar e painel compacto. Ao pesquisar, o teclado pede foco temporário; fora da pesquisa, a janela flutuante não toma foco.
- **Galeria**: 268 texturas originais ASTC extraídas das amostras fornecidas (se WebGL ASTC estiver disponível no aparelho). Configurações e favoritos são locais.
- **C++17/JNI**: registra apenas seleções de prévias locais. Não lê memória de terceiros.

## Como compilar
### Com Android Studio
- Abra `SkinLab5-Overlay` em um Android Studio moderno.
- Instale Android SDK Platform **35**, Android NDK e CMake pelo SDK Manager.
- `Build > Build APK(s)`. Instale o APK gerado em `app/build/outputs/apk/debug/app-debug.apk`.
- Por conta do serviço de notificação, conceda as permissões Android solicitadas, especialmente *Mostrar sobre outros apps*. O acesso de uso é opcional para status.
- Abra SkinLab -> **▶ JOGO + PAINEL**. Com o jogo aberto, teste tocar fora da janela, minimizar, ocultar e restaurar pela notificação.

### Somente com celular (sem Android Studio)
- O projeto inclui `.github/workflows/build-android.yml`, que gera um APK debug em GitHub Actions com o SDK/NDK disponíveis no runner. É necessário importar os arquivos para um repositório GitHub e acionar `Actions > Build SkinLab Android APK > Run workflow`; após concluir, baixar o artefato `skinlab53-debug-apk`.
- Não foi compilado neste ambiente, pois não há Android SDK/Gradle disponíveis. O workflow é uma receita de build, não uma garantia de compilação sem ajustes.

## O que não funciona
- **Não altera skins no jogo, inventário, progresso ou dados de servidores.** O botão Aplicar salva uma prévia **no próprio SkinLab**, não no Standoff 2.
- **Não é uma modificação/reassinatura do APK do jogo**, nem um injector ou bypass de integridade/anti-cheat. A flag `-insecure` não concede privilégios de memória do Android.
- A compatibilidade de sobreposição e ASTC depende do aparelho e da configuração do Android.

## Teste de aceite no aparelho
1. Standoff 2 instalado e aberto pelo botão.
2. Painel aparece sobre a tela sem fazer o jogo fechar.
3. Toques fora do painel continuam indo para o jogo.
4. Minimize para bolha; arraste; restaure.
5. Ocultar faz o overlay desaparecer e permite tocar na tela inteira; restaure pela notificação.
6. Entre em **Compatibilidade** e confirme status de jogo após conceder *Acesso de uso*.
7. Veja se as miniaturas ASTC renderizam no Android WebView.
