plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.noukzxx.keys"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.noukzxx.keynouk.issuer.standalone26"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "3.0.0-keynouk"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
