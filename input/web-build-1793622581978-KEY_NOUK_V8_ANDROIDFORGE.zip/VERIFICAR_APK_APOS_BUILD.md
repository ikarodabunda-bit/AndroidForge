# Como confirmar que o AndroidForge compilou o projeto certo

**Projeto:** KEY NOUK

**ID esperado:** `com.noukzxx.keynouk.issuer.standalone26`

1. Envie **somente este ZIP individual** pelo AndroidForge, escolha `debug`.
2. Após baixar o APK, confira seu identificador. Com Android SDK Build Tools, execute:

   `aapt dump badging seu-app.apk | grep package:`

   Alternativa: `apkanalyzer manifest application-id seu-app.apk`.

3. O ID retornado deve ser exatamente `com.noukzxx.keynouk.issuer.standalone26`. Caso apareça outro, o AndroidForge usou o arquivo errado ou um artefato antigo.
4. Para não confundir os downloads, renomeie **o arquivo APK baixado** para `KEY_NOUK_STANDALONE_V3.apk` (renomear o arquivo não altera o pacote Android).

**Observação:** os ZIPs contêm fontes, não APKs compilados.
