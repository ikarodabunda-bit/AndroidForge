# KEY NOUK v6 — By:Noukzxx

Projeto Android separado para o AndroidForge, com `applicationId=com.noukzxx.keynouk.issuer.standalone26`.

Funcionalidades de emissão local com assinatura ECDSA usando Android Keystore: 1, 7, 31 dias ou permanente; histórico local; copiar, compartilhar e enviar a licença diretamente para o ChargeSkin v4/v5/v6, que pede confirmação.

**Como instalar:** compile este ZIP **individualmente** em debug; instale o APK. Na aba Emissor, escolha PAREAR NO CHARGESKIN. Depois gere uma licença e toque em ATIVAR NO CHARGESKIN.

**Segurança:** qualquer pessoa que consiga usar o app emissor no seu Android poderá emitir licenças. O protótipo offline não permite revogação remota ou controle de dispositivos; não adequado para vendas sem servidor/autenticação.

Não modifica jogos, não desbloqueia skins no Counter Flame e não contém bypass. Sem compilação de APK no ambiente de criação; precisa AndroidForge e teste no aparelho.
