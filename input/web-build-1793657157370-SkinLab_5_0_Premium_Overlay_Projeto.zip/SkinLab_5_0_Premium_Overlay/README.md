# SKINLAB 5.0 — PREMIUM OVERLAY (ANDROID / C++17)

Projeto-fonte Android com painel visual inspirado na captura enviada pelo usuário: tema preto/vermelho, navegação lateral, catálogo em grade, prévia ampliada, busca, filtros e restauração de preferências. **20 opções** (19 miniaturas extraídas das capturas do usuário + AK-47 padrão). A interface HTML/JS também funciona como prévia autônoma no navegador. O núcleo de catálogo e seleção é C++17 e a comunicação com Android usa JNI.

## Estado real do projeto

- **Executado e verificado neste ambiente:** núcleo C++ compilado e testes de seleção, restauração, identificação e JSON; interface HTML executada no Chromium com ponte Android simulada e testada; arquivos de imagem, manifest e dados catalogados.
- **Não executado aqui:** Gradle/Android SDK/NDK não estão disponíveis neste ambiente. Não foi gerado nem testado APK desta versão. O projeto está pronto para compilar em um ambiente Android Studio ou AndroidIDE com toolchain instalado.
- **Não implementado:** nenhuma alteração de modelos/materiais dentro do CounterFlame. Botão Aplicar salva somente a prévia local do SkinLab. Overlay Android pode ser impedido por ROM/jogo.

## Como usar no celular sem PC

### Prévia imediata — Termux

1. Extraia este ZIP em `Download/SkinLab_5_0_Premium_Overlay` com ZArchiver.
2. No Termux execute:

```bash
pkg install python -y
cd ~/storage/downloads/SkinLab_5_0_Premium_Overlay
bash preview_termux.sh
```

3. Abra no Chrome `http://127.0.0.1:8989/`.

A prévia contém todos os itens, busca, filtros, botão Aplicar Prévia, botão Restaurar e configurações. Ela **não** desenha um overlay sobre outro app; isso só existe na build nativa Android.

### Gerar APK no próprio Android

1. Instale um IDE Android com SDK, NDK, CMake, JDK 17 e Gradle compatível (por exemplo AndroidIDE, se o ambiente atender aos requisitos).
2. Importe a pasta `SkinLab_5_0_Premium_Overlay` como projeto Gradle.
3. Faça Gradle sync. O projeto pede Android SDK Platform 35, NDK e CMake; usa `com.android.tools.build:gradle:8.7.3` e Gradle 8.9.
4. Compile `app:assembleDebug`. O APK de desenvolvimento estará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale; autorize **Exibir sobre outros aplicativos** e toque em **ATIVAR OVERLAY**. Inicie o CounterFlame e teste apenas a visualização do painel flutuante.

**Observação:** a versão do Gradle deve ser disponibilizada pela IDE; este ZIP não inclui o binário wrapper. O APK de depuração não altera o jogo instalado e não substitui o pacote oficial.

## Arquitetura

```
app/src/main/
├── assets/panel/index.html       # UI premium, responsiva e offline
├── assets/panel/images/          # Miniaturas das capturas do usuário
├── cpp/skin_core.cpp             # Catálogo, seleção e restauração nativa
├── cpp/native_bridge.cpp         # JNI para Android
├── java/.../MainActivity.java    # Janela inicial estável e ativação manual
├── java/.../OverlayService.java  # Bolha e painel Android WindowManager
├── java/.../PanelBridge.java     # Exposição restrita de ações à UI local
└── AndroidManifest.xml           # Permissões apenas de overlay e foreground service
```

## Modo de compatibilidade / integridade

Este modo é **transparente**, e **não é bypass de anticheat**. O aplicativo:

- usa as APIs Android `SYSTEM_ALERT_WINDOW`/`WindowManager` com permissão explícita;
- inicia o overlay somente após o usuário pedir;
- oferece notificação com ação para parar o serviço;
- não modifica o APK do CounterFlame, não lê memória, não injeta bibliotecas, não esconde processos e não toca no inventário ou na rede do jogo;
- pode ser fechado antes de partidas caso a plataforma não permita sobreposições.

Isso **não garante ausência de restrições ou punições**. Apenas o desenvolvedor do jogo pode confirmar quais sobreposições e modificações são permitidas. Não há funcionalidade de evasão do anticheat no projeto.

## Testes

Núcleo nativo no Linux/Termux:

```bash
c++ -std=c++17 -Wall -Wextra -Werror \
    app/src/main/cpp/skin_core.cpp tests/test_core.cpp -o skinlab_core_tests
./skinlab_core_tests
```

A interface foi verificada em Chromium com simulação explícita da ponte `SkinLabAndroid`: seleção, restauração, busca, navegação, filtros e controles de configuração. Não substitui teste do APK em um celular real.
