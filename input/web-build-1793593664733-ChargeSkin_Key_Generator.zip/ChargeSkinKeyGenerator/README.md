ChargeSkin Key Generator — projeto Android Kotlin para AndroidIDE.

Importe a pasta no AndroidIDE e compile o app. Gere uma KEY e cole no ChargeSkin Cyber Purple v3. Ambos usam o mesmo formato HMAC de demonstração.

ATENÇÃO: é um protótipo offline para testes. Como o segredo é incluído no código dos apps, não oferece proteção real contra falsificação. Para produção, use servidor de licenças ou assinatura assimétrica com chave privada protegida fora do app cliente.
