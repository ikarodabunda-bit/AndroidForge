package com.chargeskin.keygen

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
 private val purple=Color.rgb(185,75,255); private lateinit var keyView:TextView; private lateinit var history:TextView
 private val items=mutableListOf<String>(); private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); window.statusBarColor=Color.rgb(9,7,18); window.navigationBarColor=Color.rgb(9,7,18)
 val root=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(dp(22),dp(24),dp(22),dp(24));background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(8,7,18),Color.rgb(42,12,65)))}
 root.addView(txt("C H A R G E S K I N",13f,purple,true));root.addView(txt("KEY GENERATOR",29f,Color.WHITE,true).apply{setPadding(0,dp(8),0,dp(6))});root.addView(txt("GERADOR DE CHAVES • CYBER PURPLE",12f,Color.LTGRAY,false).apply{setPadding(0,0,0,dp(26))})
 val card=LinearLayout(this).apply{orientation=1;setPadding(dp(18),dp(20),dp(18),dp(20));background=GradientDrawable().apply{setColor(Color.rgb(20,15,31));cornerRadius=dp(20).toFloat();setStroke(dp(1),purple)}}
 card.addView(txt("SUA NOVA KEY",14f,Color.LTGRAY,true));keyView=txt("Nenhuma KEY gerada",18f,Color.WHITE,true).apply{setPadding(0,dp(18),0,dp(18))};card.addView(keyView)
 card.addView(btn("⚡  GERAR KEY",purple){val k=generate();keyView.text=k;items.add(0,k);history.text=items.take(10).joinToString("\n");Toast.makeText(this,"KEY criada! Copie e cole no ChargeSkin.",Toast.LENGTH_LONG).show()})
 card.addView(btn("COPIAR KEY",Color.rgb(75,42,103)){val k=keyView.text.toString();if(k.startsWith("CS-")){(getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ChargeSkin KEY",k));Toast.makeText(this,"KEY copiada",Toast.LENGTH_SHORT).show()}else Toast.makeText(this,"Gere uma KEY primeiro",Toast.LENGTH_SHORT).show()})
 card.addView(txt("Histórico desta sessão",14f,Color.WHITE,true).apply{setPadding(0,dp(20),0,dp(8))});history=txt("As chaves geradas aparecerão aqui.",12f,Color.LTGRAY,false);card.addView(history);root.addView(card,LinearLayout.LayoutParams(-1,-2));root.addView(txt("Modo de teste offline. Não use para licenciamento comercial: o segredo está no código dos dois apps.",11f,Color.LTGRAY,false).apply{gravity=Gravity.CENTER;textAlignment=TextView.TEXT_ALIGNMENT_CENTER;setPadding(0,dp(18),0,0)});setContentView(root)
 }
 private fun generate():String{val id=java.util.UUID.randomUUID().toString().replace("-","").uppercase().take(12);return "CS-$id-${sign(id)}"}
 private fun sign(id:String):String{val mac=Mac.getInstance("HmacSHA256");mac.init(SecretKeySpec("ChargeSkin-CyberPurple-TEST-SECRET-2026".toByteArray(),"HmacSHA256"));return mac.doFinal(id.toByteArray()).joinToString(""){ "%02X".format(it)}.take(12)}
 private fun txt(t:String,s:Float,c:Int,b:Boolean)=TextView(this).apply{text=t;textSize=s;setTextColor(c);if(b)setTypeface(typeface,Typeface.BOLD)}
 private fun btn(t:String,c:Int,action:()->Unit)=Button(this).apply{text=t;isAllCaps=false;setTextColor(Color.WHITE);background=GradientDrawable().apply{setColor(c);cornerRadius=dp(12).toFloat()};setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(9)}}
}
