# SkinLab 3.4 — C++17 + JNI + Android Overlay

**Status:** projeto-fonte pronto para compilar em Android Studio. O núcleo C++ e a ponte JNI foram compilados e testados em ambiente de desenvolvimento Linux; o projeto Android ainda **não** foi compilado nem executado em um aparelho físico, pois o Android SDK/NDK não estava disponível neste ambiente. **Este pacote não é um APK.**

## Objetivo

Corrigir a arquitetura que causou crashes no SkinLab 3.0, 3.1 e 3.3. A versão 3.2 abriu e permitiu selecionar/restaurar skins no Android do usuário. O 3.4 substitui a geração manual de classes.dex por um projeto Gradle padrão. A lógica de catálogo/seleção é C++17 nativo (biblioteca libskinlab.so), com JNI; a Activity e o serviço flutuante são Java Android, indispensáveis para obter permissão e usar WindowManager.

**Não injeta no CounterFlame, não acessa sua memória nem altera texturas, inventário ou arquivos do jogo.** O botão «APLICAR PRÉVIA» somente salva a preferência no aplicativo. A sobreposição pode ser bloqueada pelo jogo/Android.

## Compilar APK (Android Studio)

1. Abra a pasta `SkinLab_3_4_CppOverlay` em Android Studio (File > Open).
2. Instale pelo SDK Manager: Android SDK Platform 35, NDK (Side by side) e CMake.
3. Faça Gradle Sync (AGP 8.7.3; Gradle 8.9 com JDK 17).
4. Se Android Studio solicitar uma configuração de wrapper Gradle, use Gradle 8.9; este projeto não inclui wrapper binário.
5. Build > Build APK(s), variante `debug`.
6. APK compilado: `app/build/outputs/apk/debug/app-debug.apk`.
7. Instale no Android (8.0+), abra o app, toque em ATIVAR MENU FLUTUANTE, conceda a permissão, volte, toque de novo, abra o CounterFlame e teste a bolha.

> Se não houver Android Studio no computador, o projeto pode ser aberto no AndroidIDE que tenha SDK/NDK/Gradle instalados. Não há APK pré-compilado neste pacote.

## Teste C++ local (incluindo Termux)

```
clang++ -std=c++17 -Wall -Wextra -pthread \
  app/src/main/cpp/skin_core.cpp tests/test_core.cpp -o test_core
./test_core
```

Saída esperada: `PASS: catalog=19, selection, invalid id, restore, JSON`.

## Diagnóstico de crash Android

Se a nova build travar, com ADB:

```
adb logcat -c
adb shell am start -n com.skinlab.cppoverlay/.MainActivity
adb logcat -d -v time AndroidRuntime:E SkinLab:E '*:S'
```

Também é possível executar `logcat` pelo Termux (quando o aparelho fornece acesso a logs) ou o painel Logcat do Android Studio. Informe a linha com `FATAL EXCEPTION` e as linhas `Caused by`.

## Estrutura

- `app/src/main/cpp/skin_core.cpp`: catálogo e seleção em C++17 com mutex.
- `app/src/main/cpp/native_bridge.cpp`: interfaces JNI para Android.
- `app/src/main/java/com/skinlab/cppoverlay/NativeCore.java`: carregamento da biblioteca.
- `app/src/main/java/com/skinlab/cppoverlay/SkinStore.java`: persistência de preferência.
- `app/src/main/java/com/skinlab/cppoverlay/MainActivity.java`: tela inicial e permissão.
- `app/src/main/java/com/skinlab/cppoverlay/OverlayService.java`: bolha/painel com WindowManager.
- `app/src/main/res/drawable-nodpi/`: 19 miniaturas extraídas das capturas fornecidas.

## Verificações realizadas

- Núcleo C++ compilado com `-Wall -Wextra -Werror`.
- Testes nativos passaram: 19 itens, seleção, rejeição de ID inválido, restauração e exportação JSON.
- Ponte JNI compilada em ambiente Linux com cabeçalhos JNI JDK (verificação sintática e de tipos, **não** biblioteca Android).
- AndroidManifest.xml parseado com sucesso.
- **Não verificados:** build APK, ABI arm64-v8a no NDK, permissão real de overlay, interação com CounterFlame.
