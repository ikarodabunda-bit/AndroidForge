#include <jni.h>
#include <string>
#include "skin_core.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_skinlab_cppoverlay_NativeCore_catalogJson(JNIEnv* env, jclass) {
  return env->NewStringUTF(skinlab::catalogJson().c_str());
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_skinlab_cppoverlay_NativeCore_select(JNIEnv* env, jclass, jstring key) {
  if (!key) return JNI_FALSE;
  const char* utf=env->GetStringUTFChars(key,nullptr);
  if (!utf) return JNI_FALSE;
  const bool ok=skinlab::select(utf);
  env->ReleaseStringUTFChars(key,utf);
  return ok?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_skinlab_cppoverlay_NativeCore_selected(JNIEnv* env, jclass) {
  return env->NewStringUTF(skinlab::selected().c_str());
}
extern "C" JNIEXPORT void JNICALL
Java_com_skinlab_cppoverlay_NativeCore_restore(JNIEnv*, jclass) {
  skinlab::restore();
}
