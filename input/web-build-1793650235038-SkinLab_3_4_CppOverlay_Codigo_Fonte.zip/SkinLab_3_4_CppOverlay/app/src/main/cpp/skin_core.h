#pragma once
#include <string>
#include <vector>

namespace skinlab {
struct Skin { const char* id; const char* weapon; const char* title; const char* category; };
const std::vector<Skin>& catalog();
std::string catalogJson();
bool select(const std::string& id);
std::string selected();
void restore();
bool isValid(const std::string& id);
}
