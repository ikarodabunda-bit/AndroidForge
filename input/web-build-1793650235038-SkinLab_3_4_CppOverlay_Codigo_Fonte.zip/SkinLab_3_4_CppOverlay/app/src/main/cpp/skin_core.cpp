#include "skin_core.h"
#include <mutex>
#include <sstream>

namespace skinlab {
namespace {
std::mutex stateMutex;
std::string active="ak-vulcan";
const std::vector<Skin> skins={
 {"ak-vulcan","AK-47","Vulcan","Armas"},
 {"ak-gold","AK-47","Gold Arabesque","Armas"},
 {"ak-neon","AK-47","Neon Revolution","Armas"},
 {"ak-aquamarine","AK-47","Aquamarine","Armas"},
 {"ak-fireserpent","AK-47","Fire Serpent","Armas"},
 {"ak-wild","AK-47","Wild Lotus","Armas"},
 {"ak-fuel","AK-47","Fuel Injector","Armas"},
 {"ak-empress","AK-47","Empress","Armas"},
 {"m4a4-how1","M4A4","Howl","Armas"},
 {"m4a4-neo","M4A4","Neo-Noir","Armas"},
 {"m4s-print","M4A1-S","Printstream","Armas"},
 {"m4s-hotrod","M4A1-S","Hot Rod","Armas"},
 {"awp-dragon","AWP","Dragon Lore","Armas"},
 {"awp-gungnir","AWP","Gungnir","Armas"},
 {"deagle-print","Desert Eagle","Printstream","Armas"},
 {"deagle-blaze","Desert Eagle","Blaze","Armas"},
 {"glove-vice","Luvas","Vice","Luvas"},
 {"glove-pandora","Luvas","Pandora Box","Luvas"},
 {"knife-butterfly","Butterfly Knife","Emerald","Facas"}
};
std::string escape(const char* value) {
  std::ostringstream out;
  for (const char* p=value; *p; ++p) {
    switch (*p) {
      case '\\': out<<"\\\\"; break;
      case '"': out<<"\\\""; break;
      case '\n': out<<"\\n"; break;
      default: out<<*p;
    }
  }
  return out.str();
}
}
const std::vector<Skin>& catalog() { return skins; }
bool isValid(const std::string& id) {
  for(const auto& s:skins) if(id==s.id) return true;
  return false;
}
bool select(const std::string& id) {
  if(!isValid(id)) return false;
  std::lock_guard<std::mutex> guard(stateMutex);
  active=id;
  return true;
}
std::string selected() {
  std::lock_guard<std::mutex> guard(stateMutex);
  return active;
}
void restore() {
  std::lock_guard<std::mutex> guard(stateMutex);
  active="ak-vulcan";
}
std::string catalogJson() {
  std::ostringstream out;
  out<<'[';
  for(size_t i=0;i<skins.size();++i) {
    if(i) out<<',';
    const auto& s=skins[i];
    out<<"{\"id\":\""<<escape(s.id)<<"\",\"weapon\":\""<<escape(s.weapon)
       <<"\",\"skin\":\""<<escape(s.title)<<"\",\"group\":\""<<escape(s.category)<<"\"}";
  }
  return out<<']',out.str();
}
}
