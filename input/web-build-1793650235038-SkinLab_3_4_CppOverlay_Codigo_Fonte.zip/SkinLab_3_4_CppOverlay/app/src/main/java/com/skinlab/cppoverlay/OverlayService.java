package com.skinlab.cppoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

public class OverlayService extends Service {
    private static final String CHANNEL="skinlab_overlay";
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams;
    private SkinStore store;
    private TextView selectedView;
    private LinearLayout list;
    private EditText search;
    private String group="Todos";
    private String query="";
    private String pendingId="ak-vulcan";
    private String pendingLabel="AK-47 | Vulcan";

    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        startInForeground();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        try { store=new SkinStore(this); }
        catch(Throwable e){ android.util.Log.e("SkinLab","Falha C++",e);stopSelf(); }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(store==null||!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        if(bubble==null && panel==null){
            try { showBubble(); }
            catch(Throwable e){android.util.Log.e("SkinLab","Overlay não suportado",e);stopSelf();}
        }
        return START_NOT_STICKY;
    }
    private void startInForeground(){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            manager.createNotificationChannel(new NotificationChannel(CHANNEL,"SkinLab — menu flutuante",NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification notification=builder.setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("SkinLab C++ ativo")
            .setContentText("Toque na bolha para ver o catálogo visual")
            .setOngoing(true).build();
        startForeground(3434,notification);
    }
    private WindowManager.LayoutParams params(int w,int h,int gravity,boolean focus){
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        if(!focus) flags|=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,type,flags,PixelFormat.TRANSLUCENT);
        p.gravity=gravity;
        return p;
    }
    private void showBubble(){
        removePanel();
        if(bubble!=null) return;
        TextView view=txt("◉  SKINLAB",14,Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10),dp(9),dp(10),dp(9));
        view.setBackgroundColor(0xff17416b);
        view.setOnClickListener(v->{try {showPanel();}catch(Throwable e){android.util.Log.e("SkinLab","Erro ao expandir",e);showBubbleSafe();}});
        bubbleParams=params(dp(120),dp(52),Gravity.TOP|Gravity.END,false);
        bubbleParams.x=dp(10);bubbleParams.y=dp(125);
        wm.addView(view,bubbleParams);bubble=view;
    }
    private void showBubbleSafe(){try{showBubble();}catch(Throwable e){android.util.Log.e("SkinLab","Erro da bolha",e);stopSelf();}}
    private void removeBubble(){
        if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}
    }
    private void removePanel(){
        if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}
    }
    private void showPanel(){
        removeBubble();
        if(panel!=null) return;
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff0c1626);
        root.setPadding(dp(12),dp(9),dp(12),dp(10));
        TextView header=txt("SKINLAB 3.4  •  C++    ✕",17,Color.WHITE);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOnClickListener(v->showBubbleSafe());
        root.addView(header);
        TextView notice=txt("PRÉVIA LOCAL — NÃO ALTERA O JOGO",11,0xffeab75e);
        root.addView(notice);
        pendingId=store.selection();
        pendingLabel=store.label();
        selectedView=txt("Prévia: "+pendingLabel,16,0xff77c7ff);
        root.addView(selectedView);
        search=new EditText(this);
        search.setSingleLine(true);
        search.setHint("Buscar skin / arma...");
        search.setHintTextColor(0xff8a9cac);
        search.setTextColor(Color.WHITE);
        search.setTextSize(14);
        search.setBackgroundColor(0xff1b2c43);
        root.addView(search,new LinearLayout.LayoutParams(-1,dp(45)));
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){query=s.toString();populate();}
            public void afterTextChanged(Editable e){}
        });
        LinearLayout cats=new LinearLayout(this);cats.setOrientation(LinearLayout.HORIZONTAL);
        for(String g:new String[]{"Todos","Armas","Facas","Luvas"}){
            Button b=new Button(this);b.setText(g);b.setAllCaps(false);b.setTextSize(10);
            cats.addView(b,new LinearLayout.LayoutParams(0,dp(43),1));
            b.setOnClickListener(v->{group=g;populate();});
        }
        root.addView(cats);
        ScrollView scroll=new ScrollView(this);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=new LinearLayout(this);
        Button save=new Button(this);save.setText("APLICAR PRÉVIA");save.setAllCaps(false);save.setTextSize(12);
        actions.addView(save,new LinearLayout.LayoutParams(0,dp(50),1));
        save.setOnClickListener(v->{
            boolean ok=store.apply(pendingId);
            selectedView.setText(ok?"Salvo no SkinLab: "+store.label():"Falha ao salvar preferência");
            populate();
        });
        Button reset=new Button(this);reset.setText("RESTAURAR");reset.setAllCaps(false);reset.setTextSize(12);
        actions.addView(reset,new LinearLayout.LayoutParams(0,dp(50),1));
        reset.setOnClickListener(v->{
            store.restore();pendingId=store.selection();pendingLabel=store.label();
            selectedView.setText("Restaurado: "+pendingLabel);populate();
        });
        root.addView(actions);
        populate();
        int width=Math.min(dp(350),getResources().getDisplayMetrics().widthPixels-dp(16));
        int height=Math.min(dp(570),getResources().getDisplayMetrics().heightPixels-dp(80));
        WindowManager.LayoutParams p=params(width,height,Gravity.TOP|Gravity.END,true);
        p.y=dp(40);p.x=dp(7);
        p.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        wm.addView(root,p);panel=root;
    }
    private void populate(){
        if(list==null||store==null) return;
        list.removeAllViews();
        for(int i=0;i<store.items().length();i++){
            JSONObject item=store.items().optJSONObject(i);
            if(item==null)continue;
            String id=item.optString("id"), name=item.optString("weapon")+" | "+item.optString("skin");
            if(!group.equals("Todos")&&!group.equals(item.optString("group")))continue;
            if(!name.toLowerCase(java.util.Locale.ROOT).contains(query.toLowerCase(java.util.Locale.ROOT)))continue;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(3),dp(5),dp(3),dp(5));
            row.setBackgroundColor(id.equals(pendingId)?0xff25496a:0xff142337);
            ImageView img=new ImageView(this);
            String key="skin_"+id.replace('-','_');
            int res=getResources().getIdentifier(key,"drawable",getPackageName());
            if(res!=0)img.setImageResource(res);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            row.addView(img,new LinearLayout.LayoutParams(dp(76),dp(54)));
            TextView label=txt(name,13,Color.WHITE);
            label.setPadding(dp(9),0,dp(2),0);
            row.addView(label,new LinearLayout.LayoutParams(0,dp(54),1));
            row.setOnClickListener(v->{
                pendingId=id;pendingLabel=name;
                selectedView.setText("Prévia: "+pendingLabel);populate();
            });
            list.addView(row);
            View spacer=new View(this);list.addView(spacer,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }
    private TextView txt(String value,int sp,int color){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(sp);v.setTextColor(color);
        v.setPadding(dp(4),dp(7),dp(4),dp(7));return v;
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    @Override public void onDestroy(){removeBubble();removePanel();super.onDestroy();}
}
