package com.skinlab.cppoverlay;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

public final class SkinStore {
    private final Context context;
    private final JSONArray items;
    public SkinStore(Context context) throws Exception {
        this.context = context.getApplicationContext();
        if (!NativeCore.load()) throw new IllegalStateException("Falha em libskinlab.so: " + NativeCore.error());
        items = new JSONArray(NativeCore.catalogJson());
        String remembered = this.context.getSharedPreferences("skins", Context.MODE_PRIVATE)
                .getString("selected", "ak-vulcan");
        if (!NativeCore.select(remembered)) NativeCore.restore();
    }
    public JSONArray items() { return items; }
    public String selection() { return NativeCore.selected(); }
    public String label() {
        String id=selection();
        for(int i=0;i<items.length();i++){
            JSONObject o=items.optJSONObject(i);
            if(o!=null && id.equals(o.optString("id"))) return o.optString("weapon")+" | "+o.optString("skin");
        }
        return "AK-47 | Vulcan";
    }
    public boolean apply(String id) {
        if (!NativeCore.select(id)) return false;
        return context.getSharedPreferences("skins", Context.MODE_PRIVATE)
                .edit().putString("selected",id).commit();
    }
    public void restore() {
        NativeCore.restore();
        context.getSharedPreferences("skins", Context.MODE_PRIVATE).edit().remove("selected").apply();
    }
}
