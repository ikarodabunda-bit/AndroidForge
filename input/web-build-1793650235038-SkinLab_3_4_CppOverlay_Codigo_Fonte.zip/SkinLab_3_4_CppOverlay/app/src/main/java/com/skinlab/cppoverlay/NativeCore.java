package com.skinlab.cppoverlay;

public final class NativeCore {
    private static boolean loaded;
    private static String error = "";
    private NativeCore() {}
    public static synchronized boolean load() {
        if (loaded) return true;
        try { System.loadLibrary("skinlab"); loaded = true; }
        catch (UnsatisfiedLinkError e) { error = e.getMessage(); }
        return loaded;
    }
    public static String error() { return error; }
    public static native String catalogJson();
    public static native boolean select(String id);
    public static native String selected();
    public static native void restore();
}
