package com.skinlab.cppoverlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private SkinStore store;
    private boolean ready;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(35),dp(22),dp(16));
        root.setBackgroundColor(Color.rgb(10,16,27));
        TextView title=text("SKINLAB 3.4  •  C++",24,Color.WHITE);
        root.addView(title);
        TextView note=text("Menu visual independente. Não altera skins ou inventário do CounterFlame.",14,0xff94a5b9);
        root.addView(note);
        status=text("Iniciando biblioteca C++...",15,Color.WHITE);
        root.addView(status);
        Button launch=button("ATIVAR MENU FLUTUANTE");
        root.addView(launch);
        launch.setOnClickListener(v->enableOverlay());
        Button stop=button("FECHAR MENU FLUTUANTE");
        root.addView(stop);
        stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
        TextView help=text("Android: permita 'Exibir sobre outros apps', volte e toque em ATIVAR.\nSe o jogo bloquear overlays, o menu continuará funcionando fora dele.",13,0xff94a5b9);
        root.addView(help);
        setContentView(root);
        try { store=new SkinStore(this); ready=true; status.setText("C++ carregado  •  19 skins  •  "+store.label()); }
        catch(Throwable e) { ready=false; status.setText("Erro ao iniciar: "+e.getClass().getSimpleName()+" — "+e.getMessage()); launch.setEnabled(false); }
    }
    @Override protected void onResume() {
        super.onResume();
        if(ready) status.setText((Settings.canDrawOverlays(this)?"Permissão concedida":"Permissão pendente")+"  •  "+store.label());
    }
    private void enableOverlay() {
        if(!ready) return;
        if(!Settings.canDrawOverlays(this)) {
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName()));
            try{startActivity(i);}catch(Exception e){status.setText("Abra Configurações > Apps > Acesso especial > Sobreposição");}
            return;
        }
        try {
            Intent i=new Intent(this,OverlayService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Menu solicitado. Abra o jogo e procure a bolha SKINLAB.");
        } catch(Exception e) { status.setText("Falha ao iniciar serviço: "+e.getMessage()); }
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private TextView text(String content,int sp,int color){TextView v=new TextView(this);v.setText(content);v.setTextSize(sp);v.setTextColor(color);v.setPadding(0,dp(6),0,dp(14));return v;}
    private Button button(String label){ Button b=new Button(this);b.setText(label);b.setAllCaps(false);return b; }
}
