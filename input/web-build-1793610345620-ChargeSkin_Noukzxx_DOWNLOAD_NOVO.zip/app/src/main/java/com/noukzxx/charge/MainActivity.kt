package com.noukzxx.charge

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("charge_v2", MODE_PRIVATE) }
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 7, 8)
        window.navigationBarColor = Color.rgb(7, 7, 8)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 7, 8))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowContentAccess = false
            settings.allowFileAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                    url?.startsWith("file:///android_asset/") != true
            }
            addJavascriptInterface(Bridge(), "Charge")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.post {
            web.evaluateJavascript("window.onPermissionUpdate && window.onPermissionUpdate()", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun status(): String {
            val token = prefs.getString("token", "") ?: ""
            val issuer = prefs.getString("issuer", "") ?: ""
            val result = LicenseVerifier.check(token, issuer)
            return JSONObject().put("paired", issuer.isNotEmpty())
                .put("valid", result.optBoolean("ok"))
                .put("expires", result.optLong("expires"))
                .put("days", result.optInt("days"))
                .put("error", result.optString("error"))
                .put("overlayAllowed", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
                .put("compatibility", prefs.getBoolean("compatibility", false))
                .toString()
        }

        @JavascriptInterface fun pairIssuer(text: String): String {
            if (LicenseVerifier.parseIssuer(text) == null) return "Emissor inválido. Copie a chave pública do KEY NOUK."
            prefs.edit().putString("issuer", text.trim()).remove("token").apply()
            return "OK"
        }

        @JavascriptInterface fun activate(token: String): String {
            val result = LicenseVerifier.check(token.trim(), prefs.getString("issuer", "") ?: "")
            if (result.optBoolean("ok")) prefs.edit().putString("token", token.trim()).apply()
            return result.toString()
        }

        @JavascriptInterface fun setCompatibility(enabled: Boolean) {
            prefs.edit().putBoolean("compatibility", enabled).apply()
            if (enabled) runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }

        @JavascriptInterface fun requestOverlay() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else launchOverlay()
            }
        }

        @JavascriptInterface fun openOverlay(): String {
            if (prefs.getBoolean("compatibility", false)) return "Desative o Modo Compatibilidade para abrir a sobreposição."
            val result = LicenseVerifier.check(prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: "")
            if (!result.optBoolean("ok")) return result.optString("error", "Licença inválida")
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) return "PERMISSION"
            runOnUiThread { launchOverlay() }
            return "OK"
        }

        private fun launchOverlay() {
            val result = LicenseVerifier.check(prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: "")
            if (!result.optBoolean("ok") || prefs.getBoolean("compatibility", false)) return
            try {
                val i = Intent(this@MainActivity, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } catch (_: Exception) { /* Android might restrict starting services; UI remains usable. */ }
        }

        @JavascriptInterface fun closeOverlay() {
            runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }

        @JavascriptInterface fun resetPairing() {
            prefs.edit().remove("issuer").remove("token").apply()
            closeOverlay()
        }
        @JavascriptInterface fun copy(text: String) {
            if (text.length > 4096) return
            runOnUiThread {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("ChargeSkin", text))
            }
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.removeJavascriptInterface("Charge"); web.destroy() }
        super.onDestroy()
    }
}
