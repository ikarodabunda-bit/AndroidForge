package com.noukzxx.charge

import android.annotation.SuppressLint
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView

/** Visual, user-controlled catalog overlay only; never accesses other apps' memory. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("charge_v2", MODE_PRIVATE) }
    private var bubble: TextView? = null
    private var panel: WebView? = null
    private var animator: ObjectAnimator? = null
    private val watchdog = object : Runnable {
        override fun run() {
            if (!allowed()) { stopSelf(); return }
            handler.postDelayed(this, 30_000L)
        }
    }

    private fun dp(v: Int) = (resources.displayMetrics.density * v).toInt()
    private fun type() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun allowed(): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return false
        if (prefs.getBoolean("compatibility", false)) return false
        return LicenseVerifier.check(prefs.getString("token", "") ?: "", prefs.getString("issuer", "") ?: "")
            .optBoolean("ok")
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startVisibleNotification() // immediate foreground promotion
        if (!allowed()) { stopSelf(startId); return START_NOT_STICKY }
        if (bubble == null) createBubble()
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 30_000L)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startVisibleNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "ChargeSkin ativo", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 55, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ChargeSkin — By:Noukzxx")
            .setContentText("Catálogo visual flutuante ativo")
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Encerrar", stopPending)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val b = TextView(this).apply {
            text = "N"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(255, 55, 67), Color.rgb(55, 9, 15))).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.rgb(255, 93, 103))
            }
            elevation = dp(12).toFloat()
            contentDescription = "Abrir catálogo ChargeSkin; segure para encerrar"
            isClickable = true
            isLongClickable = true
        }
        val params = WindowManager.LayoutParams(dp(60), dp(60), type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(210)
        }
        b.setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        b.setOnLongClickListener { stopSelf(); true }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var px = 0; var py = 0
            var dragged = false; var pressed = false
            val hold = Runnable { if (!dragged) { pressed = true; b.performLongClick() } }
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when(e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx=e.rawX; sy=e.rawY; px=params.x; py=params.y
                        dragged=false; pressed=false
                        handler.postDelayed(hold, ViewConfiguration.getLongPressTimeout().toLong())
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=e.rawX-sx; val dy=e.rawY-sy
                        if (kotlin.math.abs(dx)>dp(6) || kotlin.math.abs(dy)>dp(6)) {
                            dragged=true; handler.removeCallbacks(hold)
                        }
                        if (dragged) {
                            params.x=(px+dx.toInt()).coerceIn(0, (resources.displayMetrics.widthPixels-dp(60)).coerceAtLeast(0))
                            params.y=(py+dy.toInt()).coerceIn(0, (resources.displayMetrics.heightPixels-dp(60)).coerceAtLeast(0))
                            try { wm.updateViewLayout(b,params) } catch (_: Exception) {}
                        }
                        return true
                    }
                    MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(hold)
                        if (e.actionMasked==MotionEvent.ACTION_UP && !dragged && !pressed) view.performClick()
                        return true
                    }
                }
                return false
            }
        })
        try {
            wm.addView(b, params)
            bubble = b
            animator = ObjectAnimator.ofFloat(b, View.ALPHA, 1f, .7f, 1f).apply {
                duration=2400L; repeatCount=ObjectAnimator.INFINITE; start()
            }
        } catch (_: Exception) { stopSelf() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showPanel() {
        if (panel != null || !allowed()) return
        val display=resources.displayMetrics
        val w=minOf(dp(390), display.widthPixels-dp(20)).coerceAtLeast(dp(200))
        val h=minOf(dp(640), display.heightPixels-dp(50)).coerceAtLeast(dp(280))
        val widget=WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled=true
            settings.allowContentAccess=false
            settings.allowFileAccess=true
            settings.allowFileAccessFromFileURLs=false
            settings.allowUniversalAccessFromFileURLs=false
            webViewClient = object: WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url:String?):Boolean =
                    url?.startsWith("file:///android_asset/") != true
            }
            addJavascriptInterface(object {
                @JavascriptInterface fun close() { handler.post { hidePanel() } }
            }, "Overlay")
            loadUrl("file:///android_asset/overlay.html")
        }
        val params=WindowManager.LayoutParams(w,h,type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.CENTER
            softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try { wm.addView(widget,params); panel=widget; bubble?.visibility=View.GONE }
        catch (_: Exception) { widget.destroy() }
    }

    private fun hidePanel() {
        panel?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
            it.removeJavascriptInterface("Overlay")
            it.destroy()
        }
        panel=null
        bubble?.visibility=View.VISIBLE
    }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        animator?.cancel(); animator=null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble=null
        if (Build.VERSION.SDK_INT>=24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        private const val CHANNEL="charge_overlay_v1"
        private const val NOTIFICATION_ID=4022
        private const val ACTION_STOP="com.noukzxx.chargeskin.STOP"
    }
}
