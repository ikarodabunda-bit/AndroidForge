ChargeSkin Cyber Purple v3 — app de catálogo com acesso por KEY gerada no app separado ChargeSkin Key Generator.

Para teste: instale/compile ambos os projetos; abra Key Generator, gere e copie uma chave; abra ChargeSkin e cole a chave.

Protótipo offline, não compilado/testado nesta entrega. O segredo compartilhado é embutido nos dois apps e não deve ser usado para licenças comerciais.
