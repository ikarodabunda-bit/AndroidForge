package com.chargeskinmenu

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.security.MessageDigest

object KeyAuth {
    // Segredo de teste compartilhado entre os dois projetos. Não usar em produção.
    private const val SECRET = "ChargeSkin-CyberPurple-TEST-SECRET-2026"
    fun generate(): String {
        val id = java.util.UUID.randomUUID().toString().replace("-", "").uppercase().take(12)
        return "CS-$id-${sign(id)}"
    }
    fun valid(key: String): Boolean {
        val parts = key.trim().uppercase().split("-")
        if (parts.size != 3 || parts[0] != "CS" || parts[1].length != 12) return false
        return MessageDigest.isEqual(parts[2].toByteArray(), sign(parts[1]).toByteArray())
    }
    private fun sign(id: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        return mac.doFinal(id.toByteArray()).joinToString("") { "%02X".format(it) }.take(12)
    }
}
