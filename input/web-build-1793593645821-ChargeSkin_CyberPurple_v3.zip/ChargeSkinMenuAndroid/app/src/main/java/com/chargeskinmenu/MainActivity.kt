package com.chargeskinmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 8, 17)
    private val purple = Color.rgb(176, 70, 255)
    private val muted = Color.rgb(169, 164, 190)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)); background = gradient(bg, Color.rgb(34, 12, 54), 0, 0) }
        root.addView(label("C H A R G E S K I N", 13f, purple, true))
        root.addView(label("CYBER PURPLE", 29f, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(8)) })
        root.addView(label("ACESSO INDIVIDUAL", 12f, muted, true).apply { setPadding(0, 0, 0, dp(24)) })
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = gradient(Color.rgb(20, 16, 32), Color.rgb(35, 20, 52), dp(22), dp(2), purple) }
        card.addView(label("Sua Key pessoal", 20f, Color.WHITE, true))
        card.addView(label("Gere uma KEY no aplicativo ChargeSkin Key Generator e digite-a aqui para liberar o botão flutuante.", 13f, muted).apply { setPadding(0, dp(8), 0, dp(16)) })
        val field = EditText(this).apply { hint = "Digite sua KEY"; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 15f; setSingleLine(true); setPadding(dp(14), dp(12), dp(14), dp(12)); background = gradient(Color.rgb(12, 11, 21), Color.rgb(12, 11, 21), dp(12), dp(1), purple) }
        card.addView(field)
        val enter = Button(this).apply { text = "LIBERAR MENU FLUTUANTE"; isAllCaps = false; setTextColor(Color.WHITE); background = gradient(purple, Color.rgb(100, 35, 180), dp(12), 0); setOnClickListener {
            if (!KeyAuth.valid(field.text.toString())) { Toast.makeText(this@MainActivity, "KEY inválida. Gere uma chave no ChargeSkin Key Generator.", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); Toast.makeText(this@MainActivity, "Autorize 'Sobrepor a outros apps' e volte para liberar o menu.", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            startService(Intent(this@MainActivity, FloatingMenuService::class.java)); Toast.makeText(this@MainActivity, "Menu flutuante ativado!", Toast.LENGTH_SHORT).show(); finish()
        } }
        card.addView(enter, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        root.addView(label("O catálogo aparece somente no botão flutuante.\nUse o gerador correspondente. Este sistema é uma demonstração offline; não é seguro para distribuição comercial.", 11f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(20), 0, 0) })
        setContentView(root)
    }
    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text=t; textSize=size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun gradient(c1: Int, c2: Int, radius: Int, stroke: Int, strokeColor: Int = c1) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1,c2)).apply { cornerRadius=radius.toFloat(); if (stroke>0) setStroke(stroke,strokeColor) }
}
