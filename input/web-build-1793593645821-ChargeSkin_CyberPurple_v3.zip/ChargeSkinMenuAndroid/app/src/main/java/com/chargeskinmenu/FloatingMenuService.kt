package com.chargeskinmenu

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class FloatingMenuService : Service() {
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val skins = listOf(
        "Karambit | Bright Water" to "FACA", "Karambit | Freehand" to "FACA", "Karambit | Gamma Doppler" to "FACA", "Karambit | Fade" to "FACA", "Karambit | Black Laminate" to "FACA", "Butterfly Knife | Emerald" to "FACA", "Butterfly Knife | Marble Fade" to "FACA", "Karambit | Lore" to "FACA", "Karambit | Crimson Web" to "FACA", "Karambit | Tiger" to "FACA", "Talon Knife | Marble Fade" to "FACA", "Skeleton Knife | Fade" to "FACA",
        "M4A4 | The Emperor" to "RIFLE", "M4A4 | Howl" to "RIFLE", "M4A4 | Eye of Horus" to "RIFLE", "M4A4 | Neo-Noir" to "RIFLE", "M4A4 | Dragon King" to "RIFLE", "M4A4 | Industrya" to "RIFLE", "M4A4 | Temukau" to "RIFLE", "M4A4 | Poseidon" to "RIFLE", "AK-47 | Vulcan" to "RIFLE", "AK-47 | Gold Arabesque" to "RIFLE", "AK-47 | Neon Revolution" to "RIFLE", "AK-47 | Aquamarine" to "RIFLE", "AK-47 | Fireserpent" to "RIFLE", "AK-47 | Wild Lotus" to "RIFLE", "AK-47 | Fuel Injector" to "RIFLE", "AK-47 | Empress" to "RIFLE", "AK-47 | Colony Eradicator" to "RIFLE",
        "Desert Eagle | Code Red" to "PISTOLA", "USP-S | Kill Confirmed" to "PISTOLA", "Desert Eagle | Printstream" to "PISTOLA", "Desert Eagle | Blaze" to "PISTOLA", "Desert Eagle | Ocean Drive" to "PISTOLA", "USP-S | Flashback" to "PISTOLA", "Desert Eagle | Sandstorm" to "PISTOLA", "USP-S | Cortex" to "PISTOLA",
        "M4A1-S | Chantico's Fire" to "RIFLE", "M4A1-S | Decimator" to "RIFLE", "M4A1-S | Next Technology" to "RIFLE", "M4A1-S | Printstream" to "RIFLE", "M4A1-S | Hot Rod" to "RIFLE", "M4A1-S | Nightmare" to "RIFLE", "M4A1-S | Master Piece" to "RIFLE", "M4A1-S | Briefing" to "RIFLE"
    )
    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply { text = "C"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(208,90,255), Color.rgb(76,25,132))).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.rgb(238,190,255)) }; elevation = dp(12).toFloat(); contentDescription = "Abrir catálogo ChargeSkin" }
        bubble = b
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(dp(58), dp(58), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(18); y = dp(180) }
        b.setOnClickListener { if (panel == null) showCatalog(type) else hideCatalog() }
        b.setOnLongClickListener { stopSelf(); true }
        b.setOnTouchListener(object : View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean { when(e.action) { MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; moved=false; return true }; MotionEvent.ACTION_MOVE -> { val dx=(sx-e.rawX).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)>dp(5)||kotlin.math.abs(dy)>dp(5)) moved=true; params.x=(ox+dx).coerceAtLeast(0); params.y=(oy+dy).coerceAtLeast(0); try { wm?.updateViewLayout(b,params) } catch (_: Exception) {}; return true }; MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true } }; return false }
        })
        wm?.addView(b, params)
    }
    private fun showCatalog(type: Int) {
        val shell = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(12)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(20,13,32),Color.rgb(8,8,17))).apply { cornerRadius=dp(22).toFloat(); setStroke(dp(2),Color.rgb(180,70,255)) } }
        val head=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
        val title=TextView(this).apply { text="CHARGESKIN  •  CYBER PURPLE"; textSize=15f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
        head.addView(title,LinearLayout.LayoutParams(0,-2,1f)); val close=TextView(this).apply { text="✕"; textSize=20f; setTextColor(Color.rgb(220,160,255)); setPadding(dp(10),dp(2),dp(4),dp(2)); setOnClickListener{hideCatalog()} }; head.addView(close); shell.addView(head)
        val search=EditText(this).apply { hint="Pesquisar skin..."; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); textSize=14f; setSingleLine(true); setPadding(dp(10),dp(8),dp(10),dp(8)); background=GradientDrawable().apply{setColor(Color.rgb(36,25,49));cornerRadius=dp(10).toFloat()} }
        shell.addView(search,LinearLayout.LayoutParams(-1,dp(44)).apply{topMargin=dp(10);bottomMargin=dp(8)})
        val scroll=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; scroll.addView(list); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        fun render(q:String){ list.removeAllViews(); skins.filter{it.first.contains(q,true)||it.second.contains(q,true)}.forEach{(name,cat)-> val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(9),dp(8),dp(9),dp(8));background=GradientDrawable().apply{setColor(Color.rgb(28,22,39));cornerRadius=dp(12).toFloat()}}; val icon=TextView(this).apply{text=if(cat=="FACA")"⚔" else if(cat=="PISTOLA")"◈" else "▰";textSize=23f;gravity=Gravity.CENTER;setTextColor(Color.rgb(205,125,255));background=GradientDrawable().apply{setColor(Color.rgb(54,31,75));cornerRadius=dp(10).toFloat()};layoutParams=LinearLayout.LayoutParams(dp(46),dp(46))};row.addView(icon);val labels=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)};labels.addView(TextView(this).apply{text=name;textSize=13f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD});labels.addView(TextView(this).apply{text=cat;textSize=10f;setTextColor(Color.rgb(175,155,195))});row.addView(labels,LinearLayout.LayoutParams(0,-2,1f));list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)}) } }
        render(""); search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render(s?.toString().orEmpty())};override fun afterTextChanged(s:android.text.Editable?) {}})
        val hint=TextView(this).apply{text="Toque no C para abrir/fechar • segure para sair";textSize=10f;setTextColor(Color.LTGRAY);setPadding(0,dp(8),0,0)};shell.addView(hint)
        val p=WindowManager.LayoutParams(dp(310),dp(470),type,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER}; panel=shell;panelParams=p;wm?.addView(shell,p)
    }
    private fun hideCatalog(){ panel?.let{try{wm?.removeView(it)}catch(_:Exception){}};panel=null;panelParams=null }
    override fun onDestroy(){hideCatalog();bubble?.let{try{wm?.removeView(it)}catch(_:Exception){}};bubble=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
