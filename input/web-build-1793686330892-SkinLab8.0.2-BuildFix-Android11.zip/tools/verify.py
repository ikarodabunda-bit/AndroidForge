#!/usr/bin/env python3
"""Static checks; not an APK compilation or on-device test."""
from pathlib import Path
import re, xml.etree.ElementTree as ET, json
root=Path(__file__).resolve().parents[1]
assets=root/'app/src/main/assets'; java=root/'app/src/main/java/dev/skinforgex'
build=(root/'app/build.gradle').read_text()
assert re.search(r'\bminSdk 30\b',build)
assert re.search(r'\btargetSdk 35\b',build)
assert re.search(r"versionName '8\.0\.2-buildfix'",build)
assert "arm64-v8a" in build
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert manifest.find('application').attrib[ns+'label'].startswith('SkinLab 8.0.2')
assert manifest.find('application/service').attrib[ns+'foregroundServiceType']=='specialUse'
assert 'WRITE_SECURE_SETTINGS' not in (root/'app/src/main/AndroidManifest.xml').read_text()
for file in ['index.html','catalogo.html','lab3d.html']:
    path=assets/file
    assert path.is_file() and path.stat().st_size>1500, file
html=(assets/'index.html').read_text()
assert '268 RECURSOS' in html
assert 'data-nav="original"' in html
assert 'diagnosticBtn' in html and 'function exportDiagnostics()' in html
assert 'loadUrl("file:///android_asset/index.html")' in (java/'MainActivity.java').read_text()
assert 'AssetOnlyWebViewClient' in (java/'OverlayService.java').read_text()
assert 'getDiagnostics()' in (java/'StudioBridge.java').read_text()
assert 'shareDiagnostics(String report)' in (java/'StudioBridge.java').read_text()
assert 'GAME.equals(foregroundPackage)' in (java/'GameDetector.java').read_text()
assert (root/'app/src/main/cpp/native-lib.cpp').is_file()
assert 'private String sizeMode="mini"' in (java/'OverlayService.java').read_text()
assert 'bubbleSize(){return dp(48);}' in (java/'OverlayService.java').read_text()
assert 'body.overlay .layout{grid-template-columns:46px' in html
assert 'id="sizeBtn"' in html
assert 'setSizeMode(validated)' in (java/'StudioBridge.java').read_text()
assert 'workflow_dispatch' in (root/'.github/workflows/build-android.yml').read_text()
assert (java/'FaultLog.java').is_file()
assert 'PANEL_START_REQUESTED' in (java/'StudioBridge.java').read_text()
assert 'FOREGROUND_SERVICE_REJECTED' in (java/'OverlayService.java').read_text()
print('PASS: SkinLab 8.0.2 BuildFix | SDK 30+, Android assets, JNI, overlay, diagnostics and CI')
