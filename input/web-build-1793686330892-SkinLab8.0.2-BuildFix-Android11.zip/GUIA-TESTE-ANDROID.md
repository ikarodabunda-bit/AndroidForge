# Teste Android 11+ — SkinLab 8.0.1 NoRoot

1. Compile a nova versão no GitHub Actions (`Build SkinLab 8.0.1 NoRoot APK`).
2. Se aparecer `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, exporte configurações locais, desinstale o 8.0 e instale o 8.0.1. O APK debug pode receber assinatura diferente entre execuções.
3. Conceda **sobreposição** novamente ao pacote `dev.skinlab.noroot`. Permissões do SkinLab 7.x não contam para este aplicativo.
4. Em **Compatibilidade**, teste **ABRIR PAINEL**. Minimize e restaure. Teste também **JOGO + PAINEL**.
5. Se a sobreposição falhar, compartilhe **EXPORTAR DIAGNÓSTICO** (campo `lastErrorCode`). Se a compilação falhar, baixe o artefato `SkinLab-8.0.1-Build-Failure-Log`.
6. O botão **Aplicar** apenas salva uma prévia no SkinLab; não altera uma skin no Standoff 2.

## Códigos úteis

- `OVERLAY_PERMISSION_MISSING`: permissão de sobreposição não concedida.
- `FOREGROUND_SERVICE_REJECTED`: Android recusou o serviço em primeiro plano.
- `OVERLAY_WINDOW_FAILED`: Android rejeitou a criação da janela flutuante.
- `PANEL_START_FAILED`/`PANEL_AND_GAME_START_FAILED`: falha ao solicitar a inicialização.
- `NONE`: nenhum erro de inicialização foi registrado neste aplicativo.
