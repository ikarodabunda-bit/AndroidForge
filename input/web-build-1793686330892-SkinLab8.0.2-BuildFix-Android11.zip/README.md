# SkinLab 8.0.2 — BuildFix Android 11+

Projeto Android Studio para painel flutuante independente. Versao 8.0.2 corrige o **fluxo de compilacao do projeto**: ZIP com arquivos na raiz e GitHub Actions que gera o Gradle Wrapper, instala SDK/NDK/CMake, compila e entrega APK ou log de erro.

**Comece por `COMO-COMPILAR.md`.** O APK nao esta precompilado. Sem acesso ao Android SDK, o build real precisa rodar no Android Studio ou GitHub Actions.

O app nao altera os arquivos nem o inventario do Standoff 2.
