# Verificações locais — SkinLab 8.0.1 NoRoot

- `tools/verify.py`: estrutura, permissões manifest, versão, novo registro de erros, interface e workflow.
- `node --check`: scripts de `index.html`, `catalogo.html`, `lab3d.html`.
- `g++ -fsyntax-only`: motor C++17/JNI usando os headers JDK.
- Chromium (conteúdo em memória, sem navegar para arquivos locais): página principal abriu sem erros JS, títulos e navegação renderizados.
- Não foi possível abrir as URLs `file://` ou `http://localhost` no navegador de teste por política deste ambiente. Portanto, não foram testadas as galerias embutidas completas neste ciclo.
- **APK não foi compilado** neste ambiente porque o Android SDK e o Gradle não estão disponíveis aqui. Serviços de sobreposição, permissões e renderização WebView precisam ser validados no celular.
- **Nenhuma troca real de skin em partidas foi implementada.**
