# SkinLab 8.0.2 — Como gerar o APK sem computador

O ZIP fornece **codigo-fonte**. Nao e um APK. A compilacao utiliza o GitHub Actions com JDK 17, Android SDK 35, Gradle 8.10.2, NDK 27.2 e CMake 3.22.

## Passos (Android)

1. Crie um repositorio **privado** vazio no GitHub (sem README inicial).
2. Extraia este ZIP com ZArchiver.
3. Envie **o conteudo da pasta** para a raiz do repositorio. `settings.gradle`, `build.gradle`, `app/`, `tools/` e `.github/` devem ficar diretamente na raiz. Nao envie so o ZIP, nem uma pasta `SkinLab8.0.2` envolvendo tudo.
4. Confira se `.github/workflows/build-android.yml` esta no repositorio. Em Android, gerenciadores de arquivos podem ocultar pastas iniciadas por ponto.
5. Abra **Actions** no GitHub. Caso necessario habilite as acoes do repositorio.
6. Rode **Compilar SkinLab 8.0.2 APK -> Run workflow**, ou apenas atualize a branch `main` (a workflow roda em push).
7. Abra a execucao com sinal verde e baixe o artifact `SkinLab-8.0.2-APK-Android11`. Extraia o ZIP do artifact: dentro estara `app-debug.apk`.
8. Instale no Android 11+ ARM64, concedendo permissao de sobreposicao manualmente.

## Se falhar

Abra a execucao vermelha -> etapa `Compilar APK Debug` ou `Instalar componentes Android 35` -> copie **as 20 primeiras linhas de erro**, com `* What went wrong:` ou `error:`. Quando a compilacao comecar e falhar, o artifact `SkinLab-8.0.2-LOG-ERRO` guardara o log. Envie-o aqui.

## Erros recorrentes

- **Workflow nao aparece:** o arquivo `.github/workflows/build-android.yml` ficou em subpasta ou nao foi enviado.
- **`Task 'assembleDebug' not found` ou `Project 'app' not found`:** o repositorio nao tem `settings.gradle` e `app/` na raiz.
- **`gradlew: not found`:** o ZIP anterior nao tinha Gradle Wrapper. A workflow 8.0.2 gera o Wrapper automaticamente.
- **SDK / NDK nao encontrado:** use a workflow fornecida; ela instala os componentes.
- **`INSTALL_FAILED_UPDATE_INCOMPATIBLE`:** erro de instalacao devido a assinatura diferente, **nao de compilacao**; faca backup das configuracoes antes de remover a versao instalada.

A compilacao ainda nao foi testada neste ambiente por falta do SDK Android. O app e um painel/visualizador independente e nao desbloqueia skins em partidas.
