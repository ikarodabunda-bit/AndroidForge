package dev.skinforgex;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;

/** Restricted bridge exposed only to packaged, trusted file:///android_asset HTML. */
public final class StudioBridge {
    private final Context context;
    private final OverlayService overlay;
    private static final String PREF="skinlab5_config";
    StudioBridge(Context context, OverlayService overlay) { this.context=context; this.overlay=overlay; }

    @JavascriptInterface public String getStatus() {return GameDetector.statusJson(context);}
    @JavascriptInterface public String nativeSummary() {return NativeCore.summary();}
    @JavascriptInterface public String applyLocalPreview(int itemId) {
        return NativeCore.applyLocalPreview(itemId);
    }
    @JavascriptInterface public String getSavedConfig() {
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("config", "");
    }
    @JavascriptInterface public String saveConfig(String json) {
        if(json==null || json.length()>100000) return "INVALID_SIZE";
        try {
            JSONObject obj=new JSONObject(json);
            if(obj.optJSONObject("saved")==null) return "INVALID_CONFIG";
            context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString("config",obj.toString()).apply();
            return "LOCAL_SAVED";
        } catch(Exception ex) {return "INVALID_JSON";}
    }
    private void dispatch(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    @JavascriptInterface public void openGame() {
        Intent launch=context.getPackageManager().getLaunchIntentForPackage(GameDetector.GAME);
        if(launch!=null) dispatch(launch);
    }
    /** One tap: starts our foreground overlay, then launches the unmodified game. */
    @JavascriptInterface public String launchGameWithPanel() {
        if(!GameDetector.installed(context)) return "GAME_NOT_INSTALLED";
        if(!Settings.canDrawOverlays(context)) {
            requestOverlayPermission();
            return "OVERLAY_PERMISSION_REQUIRED";
        }
        Intent launch=context.getPackageManager().getLaunchIntentForPackage(GameDetector.GAME);
        if(launch==null) return "LAUNCH_UNAVAILABLE";
        Intent svc=new Intent(context,OverlayService.class);
        svc.setAction(OverlayService.ACTION_SHOW);
        try {
            if(Build.VERSION.SDK_INT>=26)context.startForegroundService(svc);
            else context.startService(svc);
            dispatch(launch);
            return "PANEL_START_REQUESTED";
        } catch(RuntimeException e) {
            FaultLog.record(context,"PANEL_AND_GAME_START_FAILED");
            return "START_FAILED";
        }
    }
    /** Fully hides all overlay touch surfaces; restored using the persistent notification. */
    @JavascriptInterface public void hidePanelForGame() {
        if(overlay!=null) overlay.hideForGame();
        else {
            Intent i=new Intent(context,OverlayService.class);
            i.setAction(OverlayService.ACTION_HIDE);
            try {
                if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);
                else context.startService(i);
            } catch (RuntimeException ex) { FaultLog.record(context,"HIDE_ACTION_FAILED"); }
        }
    }
    @JavascriptInterface public void requestUsagePermission() {
        try { dispatch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
        catch (RuntimeException ex) { FaultLog.record(context,"USAGE_SETTINGS_UNAVAILABLE"); }
    }
    @JavascriptInterface public void requestOverlayPermission() {
        try {
            dispatch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:"+context.getPackageName())));
        } catch (RuntimeException ex) { FaultLog.record(context,"OVERLAY_SETTINGS_UNAVAILABLE"); }
    }
    @JavascriptInterface public String startOverlay() {
        if(!Settings.canDrawOverlays(context)) {
            requestOverlayPermission();
            return "OVERLAY_PERMISSION_REQUIRED";
        }
        Intent service=new Intent(context,OverlayService.class);
        service.setAction(OverlayService.ACTION_SHOW);
        try {
            if(Build.VERSION.SDK_INT>=26) context.startForegroundService(service);
            else context.startService(service);
            return "PANEL_START_REQUESTED";
        } catch (RuntimeException ex) {
            FaultLog.record(context,"PANEL_START_FAILED");
            return "START_FAILED";
        }
    }
    @JavascriptInterface public void closeOverlay() {
        if(overlay!=null) overlay.stopSelf();
        else context.stopService(new Intent(context,OverlayService.class));
    }
    @JavascriptInterface public void moveOverlay(int dx,int dy) {
        if(overlay!=null)overlay.moveBy(dx,dy);
    }
    @JavascriptInterface public void minimizeOverlay(boolean tiny) {
        if(overlay!=null)overlay.minimize(tiny);
    }
    @JavascriptInterface public void setOverlaySize(String mode) {
        String validated=("compact".equals(mode)||"full".equals(mode))?mode:"mini";
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString("panel_size",validated).apply();
        if(overlay!=null)overlay.setSizeMode(validated);
    }
    @JavascriptInterface public void setOverlayKeyboardEnabled(boolean enabled) {
        if(overlay!=null) overlay.setKeyboardEnabled(enabled);
    }
    @JavascriptInterface public void shareConfig(String content) {
        if(content==null||content.length()>100000)return;
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("application/json");
        share.putExtra(Intent.EXTRA_TEXT,content);
        dispatch(Intent.createChooser(share,"Exportar SkinLab 8.0.2"));
    }

    /** Diagnostic data intentionally excludes account IDs, device IDs, location, and other private data. */
    @JavascriptInterface public String getDiagnostics() {
        JSONObject report=new JSONObject();
        try {
            report.put("app", "SkinLab 8.0.2 NoRoot");
            report.put("package", context.getPackageName());
            report.put("lastErrorCode", FaultLog.lastCode(context));
            report.put("lastErrorTimestamp", FaultLog.lastTime(context));
            report.put("minSdk", 30);
            report.put("androidSdk", Build.VERSION.SDK_INT);
            report.put("overlayPermission", Settings.canDrawOverlays(context));
            report.put("inOverlayWindow", overlay != null);
            report.put("game", new JSONObject(GameDetector.statusJson(context)));
            report.put("nativeSummary", NativeCore.summary());
            android.content.pm.PackageInfo webview=android.webkit.WebView.getCurrentWebViewPackage();
            report.put("webViewVersion", webview == null ? "unavailable" : webview.versionName);
        } catch(Exception ex) { try {report.put("diagnosticError", "unavailable");} catch(Exception ignored) {} }
        return report.toString();
    }
    @JavascriptInterface public void shareDiagnostics(String report) {
        if (report == null || report.length() > 20000) return;
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, report);
        dispatch(Intent.createChooser(send, "Compartilhar diagnóstico SkinLab"));
    }
}
