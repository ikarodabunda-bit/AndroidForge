package dev.skinforgex;

import android.content.Context;

/** Stores only an error code and timestamp; no user data, device IDs or trace. */
public final class FaultLog {
    private FaultLog() {}
    public static void record(Context context, String code) {
        context.getSharedPreferences("skinlab_errors", Context.MODE_PRIVATE).edit()
            .putString("last_code", code).putLong("last_time", System.currentTimeMillis()).apply();
    }
    public static String lastCode(Context context) {
        return context.getSharedPreferences("skinlab_errors", Context.MODE_PRIVATE)
            .getString("last_code", "NONE");
    }
    public static long lastTime(Context context) {
        return context.getSharedPreferences("skinlab_errors", Context.MODE_PRIVATE)
            .getLong("last_time", 0L);
    }
    public static void clear(Context context) {
        context.getSharedPreferences("skinlab_errors", Context.MODE_PRIVATE).edit().clear().apply();
    }
}
