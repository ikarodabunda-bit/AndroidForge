package com.chargeskinmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 25)
    private val panel = Color.rgb(20, 29, 44)
    private val accent = Color.rgb(0, 220, 190)
    private val muted = Color.rgb(155, 171, 190)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(28), dp(20), dp(20)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("CHARGE", 14f, accent, true))
        content.addView(label("SKIN MENU", 30f, Color.WHITE, true))
        content.addView(label("CATÁLOGO VISUAL • VERSÃO 2.0", 11f, muted, true).apply { setPadding(0, dp(4), 0, dp(20)) })

        val intro = card()
        intro.addView(label("Bem-vindo", 20f, Color.WHITE, true))
        intro.addView(label("Explore uma coleção demonstrativa de visuais. Escolha um cartão para ver os detalhes.", 14f, muted).apply { setPadding(0, dp(8), 0, dp(12)) })
        intro.addView(actionButton("Ativar menu flutuante") { requestOverlayAndStart() })
        content.addView(intro)
        content.addView(label("COLEÇÃO EM DESTAQUE", 13f, accent, true).apply { setPadding(0, dp(24), 0, dp(10)) })

        val skins = listOf(
            Triple("NEON PHANTOM", "Visual futurista • Edição neon", "01"),
            Triple("SHADOW ELITE", "Visual tático • Edição escura", "02"),
            Triple("CRIMSON STORM", "Visual intenso • Edição rubra", "03"),
            Triple("CYBER GUARD", "Visual tecnológico • Edição azul", "04")
        )
        skins.forEach { (name, desc, number) ->
            val item = card()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(label(number, 22f, accent, true).apply { setBackgroundColor(Color.rgb(31, 54, 69)); setPadding(dp(14), dp(12), dp(14), dp(12)) })
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
            labels.addView(label(name, 16f, Color.WHITE, true))
            labels.addView(label(desc, 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            item.addView(row)
            item.addView(actionButton("Ver detalhes") { Toast.makeText(this, "$name — prévia demonstrativa", Toast.LENGTH_SHORT).show() })
            content.addView(item)
        }
        content.addView(label("Aviso: este aplicativo é um catálogo demonstrativo. Ele não instala, desbloqueia ou altera itens de jogos.", 11f, muted).apply { setPadding(0, dp(18), 0, dp(8)) })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
    }
    private fun actionButton(title: String, action: () -> Unit) = Button(this).apply {
        text = title; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 125, 117)); setOnClickListener { action() }
    }
    private fun requestOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Autorize a sobreposição e volte ao aplicativo.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingMenuService::class.java))
        Toast.makeText(this, "Menu flutuante ativado.", Toast.LENGTH_SHORT).show()
    }
}
