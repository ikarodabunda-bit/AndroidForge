# ChargeSkinMenuAndroid v2.0

Projeto Android demonstrativo de catálogo visual de skins e menu flutuante.

Requisitos: Android SDK 35 e JDK 17. Abra a pasta raiz no Android Studio e aguarde a sincronização do Gradle. Para APK debug: `gradle assembleDebug`.

O catálogo é apenas demonstrativo. Não modifica arquivos de jogos, não injeta código e não interage com sistemas anti-cheat.
