package com.chargeskinmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 25)
    private val panel = Color.rgb(25, 19, 39)
    private val accent = Color.rgb(190, 80, 255)
    private val muted = Color.rgb(155, 171, 190)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(28), dp(20), dp(20)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("CHARGESKIN", 14f, accent, true))
        content.addView(label("CYBER PURPLE", 30f, Color.WHITE, true))
        content.addView(label("CATÁLOGO DE SKINS • BASEADO NAS SUAS PRINTS", 11f, muted, true).apply { setPadding(0, dp(4), 0, dp(20)) })

        val intro = card()
        intro.addView(label("Mercado de skins", 20f, Color.WHITE, true))
        intro.addView(label("Itens identificados nas cinco capturas que você enviou. Use a busca para filtrar por arma ou nome.", 14f, muted).apply { setPadding(0, dp(8), 0, dp(12)) })
        intro.addView(actionButton("Ativar menu flutuante") { requestOverlayAndStart() })
        content.addView(intro)

        val skins = listOf(
            Triple("Karambit | Bright Water", "Faca", "01"),
            Triple("Karambit | Freehand", "Faca", "02"),
            Triple("Karambit | Gamma Doppler", "Faca", "03"),
            Triple("Karambit | Fade", "Faca", "04"),
            Triple("Karambit | Black Laminate", "Faca", "05"),
            Triple("Butterfly Knife | Emerald", "Faca", "06"),
            Triple("Butterfly Knife | Marble Fade", "Faca", "07"),
            Triple("Karambit | Lore", "Faca", "08"),
            Triple("Karambit | Crimson Web", "Faca", "09"),
            Triple("Karambit | Tiger", "Faca", "10"),
            Triple("Talon Knife | Marble Fade", "Faca", "11"),
            Triple("Skeleton Knife | Fade", "Faca", "12"),
            Triple("M4A4 | The Emperor", "Rifle", "13"),
            Triple("M4A4 | Howl", "Rifle", "14"),
            Triple("M4A4 | Eye of Horus", "Rifle", "15"),
            Triple("M4A4 | Neo-Noir", "Rifle", "16"),
            Triple("M4A4 | Dragon King", "Rifle", "17"),
            Triple("M4A4 | Industrya", "Rifle", "18"),
            Triple("M4A4 | Temukau", "Rifle", "19"),
            Triple("M4A4 | Poseidon", "Rifle", "20"),
            Triple("AK-47 | Vulcan", "Rifle", "21"),
            Triple("AK-47 | Gold Arabesque", "Rifle", "22"),
            Triple("AK-47 | Neon Revolution", "Rifle", "23"),
            Triple("AK-47 | Aquamarine", "Rifle", "24"),
            Triple("AK-47 | Fireserpent", "Rifle", "25"),
            Triple("AK-47 | Wild Lotus", "Rifle", "26"),
            Triple("AK-47 | Fuel Injector", "Rifle", "27"),
            Triple("AK-47 | Empress", "Rifle", "28"),
            Triple("AK-47 | Colony Eradicator", "Rifle", "29"),
            Triple("Desert Eagle | Code Red", "Pistola", "30"),
            Triple("USP-S | Kill Confirmed", "Pistola", "31"),
            Triple("Desert Eagle | Printstream", "Pistola", "32"),
            Triple("Desert Eagle | Blaze", "Pistola", "33"),
            Triple("Desert Eagle | Ocean Drive", "Pistola", "34"),
            Triple("USP-S | Flashback", "Pistola", "35"),
            Triple("Desert Eagle | Sandstorm", "Pistola", "36"),
            Triple("USP-S | Cortex", "Pistola", "37"),
            Triple("M4A1-S | Chantico's Fire", "Rifle", "38"),
            Triple("M4A1-S | Decimator", "Rifle", "39"),
            Triple("M4A1-S | Next Technology", "Rifle", "40"),
            Triple("M4A1-S | Printstream", "Rifle", "41"),
            Triple("M4A1-S | Hot Rod", "Rifle", "42"),
            Triple("M4A1-S | Nightmare", "Rifle", "43"),
            Triple("M4A1-S | Master Piece", "Rifle", "44"),
            Triple("M4A1-S | Briefing", "Rifle", "45")
        )
        content.addView(label("45 ITENS IDENTIFICADOS", 13f, accent, true).apply { setPadding(0, dp(22), 0, dp(10)) })
        val search = EditText(this).apply {
            hint = "Buscar skin ou arma..."
            setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(true); setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.rgb(37, 27, 54))
        }
        content.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) })
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun render(query: String) {
            results.removeAllViews()
            val filtered = skins.filter { it.first.contains(query, ignoreCase = true) || it.second.contains(query, ignoreCase = true) }
            if (filtered.isEmpty()) results.addView(label("Nenhuma skin encontrada.", 14f, muted).apply { setPadding(0, dp(12), 0, dp(12)) })
            filtered.forEach { (name, category, number) ->
                val item = card()
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(label(number, 18f, accent, true).apply { setBackgroundColor(Color.rgb(49, 28, 70)); setPadding(dp(12), dp(10), dp(12), dp(10)) })
                val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                labels.addView(label(name, 15f, Color.WHITE, true))
                labels.addView(label(category.uppercase(), 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
                row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                item.addView(row)
                item.addView(actionButton("Ver detalhes") { Toast.makeText(this, "$name — entrada do catálogo visual", Toast.LENGTH_SHORT).show() })
                results.addView(item)
            }
        }
        render("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        content.addView(label("Aviso: catálogo visual baseado nas capturas enviadas. Ele não aplica skins dentro das partidas nem altera arquivos do jogo.", 11f, muted).apply { setPadding(0, dp(18), 0, dp(8)) })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
    }
    private fun actionButton(title: String, action: () -> Unit) = Button(this).apply {
        text = title; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(112, 35, 165)); setOnClickListener { action() }
    }
    private fun requestOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Autorize a sobreposição e volte ao aplicativo.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingMenuService::class.java))
        Toast.makeText(this, "Menu flutuante ativado.", Toast.LENGTH_SHORT).show()
    }
}
