package com.chargeskinmenu

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private data class SkinItem(val name: String, val weapon: String, val category: String, val image: String)

class FloatingMenuService : Service() {
    companion object {
        const val EXTRA_EXPIRES_AT = "license_expires_at"
    }

    private val violet = Color.rgb(191, 75, 255)
    private val pink = Color.rgb(236, 119, 255)
    private val ink = Color.rgb(9, 7, 16)
    private val muted = Color.rgb(172, 156, 193)
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var activeCategory = "TODAS"
    private var query = ""
    private var expiresAt = 0L
    private var expiryTask: Runnable? = null
    private lateinit var listContainer: LinearLayout
    private lateinit var countLabel: TextView

    private val skins = listOf(
        SkinItem("Karambit | Bright Water", "FACA", "FACAS", "karambit_bright_water"),
        SkinItem("Karambit | Freehand", "FACA", "FACAS", "karambit_freehand"),
        SkinItem("Karambit | Gamma Doppler", "FACA", "FACAS", "karambit_gamma_doppler"),
        SkinItem("Karambit | Fade", "FACA", "FACAS", "karambit_fade"),
        SkinItem("Karambit | Black Laminate", "FACA", "FACAS", "karambit_black_laminate"),
        SkinItem("Butterfly Knife | Emerald", "FACA", "FACAS", "butterfly_emerald"),
        SkinItem("Butterfly Knife | Marble Fade", "FACA", "FACAS", "butterfly_marble_fade"),
        SkinItem("Karambit | Lore", "FACA", "FACAS", "karambit_lore"),
        SkinItem("Karambit | Crimson Web", "FACA", "FACAS", "karambit_crimson_web"),
        SkinItem("Karambit | Tiger", "FACA", "FACAS", "karambit_tiger"),
        SkinItem("Talon Knife | Marble Fade", "FACA", "FACAS", "talon_marble_fade"),
        SkinItem("Skeleton Knife | Fade", "FACA", "FACAS", "skeleton_knife_fade"),

        SkinItem("AK-47 | Vulcan", "RIFLE", "RIFLES", "ak_vulcan"),
        SkinItem("AK-47 | Gold Arabesque", "RIFLE", "RIFLES", "ak_gold_arabesque"),
        SkinItem("AK-47 | Neon Revolution", "RIFLE", "RIFLES", "ak_neon_revolution"),
        SkinItem("AK-47 | Aquamarine", "RIFLE", "RIFLES", "ak_aquamarine"),
        SkinItem("AK-47 | Fireserpent", "RIFLE", "RIFLES", "ak_fireserpent"),
        SkinItem("AK-47 | Wild Lotus", "RIFLE", "RIFLES", "ak_wild_lotus"),
        SkinItem("AK-47 | Fuel Injector", "RIFLE", "RIFLES", "ak_fuel_injector"),
        SkinItem("AK-47 | Empress", "RIFLE", "RIFLES", "ak_empress"),
        SkinItem("AK-47 | Colony Eradicator", "RIFLE", "RIFLES", "ak_colony_eradicator"),

        SkinItem("M4A4 | The Emperor", "RIFLE", "RIFLES", "m4a4_emperor"),
        SkinItem("M4A4 | Howl", "RIFLE", "RIFLES", "m4a4_howl"),
        SkinItem("M4A4 | Eye of Horus", "RIFLE", "RIFLES", "m4a4_eye_of_horus"),
        SkinItem("M4A4 | Neo-Noir", "RIFLE", "RIFLES", "m4a4_neo_noir"),
        SkinItem("M4A4 | Dragon King", "RIFLE", "RIFLES", "m4a4_dragon_king"),
        SkinItem("M4A4 | Industrya", "RIFLE", "RIFLES", "m4a4_industrya"),
        SkinItem("M4A4 | Temukau", "RIFLE", "RIFLES", "m4a4_temukau"),
        SkinItem("M4A4 | Poseidon", "RIFLE", "RIFLES", "m4a4_poseidon"),

        SkinItem("M4A1-S | Chantico's Fire", "RIFLE", "RIFLES", "m4a1s_chanticos_fire"),
        SkinItem("M4A1-S | Decimator", "RIFLE", "RIFLES", "m4a1s_decimator"),
        SkinItem("M4A1-S | Next Technology", "RIFLE", "RIFLES", "m4a1s_next_technology"),
        SkinItem("M4A1-S | Printstream", "RIFLE", "RIFLES", "m4a1s_printstream"),
        SkinItem("M4A1-S | Hot Rod", "RIFLE", "RIFLES", "m4a1s_hot_rod"),
        SkinItem("M4A1-S | Nightmare", "RIFLE", "RIFLES", "m4a1s_nightmare"),
        SkinItem("M4A1-S | Master Piece", "RIFLE", "RIFLES", "m4a1s_master_piece"),
        SkinItem("M4A1-S | Briefing", "RIFLE", "RIFLES", "m4a1s_briefing"),

        SkinItem("Desert Eagle | Code Red", "PISTOLA", "PISTOLAS", "deagle_code_red"),
        SkinItem("USP-S | Kill Confirmed", "PISTOLA", "PISTOLAS", "usp_kill_confirmed"),
        SkinItem("Desert Eagle | Printstream", "PISTOLA", "PISTOLAS", "deagle_printstream"),
        SkinItem("Desert Eagle | Blaze", "PISTOLA", "PISTOLAS", "deagle_blaze"),
        SkinItem("Desert Eagle | Ocean Drive", "PISTOLA", "PISTOLAS", "deagle_ocean_drive"),
        SkinItem("USP-S | Flashback", "PISTOLA", "PISTOLAS", "usp_flashback"),
        SkinItem("Desert Eagle | Sandstorm", "PISTOLA", "PISTOLAS", "deagle_sandstorm"),
        SkinItem("USP-S | Cortex", "PISTOLA", "PISTOLAS", "usp_cortex")
    )

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        expiresAt = intent?.getLongExtra(EXTRA_EXPIRES_AT, 0L) ?: 0L
        expiryTask?.let { handler.removeCallbacks(it) }
        if (expiresAt > 0L) {
            val remaining = expiresAt - System.currentTimeMillis()
            if (remaining <= 0L) stopSelf() else {
                expiryTask = Runnable { Toast.makeText(this, "A licença ChargeSkin expirou.", Toast.LENGTH_LONG).show(); stopSelf() }
                handler.postDelayed(expiryTask!!, remaining)
            }
        }
        return START_NOT_STICKY
    }

    private fun windowType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun createBubble() {
        val bubbleView = TextView(this).apply {
            text = "♛"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(180, 54, 255), Color.rgb(59, 18, 105))).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), pink)
            }
            elevation = dp(12).toFloat()
            contentDescription = "Abrir menu flutuante ChargeSkin"
        }
        bubble = bubbleView
        val params = WindowManager.LayoutParams(
            dp(62), dp(62), windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(14)
            y = dp(240)
        }
        bubbleView.setOnClickListener { if (panel == null) showCatalog() else hideCatalog() }
        bubbleView.setOnLongClickListener { stopSelf(); true }
        bubbleView.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0f; var startY = 0f; var originalX = 0; var originalY = 0; var moved = false
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX; startY = event.rawY; originalX = params.x; originalY = params.y; moved = false; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (startX - event.rawX).toInt(); val dy = (event.rawY - startY).toInt()
                        if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                        params.x = (originalX + dx).coerceAtLeast(0)
                        params.y = (originalY + dy).coerceAtLeast(dp(8))
                        try { windowManager?.updateViewLayout(bubbleView, params) } catch (_: Exception) { }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) view.performClick()
                        return true
                    }
                }
                return false
            }
        })
        try { windowManager?.addView(bubbleView, params) } catch (_: Exception) { stopSelf() }
    }

    private fun showCatalog() {
        val screenWidth = resources.configuration.screenWidthDp
        val screenHeight = resources.configuration.screenHeightDp
        val panelWidth = dp(minOf(390, screenWidth - 28).coerceAtLeast(280))
        val panelHeight = dp(minOf(650, screenHeight - 64).coerceAtLeast(440))

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(23, 12, 36), ink)).apply {
                cornerRadius = dp(27).toFloat()
                setStroke(dp(2), violet)
            }
            elevation = dp(18).toFloat()
        }
        panel = shell

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "♛"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(pink)
            background = rounded(Color.rgb(48, 19, 68), dp(14), violet)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        })
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titleBlock.addView(label("CHARGESKIN", 17f, Color.WHITE, true))
        titleBlock.addView(label("CYBER PURPLE  •  NOUK", 9f, pink, true).apply { setPadding(0, dp(3), 0, 0) })
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "×"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(pink)
            background = rounded(Color.rgb(36, 18, 52), dp(20), pink)
            layoutParams = LinearLayout.LayoutParams(dp(39), dp(39))
            setOnClickListener { hideCatalog() }
        })
        shell.addView(header)

        val search = EditText(this).apply {
            hint = "⌕  Buscar skin..."
            setHintTextColor(Color.rgb(143, 122, 162)); setTextColor(Color.WHITE); textSize = 13f
            setSingleLine(true); setPadding(dp(13), dp(9), dp(13), dp(9))
            background = rounded(Color.rgb(12, 9, 20), dp(13), Color.rgb(92, 52, 120))
        }
        shell.addView(search, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(9)) }
        listOf("TODAS", "FACAS", "RIFLES", "PISTOLAS").forEach { category ->
            val tab = TextView(this).apply {
                text = category; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(if (activeCategory == category) Color.rgb(75, 25, 105) else Color.rgb(29, 20, 39), dp(20), if (activeCategory == category) pink else Color.rgb(63, 47, 78))
                setTextColor(if (activeCategory == category) Color.WHITE else muted)
                setOnClickListener { activeCategory = category; updateTabs(tabs); renderSkins() }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(-2, dp(38)).apply { marginEnd = dp(7) })
        }
        tabScroll.addView(tabs)
        shell.addView(tabScroll)

        countLabel = label("45 SKINS NO CATÁLOGO", 10f, muted, true).apply { setPadding(dp(2), dp(2), 0, dp(8)) }
        shell.addView(countLabel)
        val scroll = ScrollView(this).apply { isFillViewport = false; isVerticalScrollBarEnabled = false }
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); renderSkins() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        shell.addView(label("Arraste o ♛ para mover  •  Toque para abrir/fechar  •  Segure para sair", 9f, muted).apply { setPadding(0, dp(10), 0, 0); gravity = Gravity.CENTER })
        renderSkins()

        val params = WindowManager.LayoutParams(
            panelWidth, panelHeight, windowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
        try { windowManager?.addView(shell, params) } catch (_: Exception) { panel = null }
    }

    private fun updateTabs(tabs: LinearLayout) {
        for (i in 0 until tabs.childCount) {
            val view = tabs.getChildAt(i) as? TextView ?: continue
            val selected = view.text.toString() == activeCategory
            view.background = rounded(if (selected) Color.rgb(75, 25, 105) else Color.rgb(29, 20, 39), dp(20), if (selected) pink else Color.rgb(63, 47, 78))
            view.setTextColor(if (selected) Color.WHITE else muted)
        }
    }

    private fun renderSkins() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val filtered = skins.filter {
            (activeCategory == "TODAS" || it.category == activeCategory) &&
                (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true))
        }
        countLabel.text = "${filtered.size} SKIN(S) ENCONTRADA(S)"
        filtered.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            pair.forEach { item -> row.addView(skinCard(item), LinearLayout.LayoutParams(0, dp(142), 1f).apply {
                if (item == pair.first()) marginEnd = dp(6) else marginStart = dp(6)
            }) }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(142), 1f).apply { marginStart = dp(6) })
            listContainer.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        if (filtered.isEmpty()) listContainer.addView(label("Nenhuma skin encontrada.", 12f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(35), 0, dp(35)) })
    }

    private fun skinCard(item: SkinItem): LinearLayout {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(Color.rgb(25, 18, 34), dp(15), Color.rgb(84, 51, 111))
            setOnClickListener { Toast.makeText(this@FloatingMenuService, "${item.name} • item do catálogo", Toast.LENGTH_SHORT).show() }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(48, 44, 54))
            val res = resources.getIdentifier(item.image, "drawable", packageName)
            if (res != 0) setImageResource(res)
            contentDescription = item.name
        }
        tile.addView(image, LinearLayout.LayoutParams(-1, dp(82)))
        tile.addView(label(item.name, 10.5f, Color.WHITE, true).apply {
            maxLines = 2; setPadding(dp(1), dp(7), dp(1), 0)
        })
        tile.addView(label(item.weapon, 8f, pink, true).apply { setPadding(dp(1), dp(3), 0, 0) })
        return tile
    }

    private fun hideCatalog() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }
        panel = null
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); setStroke(dp(1), stroke)
    }

    override fun onDestroy() {
        expiryTask?.let { handler.removeCallbacks(it) }
        hideCatalog()
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
