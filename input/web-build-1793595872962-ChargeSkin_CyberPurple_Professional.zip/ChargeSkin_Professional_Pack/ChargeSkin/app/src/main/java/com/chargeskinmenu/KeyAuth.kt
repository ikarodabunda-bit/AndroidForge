package com.chargeskinmenu

import android.util.Base64
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

data class LicenseInfo(val id: String, val issuedAt: Long, val expiresAt: Long, val days: Int) {
    val isPermanent: Boolean get() = days == 0
}

sealed class LicenseResult {
    data class Valid(val license: LicenseInfo) : LicenseResult()
    data class Invalid(val message: String) : LicenseResult()
}

object KeyAuth {
    // Public key only. The private signing key exists in the separate KEY NOUK generator project.
    private const val PUBLIC_KEY_B64 = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE79eykbErvpxJ+o+RCt/UdxkkTAyp6TNrZO8yX4f6fMH8XaWJa941SOy+/H17lfft/PA0+6Szehq75E69LssvgQ=="

    fun validate(raw: String): LicenseResult {
        val parts = raw.trim().split('.')
        if (parts.size != 3 || parts[0] != "KN1") return LicenseResult.Invalid("Formato de KEY inválido.")
        return try {
            val payloadBytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            val signatureBytes = Base64.decode(parts[2], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            val payload = payloadBytes.toString(Charsets.UTF_8)
            val verifier = Signature.getInstance("SHA256withECDSA")
            val publicBytes = Base64.decode(PUBLIC_KEY_B64, Base64.DEFAULT)
            val publicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(publicBytes))
            verifier.initVerify(publicKey)
            verifier.update(payloadBytes)
            if (!verifier.verify(signatureBytes)) return LicenseResult.Invalid("Assinatura não reconhecida. Gere uma KEY no KEY NOUK.")

            val fields = payload.split('|')
            if (fields.size != 5 || fields[0] != "KN1") return LicenseResult.Invalid("Dados da licença inválidos.")
            val id = fields[1]
            val issued = fields[2].toLongOrNull() ?: return LicenseResult.Invalid("Data de emissão inválida.")
            val expires = fields[3].toLongOrNull() ?: return LicenseResult.Invalid("Validade inválida.")
            val days = fields[4].toIntOrNull() ?: return LicenseResult.Invalid("Período inválido.")
            if (id.length != 16 || days !in listOf(0, 1, 7, 31)) return LicenseResult.Invalid("Licença não reconhecida.")
            val now = System.currentTimeMillis()
            if (issued > now + 5 * 60 * 1000L || issued <= 0L) return LicenseResult.Invalid("Data de emissão não válida neste aparelho.")
            val expectedExpiry = if (days == 0) 0L else issued + days * 24L * 60L * 60L * 1000L
            if (expires != expectedExpiry) return LicenseResult.Invalid("Período da licença foi alterado.")
            if (days != 0 && expires <= now) return LicenseResult.Invalid("Esta KEY expirou. Gere uma nova no KEY NOUK.")
            LicenseResult.Valid(LicenseInfo(id, issued, expires, days))
        } catch (_: Exception) {
            LicenseResult.Invalid("Não foi possível ler esta KEY. Confira se ela foi copiada por completo.")
        }
    }
}
