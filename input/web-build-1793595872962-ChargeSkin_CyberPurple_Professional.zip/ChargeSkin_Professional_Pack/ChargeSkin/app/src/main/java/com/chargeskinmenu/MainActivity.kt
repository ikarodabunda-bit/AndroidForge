package com.chargeskinmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val violet = Color.rgb(193, 81, 255)
    private val pale = Color.rgb(190, 174, 211)
    private lateinit var keyField: EditText
    private lateinit var status: TextView
    private var pendingExpiry = 0L
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 6, 16)
        window.navigationBarColor = Color.rgb(8, 6, 16)
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Color.rgb(8, 6, 16)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(25), dp(22), dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(8, 6, 16), Color.rgb(28, 9, 43)))
        }
        scroll.addView(root)

        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(text("♛", 27f, Color.rgb(230, 145, 255), true).apply {
            gravity = Gravity.CENTER
            background = round(Color.rgb(42, 17, 62), dp(15), dp(1), violet)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("CHARGESKIN", 18f, Color.WHITE, true))
        brand.addView(text("CYBER PURPLE  /  NOUK EDITION", 9f, violet, true).apply { setPadding(0, dp(4), 0, 0) })
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(text("V3.0", 10f, Color.rgb(116, 235, 168), true).apply { background = round(Color.rgb(16, 43, 33), dp(20), dp(1), Color.rgb(50, 137, 91)); setPadding(dp(10), dp(7), dp(10), dp(7)) })
        root.addView(brandRow)

        root.addView(text("Seu catálogo.\nSeu estilo.", 31f, Color.WHITE, true).apply { setPadding(0, dp(33), 0, dp(8)) })
        root.addView(text("Acesse o menu flutuante Cyber Purple usando uma licença gerada pelo KEY NOUK.", 13f, pale).apply {
            setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, 0, 0, dp(20))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(19), dp(18), dp(18))
            background = round(Color.rgb(20, 14, 31), dp(22), dp(1), Color.rgb(91, 49, 123))
        }
        card.addView(text("01  /  AUTENTICAÇÃO", 11f, violet, true))
        card.addView(text("Informe sua KEY NOUK", 19f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(6)) })
        card.addView(text("Cada licença possui um período próprio: 1 dia, 7 dias, 31 dias ou permanente.", 11f, pale).apply { setPadding(0, 0, 0, dp(14)); setLineSpacing(dp(2).toFloat(), 1f) })
        keyField = EditText(this).apply {
            hint = "Cole sua KEY completa aqui"
            setHintTextColor(Color.rgb(125, 111, 143))
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            minLines = 2
            maxLines = 4
            setHorizontallyScrolling(false)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = round(Color.rgb(10, 8, 17), dp(13), dp(1), Color.rgb(103, 61, 133))
        }
        card.addView(keyField, LinearLayout.LayoutParams(-1, -2))
        status = text("Aguardando validação da licença.", 11f, pale).apply { setPadding(0, dp(12), 0, dp(4)) }
        card.addView(status)
        card.addView(actionButton("VALIDAR E ABRIR FLUTUANTE", true) { validateAndLaunch() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
        root.addView(card)

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = round(Color.rgb(16, 12, 25), dp(18), dp(1), Color.rgb(56, 40, 72))
        }
        info.addView(text("02  /  COMO LIBERAR", 11f, violet, true))
        info.addView(infoLine("1", "Abra o aplicativo KEY NOUK e selecione a duração."))
        info.addView(infoLine("2", "Gere a KEY e use o botão COPIAR KEY."))
        info.addView(infoLine("3", "Cole a licença acima e valide para abrir o catálogo."))
        root.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(text("A interface flutuante é um catálogo visual. Ela não altera arquivos do jogo nem aplica skins automaticamente.", 10f, Color.rgb(126, 112, 143)).apply {
            setPadding(dp(2), dp(18), dp(2), 0); gravity = Gravity.CENTER; setLineSpacing(dp(3).toFloat(), 1f)
        })
        setContentView(scroll)
    }

    private fun validateAndLaunch() {
        when (val result = KeyAuth.validate(keyField.text.toString())) {
            is LicenseResult.Invalid -> {
                status.text = "✕  ${result.message}"
                status.setTextColor(Color.rgb(255, 111, 135))
            }
            is LicenseResult.Valid -> {
                pendingExpiry = result.license.expiresAt
                val period = if (result.license.isPermanent) "PERMANENTE" else "${result.license.days} DIA(S)"
                status.text = "✓  KEY válida • $period • ID ${result.license.id}"
                status.setTextColor(Color.rgb(111, 235, 164))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 701)
                    Toast.makeText(this, "Permita a sobreposição e volte ao ChargeSkin.", Toast.LENGTH_LONG).show()
                } else launchFloating()
            }
        }
    }

    @Deprecated("Deprecated in Android API; kept for AndroidIDE compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) launchFloating()
            else {
                status.text = "Permissão de sobreposição não concedida."
                status.setTextColor(Color.rgb(255, 111, 135))
            }
        }
    }

    private fun launchFloating() {
        if (pendingExpiry != 0L && pendingExpiry <= System.currentTimeMillis()) {
            status.text = "Esta licença expirou. Gere outra no KEY NOUK."
            status.setTextColor(Color.rgb(255, 111, 135))
            return
        }
        startService(Intent(this, FloatingMenuService::class.java).putExtra(FloatingMenuService.EXTRA_EXPIRES_AT, pendingExpiry))
        Toast.makeText(this, "ChargeSkin flutuante ativado!", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun infoLine(number: String, message: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(13), 0, 0)
        addView(text(number, 12f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = round(Color.rgb(67, 24, 94), dp(9), dp(1), violet)
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
        })
        addView(text(message, 11f, pale).apply { setPadding(dp(11), 0, 0, 0) })
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun actionButton(label: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
        background = round(if (primary) Color.rgb(115, 35, 171) else Color.rgb(42, 29, 57), dp(14), dp(1), violet)
        setOnClickListener { action() }
    }
    private fun round(color: Int, radius: Int, stroke: Int, strokeColor: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke > 0) setStroke(stroke, strokeColor)
    }
}
