# ChargeSkin Cyber Purple — v3.0

Aplicativo Android com tela de validação KEY NOUK e catálogo flutuante redondo/neon.

O catálogo contém 45 entradas com miniaturas, pesquisa e filtros por facas, rifles e pistolas. O botão ♛ pode ser arrastado; toque para abrir/fechar e pressione por alguns instantes para encerrar.

O ChargeSkin valida a assinatura ECDSA usando a chave pública correspondente ao gerador KEY NOUK e verifica as datas de validade.

Abra esta pasta no AndroidIDE. Veja `../README_GERAL.md` para instalar e testar os dois projetos juntos.

**Atenção:** o catálogo é visual e não altera o jogo. A verificação offline é para prototipagem; consulte as limitações no README geral antes de distribuir.
