# ChargeSkin Cyber Purple + KEY NOUK — pacote profissional de teste

O pacote contém dois projetos Android independentes:

- `KeyNouk/`: gerador de licenças KEY NOUK com opções de 1 dia, 7 dias, 31 dias e permanente.
- `ChargeSkin/`: aplicativo ChargeSkin Cyber Purple, que valida a licença e abre o catálogo em um botão flutuante circular.

## Como compilar no AndroidIDE

1. Extraia os dois projetos.
2. Abra a pasta `KeyNouk` no AndroidIDE e sincronize/compile o projeto.
3. Faça o mesmo com a pasta `ChargeSkin`.
4. Instale os dois aplicativos no mesmo aparelho.
5. Abra o KEY NOUK, escolha uma validade, toque em **GERAR NOVA KEY** e depois em **COPIAR KEY**.
6. Abra o ChargeSkin, cole a KEY, toque em **VALIDAR E ABRIR FLUTUANTE** e conceda a permissão **Sobrepor a outros apps**.
7. O botão circular ♛ aparece sobre a tela. Toque para abrir/fechar; arraste para mover; mantenha pressionado para encerrar.

## O que está implementado

- Assinatura de licença ECDSA/SHA-256: o KEY NOUK assina o conteúdo e o ChargeSkin valida usando somente a chave pública.
- Validade de 24 horas, 7 dias, 31 dias ou permanente.
- Expiração verificada na ativação e encerramento do serviço flutuante no fim da licença.
- Histórico local no gerador, cópia e compartilhamento da KEY.
- Catálogo visual com 45 skins e miniaturas recortadas das imagens enviadas na conversa.
- Busca e filtros por facas, rifles e pistolas.

## Limitações importantes

Este é um protótipo offline para testes. Como o aplicativo gerador contém a chave privada para assinar licenças, alguém com conhecimento técnico pode extraí-la do APK e fabricar licenças. Para distribuir publicamente, a assinatura precisa ser feita por um serviço seguro/servidor, ou por um processo de emissão privado fora do aplicativo. Licenças offline também não podem ser revogadas remotamente.

O catálogo é uma interface visual: não injeta arquivos, não altera memória e não aplica skins dentro do Counter Flame Mobile. Isso depende de suporte oficial do jogo (API/SDK ou mecanismo permitido pelo desenvolvedor), que não está implementado aqui.

Os projetos usam Android Gradle Plugin 8.7.3 / Kotlin 2.0.21, compileSdk 35 e minSdk 23. Nesta sessão não havia Gradle/Android SDK instalado; por isso os arquivos foram revisados e empacotados, mas não foi possível gerar APK nem confirmar compilação em dispositivo. O AndroidIDE precisará baixar/sincronizar as dependências de build.
