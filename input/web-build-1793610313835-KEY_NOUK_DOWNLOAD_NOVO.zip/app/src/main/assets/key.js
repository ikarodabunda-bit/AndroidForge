(function(){
 'use strict';
 const $=id=>document.getElementById(id), native=!!window.Nouk;
 let days=1,current='';
 const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const format=t=>!t?'Sem data de expiração':new Date(t).toLocaleString('pt-BR');
 [...document.querySelectorAll('#nav button')].forEach(b=>b.onclick=()=>{document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x===b));['generate','pair','history','about'].forEach(x=>$('page-'+x).classList.toggle('hide',x!==b.dataset.page));if(b.dataset.page==='history')refreshHistory()});
 $('durations').onclick=e=>{const b=e.target.closest('[data-days]');if(!b)return;days=+b.dataset.days;[...$('durations').children].forEach(x=>x.classList.toggle('selected',x===b))};
 function refreshHistory(){let a=[];try{a=native?JSON.parse(Nouk.history()):JSON.parse(localStorage.getItem('nouk_demo_history')||'[]')}catch(e){}$('issuedCount').textContent=a.length;$('history').innerHTML=a.length?a.map(item=>`<div class="history-item"><b>${item.days===0?'PERMANENTE':item.days+' DIA(S)'}</b> • ${format(item.issued)}<br><span class="soft">Expira: ${format(item.expires)}</span><div class="keytext" style="margin-top:7px">${esc(item.key)}</div></div>`).join(''):'<p class="soft">Nenhuma licença nesta instalação.</p>'}
 $('generate').onclick=()=>{if(!native){current='DEMO-NAO-VALIDA-CHAVES';$('keyValue').textContent=current;$('keyExpiry').textContent='Prévia visual somente: não assina licenças.';return}try{const data=JSON.parse(Nouk.generate(days));if(!data.ok){$('keyValue').textContent='Erro: '+data.error;return}current=data.token;$('keyValue').textContent=current;$('keyExpiry').textContent='Expira: '+format(data.expires);refreshHistory()}catch(e){$('keyValue').textContent='Falha ao gerar: '+e.message}};
 function copy(text){if(!text)return;if(native)Nouk.copy(text);else if(navigator.clipboard)navigator.clipboard.writeText(text).catch(()=>{});}
 $('copyKey').onclick=()=>copy(current);$('shareKey').onclick=()=>{if(native&&current)Nouk.share(current)};
 $('copyIssuer').onclick=()=>copy($('issuer').textContent);
 $('clear').onclick=()=>{if(!confirm('Limpar histórico local? As KEYs emitidas continuam válidas.'))return;if(native)Nouk.clearHistory();else localStorage.removeItem('nouk_demo_history');refreshHistory()};
 $('issuer').textContent=native?Nouk.issuer():'Prévia: copie esta informação do APK KEY NOUK';refreshHistory();
})();
