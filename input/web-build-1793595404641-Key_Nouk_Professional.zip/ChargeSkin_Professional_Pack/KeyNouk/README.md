# KEY NOUK — v2.0

Gerador Android de licenças para ChargeSkin Cyber Purple.

## Validades disponíveis
- 1 dia (24 horas)
- 7 dias
- 31 dias
- Permanentemente

Gera um identificador aleatório, registra a emissão e a expiração e assina o conteúdo usando ECDSA com SHA-256. Inclui botão de copiar, compartilhar e histórico local das últimas chaves.

Abra esta pasta no AndroidIDE. Veja `../README_GERAL.md` para o fluxo de teste com o ChargeSkin.

**Atenção:** protótipo offline. A chave privada está dentro do código do gerador para permitir o teste isolado; não distribuir publicamente como sistema seguro de licenciamento.
