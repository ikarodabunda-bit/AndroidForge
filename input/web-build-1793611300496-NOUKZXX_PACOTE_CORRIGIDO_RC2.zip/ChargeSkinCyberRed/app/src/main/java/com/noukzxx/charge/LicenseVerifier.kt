package com.noukzxx.charge

import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/** Requires an explicitly paired KeyNouk public key. Never trusts a key bundled in a token. */
object LicenseVerifier {
    private fun decode(s: String): ByteArray = Base64.decode(
        s, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
    )

    fun parseIssuer(value: String): ByteArray? = try {
        val text = value.trim()
        if (text.length !in 70..500 || !text.startsWith("NKPUB.")) null
        else decode(text.removePrefix("NKPUB.")).also {
            KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(it))
        }
    } catch (_: Exception) { null }

    /** Returns a user-facing JSON result, never throws for malformed user input. */
    fun check(token: String, issuer: String): JSONObject = try {
        require(token.length in 50..4096) { "KEY incompleta ou excessivamente longa." }
        val pub = parseIssuer(issuer) ?: error("Emissor não configurado. Faça o pareamento.")
        val parts = token.trim().split('.')
        require(parts.size == 3 && parts[0] == "NK2") { "Formato de KEY não reconhecido." }
        val payload = decode(parts[1])
        val signature = decode(parts[2])
        require(payload.size in 30..1000 && signature.size in 60..150) { "Dados de KEY inválidos." }
        val verifier = Signature.getInstance("SHA256withECDSA")
        val pk = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(pub))
        verifier.initVerify(pk)
        verifier.update(payload)
        require(verifier.verify(signature)) { "Assinatura inválida para este emissor." }
        val data = JSONObject(String(payload, Charsets.UTF_8))
        val now = System.currentTimeMillis()
        val days = data.getInt("days")
        val issued = data.getLong("iat")
        val end = data.getLong("exp")
        require(data.getInt("v") == 2 && days in setOf(0, 1, 7, 31)) { "Período inválido." }
        require(data.getString("id").matches(Regex("[A-Za-z0-9_-]{16}"))) { "Identificador inválido." }
        require(issued > 0 && issued <= now + 300_000L) { "Data de emissão inválida neste aparelho." }
        require(end == (if (days == 0) 0L else issued + days * 86_400_000L)) { "Validade alterada." }
        require(end == 0L || end > now) { "Licença expirada." }
        JSONObject().put("ok", true).put("days", days).put("expires", end)
            .put("id", data.getString("id"))
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message ?: "Não foi possível validar a KEY.")
    }
}
