(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const catalog=window.NOUK_CATALOG||[];
  const native=!!window.Charge;
  const categories=['Todas',...new Set(catalog.map(x=>x.category))];
  let storedFavorites=[];try{storedFavorites=JSON.parse(localStorage.getItem('nouk_favorites')||'[]')}catch(e){}
  const favs=new Set(Array.isArray(storedFavorites)?storedFavorites:[]);
  let active='Todas',timer=0;
  const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const src=x=>x.source==='print+bundle'?'PRINT + BUNDLE':x.source==='print-only'?'CONFIRMADO POR PRINT':x.source==='bundle+previous-catalog'?'CATÁLOGO + BUNDLE':'RECURSO UNITY';
  const img=x=>x.image?`<img loading="lazy" src="${esc(x.image)}" alt="${esc(x.name)}">`:'<div class="placeholder" aria-label="Imagem ainda não disponível">◈</div>';
  function displayCard(x){return `<article class="tile" tabindex="0" data-view="${esc(x.id)}">${img(x)}<button class="star ${favs.has(x.id)?'on':''}" data-fav="${esc(x.id)}" aria-label="Favoritar">${favs.has(x.id)?'★':'☆'}</button><h3>${esc(x.name)}</h3><div class="src">${src(x)}</div></article>`;}
  function bindCards(box){box.querySelectorAll('[data-fav]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const id=b.dataset.fav;favs.has(id)?favs.delete(id):favs.add(id);localStorage.setItem('nouk_favorites',JSON.stringify([...favs]));render();}));box.querySelectorAll('[data-view]').forEach(b=>{b.addEventListener('click',()=>detail(b.dataset.view));b.addEventListener('keydown',e=>{if(e.key==='Enter')detail(b.dataset.view)})});}
  function detail(id){const x=catalog.find(s=>s.id===id);if(!x)return;const container=$('detailBody');container.innerHTML=`<div class="row"><span class="section-name">DETALHES DO RECURSO</span><button class="btn small secondary" id="dismiss">FECHAR</button></div><div style="height:150px;margin:11px 0">${img(x)}</div><h2>${esc(x.name)}</h2><p class="soft">${esc(x.category)} • ${src(x)}</p><p class="soft">Identificador técnico: <code>${esc(x.id)}</code></p><p class="soft">Bundles localizados: ${x.bundles} ${x.bundleZip?'• '+esc(x.bundleZip):''}</p><p class="notice">Visualização de catálogo: não altera arquivos, equipamentos ou inventário do jogo.</p>`;$('detail').classList.remove('hide');$('dismiss').onclick=()=>$('detail').classList.add('hide');}
  $('detail').addEventListener('click',e=>{if(e.target===$('detail'))$('detail').classList.add('hide')});
  function render(){let text=$('search').value.trim().toLowerCase();const found=catalog.filter(x=>(active==='Todas'||x.category===active)&&(`${x.name} ${x.id} ${x.category}`).toLowerCase().includes(text));$('grid').innerHTML=found.length?found.map(displayCard).join(''):'<p class="nfound">Nenhum resultado para essa busca.</p>';$('resultCount').textContent=found.length+' itens';bindCards($('grid'));const bookmarked=catalog.filter(x=>favs.has(x.id));$('favgrid').innerHTML=bookmarked.map(displayCard).join('');bindCards($('favgrid'));$('emptyFav').classList.toggle('hide',bookmarked.length>0);$('favcount').textContent=bookmarked.length;}
  $('total').textContent=catalog.length;
  $('chips').innerHTML=categories.map(c=>`<button class="chip ${c==='Todas'?'selected':''}" data-category="${esc(c)}">${esc(c)}</button>`).join('');$('chips').addEventListener('click',e=>{const b=e.target.closest('[data-category]');if(!b)return;active=b.dataset.category;[...$('chips').children].forEach(x=>x.classList.toggle('selected',x===b));render()});
  $('search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(render,100)});
  [...document.querySelectorAll('#nav button')].forEach(b=>b.onclick=()=>{document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x===b));['catalog','favorites','access','settings'].forEach(x=>$('page-'+x).classList.toggle('hide',x!==b.dataset.page));if(b.dataset.page==='access')refreshStatus()});
  function message(text,isError){$('licenseStatus').textContent=text;$('licenseStatus').className=isError?'error':'good';}
  function refreshStatus(){if(!native){$('licenseMini').textContent='DEMO';message('Prévia no navegador: instale o APK para validar licenças.',false);return};try{const s=JSON.parse(Charge.status());$('licenseMini').textContent=s.valid?'ATIVA':s.paired?'PAREADA':'OFF';if(s.valid)message(`Licença válida • ${s.days===0?'Permanente':s.days+' dia(s)'} ${s.expires? '• até '+new Date(s.expires).toLocaleString('pt-BR'):''}`,false);else message(s.paired?(s.error||'Informe sua KEY'): 'Faça o pareamento com o emissor.',!!s.paired)}catch(e){message('Falha na leitura do estado.',true)}}
  window.onPermissionUpdate=refreshStatus;
  window.onOverlayLaunchFailure=()=>message('O Android bloqueou o início do flutuante. Verifique permissões e economia de bateria.',true);
  $('pair').onclick=()=>{if(!native){message('Pareamento exige o aplicativo Android.',true);return}if(!confirm('Confirma confiar neste emissor? Isso substitui o emissor anterior e invalida a KEY antiga.'))return;const result=Charge.pairIssuer($('issuerInput').value);message(result==='OK'?'Emissor associado. Agora informe uma KEY.':result,result!=='OK');refreshStatus()};
  $('activate').onclick=()=>{if(!native){message('Ativação exige o aplicativo Android.',true);return}try{const result=JSON.parse(Charge.activate($('tokenInput').value));message(result.ok?'Licença ativada!':result.error,!result.ok);refreshStatus()}catch(e){message('KEY inválida.',true)}};
  $('openOverlay').onclick=()=>{if(!native){message('Flutuante disponível no aplicativo Android.',true);return}let result=Charge.openOverlay();if(result==='PERMISSION'){Charge.requestOverlay();message('Conceda a permissão de sobreposição no Android e toque em ABRIR novamente.',false)}else message(result==='OK'?'Solicitação de abertura enviada ao Android.':'Não foi possível abrir: '+result,result!=='OK')};
  $('stopOverlay').onclick=()=>{if(native)Charge.closeOverlay();message('Flutuante encerrado.',false)};
  let compatSaved=localStorage.getItem('nouk_compat')==='1';if(native){try{compatSaved=!!JSON.parse(Charge.status()).compatibility}catch(e){}}$('compat').checked=compatSaved;$('compat').onchange=e=>{const on=e.target.checked;localStorage.setItem('nouk_compat',on?'1':'0');if(native)Charge.setCompatibility(on)};
  $('reduced').checked=localStorage.getItem('nouk_reduce')==='1';function reduce(on){document.body.classList.toggle('reduce-motion',on)} reduce($('reduced').checked);$('reduced').onchange=e=>{reduce(e.target.checked);localStorage.setItem('nouk_reduce',e.target.checked?'1':'0')};
  $('resetPairing').onclick=()=>{if(!native)return;if(confirm('Remover o emissor e a licença salva?')){Charge.resetPairing();refreshStatus()}};
  render();refreshStatus();
})();
