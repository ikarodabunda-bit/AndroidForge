(function(){
 'use strict';
 const $=id=>document.getElementById(id), data=window.NOUK_CATALOG||[];
 let filter='Todas', timer=0;
 const categories=['Todas',...new Set(data.map(x=>x.category))];
 const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const img=x=>x.image?`<img loading="lazy" src="${esc(x.image)}" alt="">`:'<div class="placeholder">◈</div>';
 $('chips').innerHTML=categories.map(x=>`<button data-cat="${esc(x)}" class="chip ${x==='Todas'?'selected':''}">${esc(x)}</button>`).join('');
 $('chips').onclick=e=>{const b=e.target.closest('[data-cat]');if(!b)return;filter=b.dataset.cat;for(const c of $('chips').children)c.classList.toggle('selected',c===b);render()};
 function render(){const q=$('search').value.trim().toLowerCase();const found=data.filter(x=>(filter==='Todas'||x.category===filter)&&`${x.name} ${x.id}`.toLowerCase().includes(q));$('resultCount').textContent=found.length+' itens';$('grid').innerHTML=found.length?found.map(x=>`<article class="tile" data-id="${esc(x.id)}">${img(x)}<h3>${esc(x.name)}</h3><div class="src">${esc(x.category)}</div></article>`).join(''):'<div class="nfound">Nenhum resultado</div>';
 for(const node of $('grid').querySelectorAll('[data-id]'))node.onclick=()=>show(node.dataset.id)}
 function show(id){const x=data.find(i=>i.id===id);if(!x)return;$('detailBody').innerHTML=`<div class="row"><span class="section-name">RECURSO VISUAL</span><button class="btn small secondary" id="closeDetail">✕ FECHAR</button></div>${img(x)}<h3>${esc(x.name)}</h3><p class="soft">${esc(x.category)} • ${esc(x.id)}</p><p class="notice">Catálogo somente visual, sem alterações no jogo.</p>`;$('detail').classList.remove('hide');$('closeDetail').onclick=()=>$('detail').classList.add('hide')}
 $('detail').onclick=e=>{if(e.target===$('detail'))$('detail').classList.add('hide')};
 $('search').oninput=()=>{clearTimeout(timer);timer=setTimeout(render,80)};
 $('close').onclick=()=>{if(window.Overlay)Overlay.close();else window.close()};render();
})();
