# By:Noukzxx — AndroidForge • Instalação corrigida (RC1)

## Motivo de aparecer "Atualizar" em vez de "Instalar"

O Android reconhece cada aplicativo por seu identificador `applicationId`. Ao tentar instalar um APK cujo identificador já esteja no celular, ele mostra "Atualizar". Se a assinatura for diferente, a atualização pode falhar com conflito de pacote. Isso não é causado pelo tema preto/vermelho.

**Neste pacote os identificadores foram alterados para novos, diferentes entre si:**
- ChargeSkin: `com.noukzxx.chargeskin.cyberred2`
- KEY NOUK: `com.noukzxx.keynouk.cyberred2`

Portanto, estes novos builds deverão aparecer como apps independentes e oferecer **Instalar** quando não houver outras instalações prévias desses mesmos IDs. Os apps antigos continuarão instalados até você removê-los manualmente; dados e licenças dos apps anteriores NÃO migram para estes.

## Correções importantes

- KEY NOUK originalmente estava abrindo um `index.html` antigo, com gerador visual que não assinava licenças, mesmo havendo `key.html` preparado para integração. Agora a Activity abre `key.html` e fornece a interface JavaScript `Nouk` que o código esperava.
- Emissão no KEY NOUK passa a usar `AndroidKeyStore` para assinar licenças ECDSA P-256 (SHA256withECDSA). A chave privada fica dentro do Keystore. A chave pública é exportada com prefixo `NKPUB.`.
- ChargeSkin verifica a licença `NK2.payload.assinatura` com a chave pública explicitamente pareada do KEY NOUK. Acesso temporário de 1, 7, 31 dias e permanente.
- ChargeSkin mantém o catálogo visual de 296 registros e 93 miniaturas recortadas dos prints fornecidos (os demais usam placeholders).
- O modo Compatibilidade desativa a sobreposição, **não contorna** anti-cheat nem restrições do jogo.
- Corrigido o tratamento de favoritos malformados e dimensionamento da sobreposição em telas pequenas.

## Compilação e instalação no AndroidForge

1. Importe `KEY_NOUK_INSTALAR_AndroidForge.zip` como projeto independente e compile `debug`.
2. Importe `CHARGESKIN_INSTALAR_AndroidForge.zip` como projeto independente e compile `debug`.
3. Instale os APKs gerados. O Android deve oferecer **Instalar** em vez de Atualizar caso estes identificadores não estejam presentes no aparelho.
4. No KEY NOUK, abra a aba **Emissor** e copie a chave pública `NKPUB...`.
5. No ChargeSkin, abra **Acesso**, cole e pareie o emissor.
6. No KEY NOUK, abra **Gerar**, selecione uma validade, gere a KEY e copie.
7. No ChargeSkin, cole a KEY e valide.
8. Conceda permissão de sobreposição para usar o catálogo flutuante (caso seja permitida).

**Atenção:** se quiser preservar dados de aplicativos antigos, não os desinstale antes de decidir o que precisa salvar. Os novos identificadores NÃO compartilham dados com eles.

## Limites e segurança

- Não é um APK pronto: ZIP contém código-fonte para compilar no AndroidForge.
- Este ambiente não disponibiliza Gradle/Android SDK para compilar e instalar de verdade; portanto, a compilação Android continua pendente.
- A emissão offline não tem revogação remota e depende do relógio local; não é segura para licenças pagas.
- O ChargeSkin não altera o inventário nem aplica skins dentro do Counter Flame: é um catálogo de referência independente.
- Sem bypass, anti-ban, aimbot, ESP ou alteração de memória do jogo.

## Correções adicionais RC2

- Corrigido conflito entre `id=generate` usado pela seção inteira e pelo botão de emissão: agora o botão tem `id=generateKey` e somente ele inicia a emissão.
- Tratamento de histórico local malformado e erros de inicialização do emissor.
- Entrada da chave pública e da licença limitada por tamanho.
- Tratamento defensivo de falhas de leitura de preferências no painel.
- Versão atualizada para `2.1.0-rc2` para ambos os aplicativos.
