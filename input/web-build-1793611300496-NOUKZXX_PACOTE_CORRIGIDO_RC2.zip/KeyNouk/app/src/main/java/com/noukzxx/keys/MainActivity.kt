package com.noukzxx.keys

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec

/** Standalone local license issuer. The signing key never leaves Android Keystore. */
class MainActivity : Activity() {
    companion object {
        private const val SIGNING_ALIAS = "noukzxx_offline_issuer_ec_v2"
        private const val HISTORY_KEY = "signed_license_history_v2"
        private const val MAX_HISTORY = 60
    }
    private lateinit var web: WebView
    private val preferences by lazy { getSharedPreferences("nouk_issuer_v2", MODE_PRIVATE) }
    private val random = SecureRandom()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 7, 8)
        window.navigationBarColor = Color.rgb(7, 7, 8)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 7, 8))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowContentAccess = false
            settings.allowFileAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = object: WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                    url?.startsWith("file:///android_asset/") != true
            }
            addJavascriptInterface(LicenseBridge(), "Nouk")
            loadUrl("file:///android_asset/key.html")
        }
        setContentView(web)
    }

    private fun encode(bytes: ByteArray): String = Base64.encodeToString(
        bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
    )

    @Synchronized
    private fun signingKey(): java.security.KeyPair {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (store.containsAlias(SIGNING_ALIAS)) {
            val privateKey = store.getKey(SIGNING_ALIAS, null) as java.security.PrivateKey
            val publicKey = store.getCertificate(SIGNING_ALIAS).publicKey
            return java.security.KeyPair(publicKey, privateKey)
        }
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        val params = KeyGenParameterSpec.Builder(
            SIGNING_ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setUserAuthenticationRequired(false)
            .build()
        generator.initialize(params)
        return generator.generateKeyPair()
    }

    private fun historyArray(): JSONArray = try {
        JSONArray(preferences.getString(HISTORY_KEY, "[]") ?: "[]")
    } catch (_: Exception) { JSONArray() }

    @Synchronized
    private fun generateLicense(days: Int): String {
        if (days !in setOf(0,1,7,31)) return JSONObject().put("ok", false).put("error", "Período inválido").toString()
        return try {
            val now = System.currentTimeMillis()
            val expires = if (days == 0) 0L else now + days.toLong()*86_400_000L
            val idBytes = ByteArray(12).also(random::nextBytes)
            val id = encode(idBytes) // 12 bytes -> 16 URL-safe characters
            val payload = JSONObject()
                .put("v", 2)
                .put("id", id)
                .put("iat", now)
                .put("exp", expires)
                .put("days", days)
                .toString().toByteArray(Charsets.UTF_8)
            val signature = Signature.getInstance("SHA256withECDSA").apply {
                initSign(signingKey().private)
                update(payload)
            }.sign()
            val token = "NK2.${encode(payload)}.${encode(signature)}"
            val history = historyArray()
            val entry = JSONObject().put("key",token).put("id",id).put("days",days)
                .put("issued",now).put("expires",expires)
            val refreshed = JSONArray().put(entry)
            for (i in 0 until minOf(history.length(), MAX_HISTORY-1)) refreshed.put(history.get(i))
            preferences.edit().putString(HISTORY_KEY,refreshed.toString()).apply()
            JSONObject().put("ok",true).put("token",token).put("id",id)
                .put("issued",now).put("expires",expires).put("days",days).toString()
        } catch (e: Exception) {
            JSONObject().put("ok",false).put("error",e.message?:"Não foi possível gerar a licença").toString()
        }
    }

    inner class LicenseBridge {
        @JavascriptInterface fun issuer(): String = try {
            "NKPUB.${encode(signingKey().public.encoded)}"
        } catch (e: Exception) { "Erro ao carregar o emissor: ${e.message}" }

        @JavascriptInterface fun generate(days: Int): String = generateLicense(days)
        @JavascriptInterface fun history(): String = historyArray().toString()
        @JavascriptInterface fun clearHistory() {
            preferences.edit().remove(HISTORY_KEY).apply()
        }
        @JavascriptInterface fun copy(value: String) {
            if (value.length > 4096) return
            runOnUiThread {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("KEY NOUK",value))
            }
        }
        @JavascriptInterface fun share(value: String) {
            if (value.length > 4096) return
            runOnUiThread {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT,value)
                }
                startActivity(Intent.createChooser(intent,"Compartilhar licença"))
            }
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("Nouk")
            web.destroy()
        }
        super.onDestroy()
    }
}
