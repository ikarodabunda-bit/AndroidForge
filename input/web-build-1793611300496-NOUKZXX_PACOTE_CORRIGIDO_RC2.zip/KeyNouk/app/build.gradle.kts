plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.noukzxx.keynouk"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.noukzxx.keynouk.cyberred2"
        minSdk = 23
        targetSdk = 32
        versionCode = 3
        versionName = "2.1.0-rc2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
