package com.chargeskinmenu

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val blue = 0xFF18BFFF.toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) createBubble()
        return START_STICKY
    }

    private fun createBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "CH"
            textSize = 16f
            setTextColor(0xFF00131C.toInt())
            setBackgroundColor(blue)
            setOnClickListener { togglePanel() }
        }
        val params = WindowManager.LayoutParams(
            120, 110,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 260 }

        button.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0
            private var downY = 0
            private var startX = 0
            private var startY = 0
            private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt(); downY = event.rawY.toInt()
                        startX = params.x; startY = params.y; moved = false
                        return false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = downX - event.rawX.toInt()
                        val dy = event.rawY.toInt() - downY
                        if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                        if (moved) {
                            params.x = (startX + dx).coerceAtLeast(0)
                            params.y = (startY + dy).coerceAtLeast(0)
                            wm.updateViewLayout(button, params)
                            return true
                        }
                    }
                }
                return false
            }
        })
        bubble = button
        wm.addView(button, params)
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xF0101522.toInt())
        }
        box.addView(TextView(this).apply {
            text = "CHARGE SKIN MENU"
            textSize = 18f
            setTextColor(blue)
        })
        box.addView(TextView(this).apply {
            text = "Catálogo de skins\nRifles • Pistolas • Snipers • Facas\n\nEste painel é demonstrativo; não altera as skins dentro do jogo."
            textSize = 14f
            setTextColor(0xFFE8F5FF.toInt())
            setPadding(0, 12, 0, 12)
        })
        box.addView(Button(this).apply {
            text = "Fechar menu"
            setOnClickListener { togglePanel() }
        })
        val params = WindowManager.LayoutParams(
            700, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        panel = box
        wm.addView(box, params)
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        panel = null
        super.onDestroy()
    }
}
