package com.chargeskinmenu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val blue = 0xFF18BFFF.toInt()
    private val dark = 0xFF10131B.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(dark)
        }

        val title = TextView(this).apply {
            text = "CHARGE SKIN MENU"
            textSize = 25f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Counter Flame • Catálogo de skins"
            textSize = 14f
            setTextColor(0xFFE8F5FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        root.addView(subtitle)

        val notice = TextView(this).apply {
            text = "Este app oferece um catálogo e um menu flutuante. Aplicar skins dentro do jogo depende de suporte oficial ou de uma integração autorizada; este projeto não injeta arquivos nem altera o jogo."
            textSize = 14f
            setTextColor(0xFFB8C5D6.toInt())
            setPadding(0, 0, 0, 18)
        }
        root.addView(notice)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val categories = listOf(
            "RIFLES" to listOf("AK-47 • Charge Blue", "M4A1 • Dragon Pulse", "FAMAS • Neon Storm"),
            "PISTOLAS" to listOf("Deagle • Electric Fang", "Glock • Blue Circuit", "USP • Frostbite"),
            "SNIPERS" to listOf("AWP • Thunder Dragon", "Scout • Arctic Charge"),
            "FACAS" to listOf("Karambit • Blue Flame", "Butterfly • Neon Edge", "Faca tática • Storm")
        )
        categories.forEach { (category, items) ->
            val header = TextView(this).apply {
                text = category
                textSize = 16f
                setTextColor(blue)
                setPadding(0, 12, 0, 6)
            }
            list.addView(header)
            items.forEach { item ->
                val row = TextView(this).apply {
                    text = "◆  $item"
                    textSize = 15f
                    setTextColor(0xFFE8F5FF.toInt())
                    setPadding(14, 13, 14, 13)
                    setBackgroundColor(0xFF1B2230.toInt())
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = 6
                list.addView(row, lp)
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val floatingButton = Button(this).apply {
            text = "ATIVAR MENU FLUTUANTE"
            setTextColor(0xFF00131C.toInt())
            setBackgroundColor(blue)
            setOnClickListener { enableFloatingMenu() }
        }
        root.addView(floatingButton, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun enableFloatingMenu() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        startService(Intent(this, FloatingMenuService::class.java))
        finish()
    }
}
