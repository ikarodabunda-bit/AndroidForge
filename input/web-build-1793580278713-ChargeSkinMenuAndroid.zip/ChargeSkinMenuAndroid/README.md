# Charge Skin Menu (Android)

Projeto inicial em Kotlin para Android Studio. Inclui:
- catálogo demonstrativo de skins para rifles, pistolas, snipers e facas;
- botão flutuante que pode ser movido;
- painel flutuante de demonstração;
- pedido de permissão de sobreposição do Android.

## Como abrir
1. Instale o Android Studio.
2. Extraia o ZIP.
3. No Android Studio, selecione **Open** e escolha a pasta `ChargeSkinMenuAndroid`.
4. Aguarde a sincronização do Gradle.
5. Execute em um dispositivo Android ou emulador.

## Limitação importante
Este é um catálogo e overlay demonstrativo. Ele não injeta skins, não altera memória/arquivos do Counter Flame e não contorna o sistema antitrapaça. Para aplicar skins no jogo, será necessária uma API, modificação ou integração oficialmente suportada pelo jogo.

O Android pode exigir que você autorize “Exibir sobre outros apps” em Configurações. Para encerrar o menu flutuante, force a parada do app nas configurações do Android.
