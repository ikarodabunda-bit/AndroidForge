# SkinLab 5.2 — Overlay Android + galeria de recursos Unity originais

O projeto mantém a estrutura Android/C++17 do SkinLab 5.1 e adiciona `app/src/main/assets/catalogo.html` com 268 imagens de prévia/HUD extraídas **das amostras fornecidas pelo usuário** (não de todo o XAPK). Um novo link na tela principal abre esta galeria.

## Conteúdo verificado
- XAPK do jogo na versão 1.1.0, OBB interno com bundles UnityFS.
- ZIP de 11 arquivos fornecido pelo usuário: 9 bundles UnityFS e dois JSON.
- 424 objetos Texture2D encontrados e seus dados ASTC extraídos sem erros reportados.
- Incluímos 214 texturas `_Preview` e 54 `_HUD` dentro da galeria original.
- Formatos comprimidos ASTC 4x4, 6x6 e 8x8. A renderização depende da extensão `WEBGL_compressed_texture_astc` exposta pelo Android WebView/GPU. Dispositivos não compatíveis mostrarão os nomes reais e um aviso; **não há substituição por imagens inventadas**.

## Como usar
1. Abra a pasta `SkinLab5-Overlay` no Android Studio, configure SDK/NDK/CMake conforme README da versão anterior e compile.
2. Instale o APK gerado, abra e conceda permissão para desenhar sobre outros aplicativos.
3. Inicie o painel pelo aplicativo, toque em **Galeria Original 5.2** para ver os recursos extraídos.
4. Use **Voltar ao painel** para retornar aos comandos da janela flutuante.

## Limitações e segurança
- Não é APK modificado do Standoff 2; não modifica jogos de terceiros nem altera skins em partidas, inventários, propriedade de itens ou dados de servidor.
- A nova galeria não tem conexão com o motor de renderização do Standoff 2; é um catálogo de leitura offline dos recursos.
- A exibição das texturas ASTC pelo WebGL e o overlay no celular exigem validação em hardware real. Nenhum APK foi compilado neste ambiente.
- Os arquivos têm direitos de propriedade intelectual de seus autores; o uso deve respeitar as respectivas licenças.

## Arquivos
- `app/src/main/assets/index.html`: painel SkinLab anterior, com navegação para a galeria original.
- `app/src/main/assets/catalogo.html`: nova galeria original, incluindo as texturas ASTC em base64, autocontida.
- `app/src/main/java/dev/skinforgex/`: integrações Android anteriores, sem alteração de jogos.
- `app/src/main/cpp/`: ponte C++17 local de pré-visualizações.
