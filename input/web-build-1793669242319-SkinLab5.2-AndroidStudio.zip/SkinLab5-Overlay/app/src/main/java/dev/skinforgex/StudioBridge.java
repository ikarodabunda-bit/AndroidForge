package dev.skinforgex;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;

/** Restricted bridge exposed only to packaged, trusted file:///android_asset HTML. */
public final class StudioBridge {
    private final Context context;
    private final OverlayService overlay;
    private static final String PREF="skinlab5_config";
    StudioBridge(Context context, OverlayService overlay) { this.context=context; this.overlay=overlay; }

    @JavascriptInterface public String getStatus() {return GameDetector.statusJson(context);}
    @JavascriptInterface public String nativeSummary() {return NativeCore.summary();}
    @JavascriptInterface public String applyLocalPreview(int itemId) {
        return NativeCore.applyLocalPreview(itemId);
    }
    @JavascriptInterface public String getSavedConfig() {
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("config", "");
    }
    @JavascriptInterface public String saveConfig(String json) {
        if(json==null || json.length()>100000) return "INVALID_SIZE";
        try {
            JSONObject obj=new JSONObject(json);
            if(obj.optJSONObject("saved")==null) return "INVALID_CONFIG";
            context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString("config",obj.toString()).apply();
            return "LOCAL_SAVED";
        } catch(Exception ex) {return "INVALID_JSON";}
    }
    private void dispatch(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    @JavascriptInterface public void openGame() {
        Intent launch=context.getPackageManager().getLaunchIntentForPackage(GameDetector.GAME);
        if(launch!=null) dispatch(launch);
    }
    @JavascriptInterface public void requestUsagePermission() {
        dispatch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
    }
    @JavascriptInterface public void requestOverlayPermission() {
        dispatch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:"+context.getPackageName())));
    }
    @JavascriptInterface public void startOverlay() {
        if(!Settings.canDrawOverlays(context)) {requestOverlayPermission();return;}
        Intent service=new Intent(context,OverlayService.class);
        if(Build.VERSION.SDK_INT>=26) context.startForegroundService(service);
        else context.startService(service);
    }
    @JavascriptInterface public void closeOverlay() {
        if(overlay!=null) overlay.stopSelf();
        else context.stopService(new Intent(context,OverlayService.class));
    }
    @JavascriptInterface public void moveOverlay(int dx,int dy) {
        if(overlay!=null)overlay.moveBy(dx,dy);
    }
    @JavascriptInterface public void minimizeOverlay(boolean tiny) {
        if(overlay!=null)overlay.minimize(tiny);
    }
    @JavascriptInterface public void setOverlaySize(String mode) {
        if(overlay!=null)overlay.setSizeMode("compact".equals(mode));
    }
    @JavascriptInterface public void setOverlayKeyboardEnabled(boolean enabled) {
        if(overlay!=null) overlay.setKeyboardEnabled(enabled);
    }
    @JavascriptInterface public void shareConfig(String content) {
        if(content==null||content.length()>100000)return;
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("application/json");
        share.putExtra(Intent.EXTRA_TEXT,content);
        dispatch(Intent.createChooser(share,"Exportar SkinLab 5.1"));
    }
}
