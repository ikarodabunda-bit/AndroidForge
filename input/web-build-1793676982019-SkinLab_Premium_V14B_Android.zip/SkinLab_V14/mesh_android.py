"""SkinLab V14B - Pure Python conversion of Unity Mesh typetree to Wavefront OBJ.
No native UnityPy MeshHandler; read-only. Unity 2019+/2021 vertex streams.
"""
import struct
import math
import base64

FORMATS = {
    0: ('f', 4),    # Float32
    1: ('e', 2),    # Float16
    2: ('B', 1),    # UNorm8
    3: ('b', 1),    # SNorm8
    4: ('H', 2),    # UNorm16
    5: ('h', 2),    # SNorm16
    6: ('B', 1),    # UInt8
    7: ('b', 1),    # SInt8
    8: ('H', 2),    # UInt16
    9: ('h', 2),    # SInt16
    10: ('I', 4),   # UInt32
    11: ('i', 4),   # SInt32
}

def key(d,*names,default=None):
    for n in names:
        if isinstance(d,dict) and n in d:
            return d[n]
    return default

def as_bytes(v):
    if isinstance(v,(bytes,bytearray,memoryview)):
        return bytes(v)
    if isinstance(v,list):
        return bytes(v)
    if isinstance(v,str):
        try:
            return base64.b64decode(v,validate=True)
        except Exception:
            return v.encode('latin1')
    raise ValueError('Formato de bytes inesperado: '+str(type(v)))

def channel_info(ch):
    return {
      'stream': int(key(ch,'stream','m_Stream','Stream',default=0)),
      'offset': int(key(ch,'offset','m_Offset','Offset',default=0)),
      'format': int(key(ch,'format','m_Format','Format',default=0)),
      'dimension': int(key(ch,'dimension','m_Dimension','Dimension',default=0)) & 15,
    }

def get_channels(tree):
    vd=key(tree,'m_VertexData', 'vertexData')
    if not isinstance(vd,dict):
        raise ValueError('m_VertexData ausente: '+str(list(tree.keys())[:30]))
    n=int(key(vd,'m_VertexCount','vertexCount',default=0))
    ch=[channel_info(q) for q in key(vd,'m_Channels','channels',default=[])]
    data=as_bytes(key(vd,'m_DataSize','dataSize',default=b''))
    if not data:raise ValueError('m_DataSize sem dados; possivel m_StreamData separado')
    if not ch or n<=0:raise ValueError(f'Canais/vertices ausentes: n={n}, canais={len(ch)}')
    # Unity >=5.0 stream data is per stream, aligned at 16-byte boundaries.
    groups={}
    for c in ch:
        if c['dimension'] <= 0:continue
        f=c['format']
        if f not in FORMATS:raise ValueError('Formato desconhecido de vertice: '+str(f))
        size=FORMATS[f][1]
        s=c['stream']
        groups[s]=max(groups.get(s,0),c['offset']+size*c['dimension'])
    starts={};base=0
    for s in range(max(groups)+1):
        if s in groups:
            starts[s]=base
            base+=n*groups[s]
            base=(base+15)&~15
    if base > len(data)+15:
        raise ValueError(f'Dados de vertices incompletos: esperado {base}, recebido {len(data)}')
    return n,ch,data,groups,starts

def get_attribute(n, channels, data, strides, starts, channel_no):
    if channel_no >= len(channels):return None
    c=channels[channel_no]
    dim=c['dimension']
    if dim==0 or c['stream'] not in starts:return None
    fmt=c['format']
    code,size=FORMATS[fmt]
    base=starts[c['stream']]+c['offset'];step=strides[c['stream']]
    res=[]
    for i in range(n):
        off=base+i*step
        if off+dim*size>len(data):
            raise ValueError(f'Canal {channel_no}: fim inesperado dos vertices no indice {i}')
        vals=struct.unpack_from('<'+code*dim,data,off)
        if fmt==2:vals=[v/255. for v in vals]
        elif fmt==3:vals=[max(-1,v/127.) for v in vals]
        elif fmt==4:vals=[v/65535. for v in vals]
        elif fmt==5:vals=[max(-1,v/32767.) for v in vals]
        res.append(tuple(float(v) for v in vals))
    return res

def export_mesh_tree(tree):
    name=str(key(tree,'m_Name',default='AK47'))
    n,ch,data,strides,starts=get_channels(tree)
    pos=get_attribute(n,ch,data,strides,starts,0)
    norms=get_attribute(n,ch,data,strides,starts,1)
    uv=get_attribute(n,ch,data,strides,starts,4)
    if not pos or len(pos[0])<3:raise ValueError('Canal de posicao m_VertexData nao decodificado')
    spans=[max(v[k] for v in pos)-min(v[k] for v in pos) for k in range(3)]
    if not all(math.isfinite(v[k]) for v in pos for k in range(3)) or max(spans)<1e-7:
        raise ValueError('Coordenadas da malha invalidas (vazias/NaN); verificar compressao/streams')
    buf=as_bytes(key(tree,'m_IndexBuffer',default=b''))
    subs=key(tree,'m_SubMeshes',default=[])
    if not subs or not buf:raise ValueError('Indices ou submalhas ausentes')
    indfmt=int(key(tree,'m_IndexFormat',default=0))
    # For older dumps m_IndexFormat might be absent; infer width from submesh range.
    expected=max((int(key(s,'firstByte','m_FirstByte',default=0))+int(key(s,'indexCount','m_IndexCount',default=0))*2) for s in subs)
    if 'm_IndexFormat' not in tree and len(buf)>=expected*2 and len(buf)>=sum(int(key(s,'indexCount',default=0)) for s in subs)*4:
        indfmt=1
    sz=4 if indfmt==1 else 2
    if len(buf)%sz:raise ValueError('m_IndexBuffer com tamanho invalido')
    fmt='<'+('I' if sz==4 else 'H')
    lines=['# SkinLab V14B - Unity Mesh typetree, sem extensao nativa', 'o '+name]
    for p in pos:lines.append('v %.7g %.7g %.7g'%(p[0],p[1],p[2]))
    if uv:
        for p in uv:lines.append('vt %.7g %.7g'%(p[0],p[1]))
    if norms:
        for p in norms:lines.append('vn %.7g %.7g %.7g'%(p[0],p[1],p[2]))
    nf=0
    for sub in subs:
        first=int(key(sub,'firstByte','m_FirstByte',default=0))
        count=int(key(sub,'indexCount','m_IndexCount',default=0))
        basev=int(key(sub,'baseVertex','m_BaseVertex',default=0))
        topology=int(key(sub,'topology','m_Topology',default=0))
        if topology!=0:
            print('AVISO: submalha com topologia',topology,'ainda nao suportada')
            continue
        if first+count*sz>len(buf):raise ValueError('Indices excedem buffer')
        raw_indices=[struct.unpack_from(fmt,buf,first+i*sz)[0]+basev for i in range(count)]
        if raw_indices and max(raw_indices)>=n:raise ValueError(f'Indice de vertice fora do intervalo ({max(raw_indices)}/{n})')
        lines.append('g submesh_'+str(nf))
        for a in range(0,len(raw_indices)-2,3):
            ids=[raw_indices[a]+1,raw_indices[a+1]+1,raw_indices[a+2]+1]
            if len(set(ids))<3:continue
            if uv and norms: f=['%d/%d/%d'%(i,i,i) for i in ids]
            elif uv:f=['%d/%d'%(i,i) for i in ids]
            elif norms:f=['%d//%d'%(i,i) for i in ids]
            else:f=list(map(str,ids))
            lines.append('f '+' '.join(f));nf+=1
    if not nf:raise ValueError('Nenhum triangulo decodificado')
    print(f'PYTHON PURO: {name} | {n} vertices | {nf} triangulos | UV:',bool(uv),'normal:',bool(norms))
    return '\n'.join(lines)+'\n'
