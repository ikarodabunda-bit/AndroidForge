#!/usr/bin/env python3
"""SkinLab V14: exportação LOCAL, somente leitura, da malha AK-47 + 2 texturas.
Requer UnityPy, Pillow e texture2ddecoder no Android/Termux.
Não instala, altera, reempacota ou injeta nada no CounterFlame.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import base64
import json
import math
import re
import sys
import traceback

BASE = Path(__file__).resolve().parent
INPUT = BASE / 'assets'
OUTPUT = Path('/sdcard/Download/SkinLab_V14_Resultado')
if not OUTPUT.parent.is_dir():
    OUTPUT = BASE / 'SkinLab_V14_Resultado'
OUTPUT.mkdir(parents=True, exist_ok=True)

try:
    import UnityPy
    from UnityPy.enums import TextureFormat
    import texture2ddecoder as dec
    from PIL import Image
except ImportError as exc:
    print('DEPENDENCIA AUSENTE:', exc)
    print('No Termux, teste: python -c "import UnityPy, texture2ddecoder; from PIL import Image; print(\'OK\')"')
    print('UnityPy/Pillow ja foram instalados nas etapas anteriores.')
    sys.exit(1)


def export_mesh(path):
    from mesh_android import export_mesh_tree
    env = UnityPy.load(path.read_bytes())
    for obj in env.objects:
        if obj.type.name == 'Mesh':
            # Avoid obj.parse_as_object() and mesh.export() on Android:
            # MeshHandler's native library is unavailable on Android Termux.
            tree = obj.parse_as_dict()
            return export_mesh_tree(tree)
    raise ValueError('Nenhum objeto Mesh encontrado')


def export_texture(src, dest):
    env = UnityPy.load(src.read_bytes())
    for obj in env.objects:
        if obj.type.name != 'Texture2D':
            continue
        tex = obj.parse_as_object()
        fmt = TextureFormat(tex.m_TextureFormat).name
        w, h = tex.m_Width, tex.m_Height
        if 'ASTC' in fmt:
            blk = re.search(r'_(\d+)x(\d+)$', fmt)
            if blk is None:
                raise ValueError('ASTC sem dimensao de bloco: ' + fmt)
            bw, bh = map(int, blk.groups())
            rgba = dec.decode_astc(bytes(tex.get_image_data()), w, h, bw, bh)
            img = Image.frombytes('RGBA', (w, h), rgba, 'raw', 'BGRA')
        else:
            img = tex.image
        img = img.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        img.save(dest, optimize=True)
        print('TEXTURA:', tex.m_Name, f'{w}x{h}', fmt, '->', dest.name)
        return
    raise ValueError('Texture2D nao encontrada em ' + src.name)


def parse_obj(s):
    """OBJ -> buffers otimizados, preservando indices de posicao/UV/normais."""
    positions = []; uvs = []; normals = []
    points = []; faces = []; keys = {}
    def parse_idx(x, length):
        i = int(x)
        return (i-1) if i > 0 else (length+i)
    for line in s.splitlines():
        if line.startswith('v '):
            vals = line.split()
            positions.append([float(v) for v in vals[1:4]])
        elif line.startswith('vt '):
            vals = line.split()
            uvs.append([float(v) for v in vals[1:3]])
        elif line.startswith('vn '):
            vals = line.split()
            normals.append([float(v) for v in vals[1:4]])
        elif line.startswith('f '):
            polygon = []
            for ref in line.split()[1:]:
                parts = ref.split('/')
                vi = parse_idx(parts[0], len(positions))
                ti = parse_idx(parts[1], len(uvs)) if len(parts)>1 and parts[1] else -1
                ni = parse_idx(parts[2], len(normals)) if len(parts)>2 and parts[2] else -1
                key = (vi, ti, ni)
                if key not in keys:
                    x,y,z = positions[vi]
                    u,v = uvs[ti] if ti>=0 else (0,0)
                    nx,ny,nz = normals[ni] if ni>=0 else (0,0,0)
                    keys[key] = len(points)
                    points.append([x,y,z,u,v,nx,ny,nz])
                polygon.append(keys[key])
            for i in range(1, len(polygon)-1):
                faces.extend([polygon[0],polygon[i],polygon[i+1]])
    if not positions or not faces:
        raise ValueError(f'OBJ sem geometria: vertices={len(positions)}, indices={len(faces)}')
    xs = [p[0] for p in points];ys=[p[1] for p in points];zs=[p[2] for p in points]
    mn=[min(xs),min(ys),min(zs)];mx=[max(xs),max(ys),max(zs)]
    mid = [(a+b)/2 for a,b in zip(mn,mx)]
    span = max(mx[i]-mn[i] for i in range(3)) or 1
    scale = 2.55/span
    for p in points:
        for i in range(3):p[i]=(p[i]-mid[i])*scale
        if (p[5]**2+p[6]**2+p[7]**2) < .0001:
            p[5],p[6],p[7]=0,0,1
    if not uvs:
        print('AVISO: OBJ sem coordenadas UV; textura pode ficar uniforme')
    return {
        'label':'AK-47 REFERENCE DROP', 'verticesCount':len(points),
        'sourceVertexCount':len(positions),
        'indices':faces,
        'interleaved':[round(v,5) for p in points for v in p]
    }


def make_mtl(name,png):
    return f'newmtl {name}\nKa 0.7 0.7 0.7\nKd 1 1 1\nKs 0.12 0.12 0.12\nNs 40\nmap_Kd {png}\n'


def write_obj_variant(original, label, image):
    cleaned=[]
    for ln in original.splitlines():
        if ln.startswith('mtllib ') or ln.startswith('usemtl '): continue
        cleaned.append(ln)
    output = 'mtllib AK47_'+label+'.mtl\nusemtl AK47_'+label+'\n' + '\n'.join(cleaned)+'\n'
    (OUTPUT/f'AK47_{label}.obj').write_text(output, encoding='utf-8', newline='')
    (OUTPUT/f'AK47_{label}.mtl').write_text(make_mtl('AK47_'+label,image), encoding='utf-8')


def main():
    required = ['AK47_MESH.unity','ASIIMOV.bundle','AQUAMARINE.bundle']
    for fn in required:
        if not (INPUT/fn).is_file():
            print('ARQUIVO AUSENTE:', INPUT/fn)
            return 1
    print('SKINLAB V14B - EXPORTACAO 3D ANDROID (SEM MODIFICAR O JOGO)')
    mesh_obj = export_mesh(INPUT/'AK47_MESH.unity')
    geometry = parse_obj(mesh_obj)
    print('OBJ:',geometry['sourceVertexCount'],'vertices originais,', len(geometry['indices'])//3,'triangulos,', geometry['verticesCount'],'vertices de renderizacao')
    image_map = {'asiimov':('ASIIMOV.bundle','AK47_Asiimov.png'), 'aquamarine':('AQUAMARINE.bundle','AK47_Aquamarine.png')}
    for key,(src,fn) in image_map.items():
        export_texture(INPUT/src, OUTPUT/fn)
        label='Asiimov' if key=='asiimov' else 'Aquamarine'
        write_obj_variant(mesh_obj,label,fn)
    geometry['textures'] = {
        name:'data:image/png;base64,'+base64.b64encode((OUTPUT/file_name).read_bytes()).decode('ascii')
        for name,(_src,file_name) in image_map.items()
    }
    template=(BASE/'viewer_template.html').read_text('utf-8')
    assert template.count('__PAYLOAD__')==1
    html=template.replace('__PAYLOAD__',json.dumps(geometry,separators=(',',':'),ensure_ascii=False))
    html_path=OUTPUT/'SkinLab_AK47_Preview_3D.html'
    html_path.write_text(html,encoding='utf-8')
    report='\n'.join([
        'SKINLAB V14B - TESTE DE PREVIA 3D LOCAL',
        'Malha: v_rif_ak47_reference_drop',
        f'Vertices de origem: {geometry["sourceVertexCount"]}',
        f'Vertices renderizados: {geometry["verticesCount"]}',
        f'Triangulos: {len(geometry["indices"])//3}',
        'Texturas: AK47_Asiimov.png e AK47_Aquamarine.png',
        'Exportacao: OBJ, MTL, HTML offline',
        'Sem alteracao no APK do CounterFlame',
        'AVISO: UV/shaders podem diferir da cena real do jogo; modelos extras nao incluidos.',
        'AVISO: escolher a skin no visualizador NAO equipa a skin durante a partida.'
    ])
    (OUTPUT/'SkinLab_V14_Relatorio.txt').write_text(report,encoding='utf-8')
    pkg=Path('/sdcard/Download/SkinLab_AK47_Previa_3D_V14.zip')
    if not pkg.parent.is_dir():pkg=BASE/'SkinLab_AK47_Previa_3D_V14.zip'
    with ZipFile(pkg,'w',ZIP_DEFLATED,compresslevel=5) as out:
        for f in sorted(OUTPUT.iterdir()):
            if f.is_file():out.write(f,f.name)
    print('\nCONCLUIDO:', html_path)
    print('ZIP:',pkg)
    print('ABRA O HTML NO CHROME. Esta e uma previa 3D local.')
    return 0

if __name__=='__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print('ERRO:', type(e).__name__, str(e))
        traceback.print_exc(limit=2)
        sys.exit(1)
