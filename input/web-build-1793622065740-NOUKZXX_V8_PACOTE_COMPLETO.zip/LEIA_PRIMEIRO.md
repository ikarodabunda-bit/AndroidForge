# CHARGESKIN CYBER RED v8 + KEY NOUK v8

## Resultado funcional

- ChargeSkin Skin Changer Lab: **substitui realmente a aparência visual dos materiais 3D próprios do app**, com 6 acabamentos e 296 skins no catálogo. Os modelos 3D são **procedurais ilustrativos**, não malhas originais do Counter Flame. As 93 miniaturas são referências extraídas das capturas do usuário.
- Inspetor 3D: toque/arraste para girar, gesto de pinça/slider para zoom e simulação de primeira pessoa. WebGL local + fallback 2D.
- KEY NOUK: assinatura ECDSA SHA256 em chave privada no Android Keystore, com validades de 1, 7, 31 dias e permanente. O ChargeSkin valida usando a chave pública pareada.
- No Android, o laboratório só é liberado com uma licença válida; a escolha de skin e o acabamento também são guardados por verificações nativas. A interface verifica vencimento periodicamente.
- **Não altera o Counter Flame, não equipa skins na conta e não burla o anti-cheat**. Este laboratório é um app independente. A sobreposição opcional é catálogo visual.

## Como compilar (AndroidForge)

1. Importe **CHARGESKIN_CYBER_RED_V8_ANDROIDFORGE.zip** sozinho (projeto Gradle na raiz).
2. Compile no AndroidForge e instale o APK.
3. Depois importe **KEY_NOUK_V8_ANDROIDFORGE.zip** sozinho, compile e instale.
4. No KEY NOUK abra Emissor e toque em **PAREAR NO CHARGESKIN**. Confirme.
5. Emita a licença de teste de 1 dia, toque em **ATIVAR NO CHARGESKIN** e confirme.
6. No ChargeSkin abra o laboratório e selecione uma skin. Altere acabamento, toque EQUIPAR NO LABORATÓRIO e gire o modelo.

Os app IDs foram mantidos **separados**: `com.noukzxx.chargeskin.red.standalone26` e `com.noukzxx.keynouk.issuer.standalone26`.

## Segurança e limites

As licenças são offline e dependem da hora do dispositivo, sem revogação remota. Parear um emissor significa confiar no KEY NOUK local selecionado. Para vendas online, usar emissão em servidor e defesa contra alterações de relógio.

## Testes

Foram realizados verificação estática, parsers JS e XML, integridade dos ZIPs e teste em navegador quando disponível. **Não há Android SDK/Gradle neste ambiente; APKs precisam de compilação e testes reais no aparelho.**
