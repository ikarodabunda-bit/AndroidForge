Key Nouk — projeto Android Kotlin para AndroidIDE.

Importe a pasta no AndroidIDE e compile o app. Gere uma KEY e cole no ChargeSkin Cyber Purple v3. Este é um protótipo de teste; o segredo compartilhado no aplicativo não oferece proteção forte para distribuição pública.
