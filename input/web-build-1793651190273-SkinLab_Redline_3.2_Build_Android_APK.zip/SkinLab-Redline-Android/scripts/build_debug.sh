#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -x ./gradlew ]]; then
  ./gradlew assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  echo 'Gradle ausente. Abra a pasta no Android Studio; instale Gradle 8.9 e gere o wrapper (gradle wrapper --gradle-version 8.9).'
  exit 1
fi
printf '\nAPK esperado: app/build/outputs/apk/debug/app-debug.apk\n'
