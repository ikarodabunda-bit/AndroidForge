# SKINLAB REDLINE 3.2 — Android + C++17

Projeto Android Studio de um **painel externo de personalização visual**, vermelho/preto, com catálogo de 85 registros visíveis nas capturas do mercado, mais opções conceituais, edição de parâmetros, presets, descoberta do CounterFlame e bolha flutuante.

## CounterFlame 1.4-c6 — referência do pacote compartilhado

- Release oficial consultada: `https://github.com/Scratchhhh/counterflame-releases/releases/tag/v1.4-c6` (publicada em 02/11/2026).
- Android 8.0+, arquivo APK anunciado com ~1,84 GB.
- SHA-256 anunciado pela release: `9cedfd40aba3b5b1fb57144e8ce1db1116a5f96b86fb79e89f00d1ab0097cd64`.
- O binário de 1,84 GB **não foi acessível neste ambiente**. Nada neste projeto é derivado de engenharia reversa dos binários dessa versão.
- O painel pode agora analisar **no próprio celular** a instalação visível do CounterFlame: nome do pacote, versão real instalada, arquivos APK/splits, nomes de bibliotecas ELF e algumas referências de assets. Também pode calcular **SHA-256 do APK base** em uma thread dedicada e comparar com o checksum anunciado (uma instalação dividida ou recompilada pode divergir).
- Os resultados da análise do APK são diagnósticos, não offsets, IDs validados ou skins aplicadas.

## O que funciona no protótipo

- Motor **C++17 via JNI** que fornece registros de armas/skins extraídos visualmente de 10 capturas do usuário, com opções conceituais adicionais e valida IDs aceitos nos perfis.
- UI offline em `WebView`, com pesquisa, filtros (rifles, pistolas, AWP, facas, luvas e favoritos), seleção e imagens recortadas das capturas fornecidas (além de ilustrações vetoriais identificadas como conceitos).
- Editor: *wear/float*, *seed/pattern*, nome, contador StatTrak visual, 4 adesivos decorativos e intensidade do brilho. Os valores alteram a prévia local e são salvos.
- Perfis persistidos em `SharedPreferences`, até seis presets (criar/carregar/atualizar/excluir), exportação compartilhável de JSON pelo Android.
- Descoberta do app instalado pelo rótulo/nome do pacote via `PackageManager` (sem adivinhar identificador); leitura de primeiro plano via `UsageStatsManager` com permissão fornecida pelo usuário.
- Serviço foreground que exibe bolha arrastável `SYSTEM_ALERT_WINDOW`; toque abre o painel flutuante em cima de outros apps, e `—` minimiza.
- Botões de abrir CounterFlame, atualizar o diagnóstico, conceder permissões e inspecionar **nomes de arquivos** relevantes dentro do APK instalado (se legíveis), incluindo APKs divididos, bibliotecas e indicadores de motor; conferir SHA-256 da instalação local sem congelar a interface.

## Limitações importantes

Este build **não troca skins dentro do CounterFlame**. A interface de integração para escrita no jogo não existe neste projeto. "Detectado" significa app identificado em primeiro plano; **não** significa acesso à memória do processo. A inspeção de APK não produz *dumps*, *offsets* nem endereços de memória. Os recortes das imagens foram feitos a partir das **capturas de tela fornecidas pelo usuário**, não dos arquivos/recursos originais do APK. Algumas opções adicionais são ilustrações originais; o catálogo não prova que um item está no inventário do usuário.

No Android comum, cada aplicativo é isolado pelo sandbox do sistema. Não há API pública que permita mudar inventário ou renderização de outro aplicativo. O argumento `-insecure` é conhecido no ecossistema de Counter-Strike no PC, porém seu suporte em CounterFlame mobile **não foi confirmado**. O CounterFlame também informa possuir anticheat. Não trate uma partida treino como garantia de segurança contra banimento.

## Requisitos

- Android Studio com **JDK 17**, **SDK API 35**, **NDK** e **CMake 3.22.1** (instaláveis em *SDK Manager*).
- **Gradle 8.9** para o plugin Android Gradle **8.7.3**.
- Android 8.0+ (API 26); as restrições e permissões de overlays variam conforme a versão do Android.

> O ZIP contém o projeto-fonte, não um APK compilado. Este ambiente não possui Android SDK/Gradle, então o build em dispositivo ainda não foi validado.

## Compilação

1. Extraia o ZIP e abra `SkinLab-Redline-Android` como projeto no Android Studio.
2. Instale o SDK 35, NDK e CMake indicados. A pasta é entregue **sem o Gradle Wrapper binário** (não disponível aqui). Se necessário, instale Gradle 8.9 e rode `gradle wrapper --gradle-version 8.9` na raiz, ou configure o Gradle local no Android Studio.
3. Sincronize o Gradle e execute **Build > Build APK(s)**, ou `./gradlew assembleDebug` depois de gerar o wrapper.
4. Localize `app/build/outputs/apk/debug/app-debug.apk`; instale no seu Android.

## Operação

1. Abra o SkinLab. Explore a biblioteca, selecione um item e modifique o acabamento no editor.
2. Em **Conexão**, ative **acesso ao uso** para que o Android permita saber qual app está em primeiro plano.
3. Autorize **sobreposição**. Use **Abrir bolha**; a bolha `SL` fica arrastável.
4. Use **Abrir jogo** para iniciar o CounterFlame, se encontrado. Com o jogo em primeiro plano, a bolha permanece e o painel mostra `JOGO DETECTADO`.
5. O botão **Ativar prévia** ativa somente a visualização no próprio SkinLab. Em **Conexão**, use **Analisar instalação** e **Verificar SHA-256** para obter um relatório real do APK instalado, sem escrever nele.

### Estrutura

- `app/src/main/cpp/skinlab_core.cpp`: catálogo nativo C++ e validação.
- `app/src/main/java/com/pelican/skinlab/SkinBridge.java`: JNI, status, permissões, persistência e metadados APK.
- `app/src/main/java/com/pelican/skinlab/OverlayService.java`: janela flutuante.
- `app/src/main/java/com/pelican/skinlab/MainActivity.java`: host do painel.
- `app/src/main/assets/`: UI original offline.

## Segurança e privacidade

Sem acesso a internet, sem root obrigatório, sem envio de credenciais, sem instalação de componentes no CounterFlame. As configurações ficam locais. A sobreposição é acionada manualmente e tem notificação do sistema para que possa ser desligada. O código não contém hooks, injeção, leitura ou escrita da memória do jogo.


## Atualização 3.2 — screenshots do mercado

- Integradas **85 posições visuais** presentes nas 10 capturas JPG recebidas (algumas são anúncios repetidos da mesma skin). Elas estão em `app/src/main/assets/images/` e vinculadas ao catálogo nativo `skinlab_core.cpp`.
- Fotos são recortes dos previews dos itens presentes nas capturas, com as etiquetas/nomes transcritos visualmente. Quando o mesmo acabamento apareceu duas vezes, as posições foram preservadas para não perder a correspondência com a imagem.
- Distinção entre opções de origem **MERCADO** e **CONCEITO**. Botões de selecionar/favoritar, filtros, pesquisa, editor e presets preservados. As opções ST do mercado iniciam com a marcação visual de StatTrak habilitada no editor.
- A prévia HTML entregue separadamente incorpora as miniaturas e pode ser aberta sem servidor.
- A imagem de uma skin é uma fotografia de catálogo, **não um arquivo de textura** do jogo. Seleções do SkinLab não afetam o inventário, o renderizador ou os servidores CounterFlame.


## Gerar um APK usando GitHub Actions (inclusive pelo celular)

1. Crie um repositório privado e envie **o conteúdo da pasta** `SkinLab-Redline-Android`, mantendo subpastas e o arquivo `.github/workflows/build-apk.yml`. O ZIP não deve ser enviado como um único arquivo: os fontes precisam estar extraídos na raiz do repositório.
2. No GitHub, abra **Actions** → **Compilar SkinLab Redline APK** → **Run workflow** → **Run workflow**. Se o GitHub solicitar, ative Actions para o repositório.
3. Ao concluir com sucesso, abra o resumo da execução, seção **Artifacts**, e baixe **SkinLab_Redline_3.2_APK**. Extraia o ZIP de artifacts e instale `app-debug.apk` no Android.
4. Caso a compilação falhe, abra a etapa em vermelho e consulte o log do erro.

> **Não há APK pronto neste pacote.** O processo acima é um build automatizado no GitHub com Java 17, SDK Android API 35, NDK, CMake e Gradle 8.9. Não foi possível executar essa compilação no ambiente local; os resultados dependem da execução real no GitHub.

**Segurança:** APK *debug* é assinado com chave de desenvolvimento gerada pela máquina de build. Para distribuição pública, use uma chave de assinatura própria e confira as exigências da plataforma. Este é um painel cosmético e não instala skins no jogo.
