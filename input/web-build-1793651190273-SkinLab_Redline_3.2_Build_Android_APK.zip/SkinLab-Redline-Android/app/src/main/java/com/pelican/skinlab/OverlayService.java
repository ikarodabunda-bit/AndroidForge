package com.pelican.skinlab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class OverlayService extends Service {
    private static OverlayService instance;
    private WindowManager window;
    private TextView bubble;
    private WebView panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean expanded;
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        String channelId = "skinlab-floating";
        NotificationManager mgr = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) mgr.createNotificationChannel(new NotificationChannel(channelId,
                "Painel flutuante SkinLab", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("SkinLab Redline")
                .setContentText("Painel cosmético flutuante ativo")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentIntent(pi).setOngoing(true).build();
        startForeground(17, n);
        window = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("S\nL");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(17f);
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xfff3374b, 0xff98131f});
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(2), 0x66ffffff);
        bubble.setBackground(bg);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        bubbleParams = new WindowManager.LayoutParams(dp(58), dp(58),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float x, y, downX, downY; boolean dragged;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        x = e.getRawX(); y = e.getRawY();
                        downX = bubbleParams.x; downY = bubbleParams.y; dragged = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - x) > dp(7) || Math.abs(e.getRawY() - y) > dp(7)) dragged = true;
                        bubbleParams.x = (int)(downX + e.getRawX() - x);
                        bubbleParams.y = Math.max(dp(24), (int)(downY + e.getRawY() - y));
                        window.updateViewLayout(bubble, bubbleParams); return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragged) togglePanel(); return true;
                }
                return false;
            }
        });
        window.addView(bubble, bubbleParams);
    }
    private void togglePanel() {
        if (expanded) { collapse(); return; }
        int width = Math.min(dp(405), getResources().getDisplayMetrics().widthPixels - dp(20));
        int height = Math.min(dp(760), getResources().getDisplayMetrics().heightPixels - dp(66));
        panel = new WebView(this);
        panel.setBackgroundColor(0xff08090d);
        panel.getSettings().setJavaScriptEnabled(true);
        panel.getSettings().setDomStorageEnabled(true);
        panel.getSettings().setAllowContentAccess(false);
        panel.getSettings().setAllowFileAccess(false);
        panel.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return true; }
        });
        panel.addJavascriptInterface(new SkinBridge(this, true, panel), "AndroidSkinLab");
        panelParams = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = dp(32);
        try {
            window.addView(panel, panelParams);
            panel.loadUrl("file:///android_asset/index.html?overlay=1");
            expanded = true; bubble.setVisibility(View.GONE);
        } catch (Exception e) {
            if (panel != null) { panel.destroy(); panel = null; }
        }
    }
    private void collapse() {
        if (panel != null) {
            try { window.removeView(panel); } catch (Exception ignored) {}
            panel.removeJavascriptInterface("AndroidSkinLab"); panel.destroy(); panel = null;
        }
        expanded = false;
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }
    static void minimizeIfRunning() { if (instance != null) instance.collapse(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        collapse();
        if (bubble != null) { try { window.removeView(bubble); } catch (Exception ignored) {} bubble = null; }
        instance = null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
