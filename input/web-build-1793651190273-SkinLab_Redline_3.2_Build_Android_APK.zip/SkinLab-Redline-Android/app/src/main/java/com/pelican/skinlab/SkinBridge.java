package com.pelican.skinlab;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class SkinBridge {
    static { System.loadLibrary("skinlab"); }
    public static native String nativeCatalog();
    public static native boolean nativeValidItem(String id);
    public static native String nativeEngineInfo();
    private final Context ctx;
    private final boolean inOverlay;
    private final WeakReference<WebView> webHost;
    private final AtomicBoolean inspectionBusy = new AtomicBoolean(false);
    private static final String RELEASE = "v1.4-c6";
    private static final String RELEASE_SHA256 = "9cedfd40aba3b5b1fb57144e8ce1db1116a5f96b86fb79e89f00d1ab0097cd64";
    private final SharedPreferences prefs;
    public SkinBridge(Context context, boolean overlay, WebView host) {
        ctx = context;
        webHost = new WeakReference<>(host);
        inOverlay = overlay;
        prefs = ctx.getSharedPreferences("skinlab-redline", Context.MODE_PRIVATE);
    }
    @JavascriptInterface public String getCatalog() { return nativeCatalog(); }
    @JavascriptInterface public String getEngineInfo() { return nativeEngineInfo(); }
    @JavascriptInterface public boolean validateItem(String id) { return nativeValidItem(id); }
    @JavascriptInterface public boolean isOverlay() { return inOverlay; }
    @JavascriptInterface public String loadProfile() { return prefs.getString("currentProfile", ""); }
    @JavascriptInterface public String loadPresets() { return prefs.getString("presets", "{}"); }
    @JavascriptInterface public boolean saveProfile(String raw) {
        if (raw == null || raw.length() > 250000) return false;
        try {
            JSONObject data = new JSONObject(raw);
            String id = data.optString("selectedId", "ak-47-vulcan");
            if (!nativeValidItem(id)) return false;
            prefs.edit().putString("currentProfile", raw).apply();
            return true;
        } catch (Exception ex) { return false; }
    }
    @JavascriptInterface public boolean savePresets(String raw) {
        if (raw == null || raw.length() > 250000) return false;
        try {
            new JSONObject(raw);
            prefs.edit().putString("presets", raw).apply();
            return true;
        } catch (Exception ex) { return false; }
    }
    @JavascriptInterface public String getGameStatus() {
        JSONObject data = new JSONObject();
        String packageName = discoverPackage();
        boolean usage = hasUsageAccess();
        boolean overlay = Settings.canDrawOverlays(ctx);
        try {
            data.put("installed", packageName != null);
            data.put("packageName", packageName == null ? "" : packageName);
            data.put("usageAccess", usage);
            data.put("overlayPermission", overlay);
            data.put("visible", packageName != null && usage && isForeground(packageName));
            if (packageName != null) {
                PackageInfo version = ctx.getPackageManager().getPackageInfo(packageName, 0);
                data.put("versionName", version.versionName == null ? "" : version.versionName);
                data.put("versionCode", Build.VERSION.SDK_INT >= 28 ? version.getLongVersionCode() : version.versionCode);
            }
            data.put("referenceRelease", RELEASE);
            data.put("mode", "local-preview");
            data.put("injectionAvailable", false);
        } catch (Exception ignored) {}
        return data.toString();
    }
    private String discoverPackage() {
        PackageManager pm = ctx.getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        try {
            for (android.content.pm.ResolveInfo i : pm.queryIntentActivities(query, 0)) {
                if (i.activityInfo == null) continue;
                String pkg = i.activityInfo.packageName;
                String label = String.valueOf(i.loadLabel(pm));
                if (matches(pkg) || matches(label)) return pkg;
            }
            // Android package visibility may restrict results; never fabricate a package.
        } catch (Exception ignored) {}
        return null;
    }
    private boolean matches(String input) {
        String s = input.toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "").replace("-", "");
        return s.contains("counterflame");
    }
    private boolean hasUsageAccess() {
        AppOpsManager op = (AppOpsManager)ctx.getSystemService(Context.APP_OPS_SERVICE);
        if (op == null) return false;
        return op.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName())
                == AppOpsManager.MODE_ALLOWED;
    }
    private boolean isForeground(String pkg) {
        try {
            UsageStatsManager usage = (UsageStatsManager) ctx.getSystemService(Context.USAGE_STATS_SERVICE);
            if (usage == null) return false;
            long now = System.currentTimeMillis();
            UsageEvents events = usage.queryEvents(now - 120000, now);
            UsageEvents.Event ev = new UsageEvents.Event();
            String lastPkg = "";
            long lastTime = 0;
            while (events.hasNextEvent()) {
                events.getNextEvent(ev);
                if (ev.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                        (Build.VERSION.SDK_INT >= 29 && ev.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED)) {
                    lastPkg = ev.getPackageName();
                    lastTime = ev.getTimeStamp();
                }
            }
            return pkg.equals(lastPkg) && now - lastTime < 120000;
        } catch (Exception e) { return false; }
    }
    private void runUi(Runnable r) {
        if (ctx instanceof Activity) ((Activity)ctx).runOnUiThread(r);
        else new android.os.Handler(android.os.Looper.getMainLooper()).post(r);
    }
    @JavascriptInterface public void requestUsageAccess() {
        runUi(() -> { Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); });
    }
    @JavascriptInterface public void requestOverlayPermission() {
        runUi(() -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        });
    }
    @JavascriptInterface public void showOverlay() {
        runUi(() -> {
            if (!Settings.canDrawOverlays(ctx)) {
                requestOverlayPermission();
                return;
            }
            try {
                Intent i = new Intent(ctx, OverlayService.class);
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
                else ctx.startService(i);
                toast("Bolha flutuante ativada");
            } catch (Exception e) { toast("Não foi possível iniciar: " + e.getClass().getSimpleName()); }
        });
    }
    @JavascriptInterface public void hideOverlay() {
        runUi(() -> ctx.stopService(new Intent(ctx, OverlayService.class)));
    }
    @JavascriptInterface public void minimizeOverlay() {
        runUi(() -> OverlayService.minimizeIfRunning());
    }
    @JavascriptInterface public void openGame() {
        runUi(() -> {
            String pkg = discoverPackage();
            Intent launch = pkg == null ? null : ctx.getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) { toast("CounterFlame não encontrado entre os apps disponíveis"); return; }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(launch);
        });
    }
    @JavascriptInterface public void shareProfile(String raw) {
        if (raw == null || raw.length() > 250000) return;
        runUi(() -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TEXT, raw);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(Intent.createChooser(i, "Compartilhar configuração SkinLab").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        });
    }
    // Run APK inspection and optional SHA-256 verification off the WebView bridge thread.
    // The installed game's files are opened read-only; we never alter its package or memory.
    @JavascriptInterface public void inspectGameApk() { startInspection(false); }
    @JavascriptInterface public void verifyInstalledApkSha256() { startInspection(true); }
    private void startInspection(boolean hash) {
        final String task = hash ? "hash" : "scan";
        if (!inspectionBusy.compareAndSet(false, true)) {
            JSONObject busy = new JSONObject();
            try { busy.put("task", task).put("ok", false).put("error", "Outra inspeção está em andamento."); }
            catch (Exception ignored) {}
            reportInspection(busy);
            return;
        }
        Thread worker = new Thread(() -> {
            JSONObject data = new JSONObject();
            try {
                data.put("task", task);
                data.put("referenceRelease", RELEASE);
                String pkg = discoverPackage();
                if (pkg == null) throw new IllegalStateException("CounterFlame não detectado. Abra o jogo pelo launcher e tente novamente.");
                PackageManager pm = ctx.getPackageManager();
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                PackageInfo pack = pm.getPackageInfo(pkg, 0);
                data.put("packageName", pkg);
                data.put("versionName", pack.versionName == null ? "" : pack.versionName);
                data.put("versionCode", Build.VERSION.SDK_INT >= 28 ? pack.getLongVersionCode() : pack.versionCode);
                if (hash) {
                    File base = new File(info.sourceDir);
                    if (!base.isFile()) throw new IllegalStateException("APK base não está acessível para leitura.");
                    String actual = sha256(base);
                    data.put("sizeBytes", base.length());
                    data.put("expected", RELEASE_SHA256);
                    data.put("actual", actual);
                    data.put("match", RELEASE_SHA256.equalsIgnoreCase(actual));
                    data.put("note", "Compara somente o APK base instalado ao arquivo anunciado na release; versões, pacotes divididos e recompilações podem divergir.");
                } else {
                    JSONArray paths = new JSONArray();
                    JSONArray libraries = new JSONArray();
                    JSONArray apks = new JSONArray();
                    int scanned = 0, matched = 0;
                    boolean unity = false, il2cpp = false, unreal = false;
                    java.util.ArrayList<String> sourceDirs = new java.util.ArrayList<>();
                    sourceDirs.add(info.sourceDir);
                    if (info.splitSourceDirs != null) for (String split : info.splitSourceDirs) sourceDirs.add(split);
                    for (String dir : sourceDirs) {
                        if (dir == null) continue;
                        File apk = new File(dir);
                        JSONObject apkInfo = new JSONObject();
                        apkInfo.put("name", apk.getName()).put("bytes", apk.length());
                        apks.put(apkInfo);
                        try (ZipFile zip = new ZipFile(apk)) {
                            Enumeration<? extends ZipEntry> entries = zip.entries();
                            int examinedHere = 0;
                            while (entries.hasMoreElements() && examinedHere < 160000) {
                                ZipEntry entry = entries.nextElement();
                                examinedHere++; scanned++;
                                String entryName = entry.getName();
                                String lower = entryName.toLowerCase(Locale.ROOT);
                                if (lower.contains("skin") || lower.contains("weapon") ||
                                    lower.contains("knife") || lower.contains("cosmetic") ||
                                    lower.contains("glove") || lower.contains("paintkit")) {
                                    matched++;
                                    if (paths.length() < 50) paths.put(entryName);
                                }
                                if (lower.startsWith("lib/") && lower.endsWith(".so") && libraries.length() < 35)
                                    libraries.put(entryName);
                                if (lower.endsWith("libunity.so") || lower.startsWith("assets/bin/data/")) unity = true;
                                if (lower.endsWith("libil2cpp.so")) il2cpp = true;
                                if (lower.endsWith("libue4.so") || lower.endsWith("libunreal.so")) unreal = true;
                            }
                        }
                    }
                    data.put("apks", apks).put("scanned", scanned).put("matched", matched)
                        .put("paths", paths).put("libraries", libraries);
                    data.put("engineHints", unity ? (il2cpp ? "Unity / IL2CPP (indícios)" : "Unity (indícios)") :
                                           unreal ? "Unreal (indícios)" : "Não identificado pelos nomes das entradas");
                    data.put("note", "Somente nomes de entradas e metadados. Não comprova skins disponíveis, offsets ou interface de modificação.");
                }
                data.put("ok", true);
            } catch (Exception ex) {
                try { data.put("ok", false).put("error", ex.getClass().getSimpleName() + ": " + ex.getMessage()); }
                catch (Exception ignored) {}
            } finally {
                inspectionBusy.set(false);
                reportInspection(data);
            }
        }, hash ? "skinlab-sha256" : "skinlab-apk-inspection");
        worker.start();
    }
    private static String sha256(File file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream is = new FileInputStream(file)) {
            int read;
            while ((read = is.read(buffer)) != -1) md.update(buffer, 0, read);
        }
        StringBuilder result = new StringBuilder(64);
        for (byte b : md.digest()) result.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return result.toString();
    }
    private void reportInspection(JSONObject data) {
        WebView host = webHost.get();
        if (host == null) return;
        host.post(() -> host.evaluateJavascript("window.skinlabInspectionResult(" + data.toString() + ")", null));
    }
    private void toast(String m) { Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show(); }
}
