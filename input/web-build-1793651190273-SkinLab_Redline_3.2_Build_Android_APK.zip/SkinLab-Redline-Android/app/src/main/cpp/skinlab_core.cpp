#include <jni.h>
#include <string>
#include <algorithm>
#include <iterator>
// Native offline catalog. These labels were transcribed from user-provided market screenshots.
// The core never reads or writes CounterFlame memory.
namespace {
static const char* ids[] = {
    "ak-47-vulcan",
    "ak-47-gold-arabesque",
    "ak-47-neon-revolution-st",
    "ak-47-neon-revolution",
    "ak-47-aquamarine-st",
    "ak-47-fire-serpent-st",
    "ak-47-wild-lotus",
    "ak-47-fuel-injector-st",
    "ak-47-aquamarine",
    "ak-47-empress",
    "ak-47-empress-2",
    "ak-47-colony-eradicator",
    "m4a4-the-emperor-st",
    "m4a4-howl-st",
    "m4a4-howl",
    "m4a4-eye-of-horus",
    "m4a4-the-emperor",
    "m4a4-neo-noir-st",
    "m4a4-dragon-king-st",
    "m4a4-industry",
    "m4a4-neo-noir",
    "m4a4-dragon-king",
    "m4a4-temukau-st",
    "m4a4-poseidon-st",
    "m4a1-s-chantico-s-fire",
    "m4a1-s-decimator-st",
    "m4a1-s-next-technology-st",
    "m4a1-s-printstream-st",
    "m4a1-s-decimator",
    "m4a1-s-next-technology",
    "m4a1-s-printstream",
    "m4a1-s-hot-rod-st",
    "m4a1-s-nightmare",
    "m4a1-s-hot-rod",
    "m4a1-s-master-piece-st",
    "m4a1-s-briefing-st",
    "desert-eagle-code-red",
    "desert-eagle-code-red-st",
    "usp-s-kill-confirmed",
    "desert-eagle-printstream",
    "desert-eagle-blaze-st",
    "desert-eagle-ocean-drive-st",
    "usp-s-flashback-st",
    "desert-eagle-blaze",
    "desert-eagle-sandstorm",
    "desert-eagle-ocean-drive",
    "usp-s-printstream-st",
    "usp-s-cortex-st",
    "karambit-bright-water",
    "karambit-freehand",
    "karambit-gamma-doppler",
    "karambit-fade",
    "karambit-black-laminate",
    "butterfly-knife-emerald",
    "butterfly-knife-marble-fade",
    "karambit-lore",
    "karambit-crimson-web",
    "karambit-tiger-tooth",
    "talon-knife-marble-fade",
    "skeleton-knife-fade",
    "m9-bayonet-autotronic",
    "m9-bayonet-flame-tester",
    "m9-bayonet-lore",
    "m9-bayonet-black-laminate",
    "m9-bayonet-doppler",
    "m9-bayonet-bright-water",
    "m9-bayonet-sapphire",
    "m9-bayonet-freehand",
    "m9-bayonet-gamma-doppler",
    "butterfly-knife-lore",
    "butterfly-knife-crimson-web",
    "butterfly-knife-marble-fade-2",
    "butterfly-knife-emerald-2",
    "stiletto-knife-ultraviolet",
    "stiletto-knife-tiger-tooth",
    "flip-knife-autotronic",
    "flip-knife-fade",
    "flip-knife-ultraviolet",
    "flip-knife-gamma-doppler",
    "flip-knife-black-laminate",
    "flip-knife-bright-water",
    "flip-knife-lore",
    "flip-knife-fade-st",
    "flip-knife-freehand",
    "kukri-knife-vanilla",
    "concept-ak-47-neon-rider",
    "concept-ak-47-bloodsport",
    "concept-ak-47-redline",
    "concept-m4a1-s-hyper-beast",
    "concept-m4a4-asiimov",
    "concept-awp-dragon-lore",
    "concept-awp-asiimov",
    "concept-awp-medusa",
    "concept-awp-hyper-beast",
    "concept-glock-18-fade",
    "concept-glock-18-water-elemental",
    "concept-karambit-doppler",
    "concept-butterfly-knife-slaughter",
    "concept-sport-gloves-pandora-s-box",
    "concept-sport-gloves-vice",
    "concept-specialist-gloves-crimson-kimono",
};
static const char* catalogJson = R"skin([{"id":"ak-47-vulcan","weapon":"AK-47","category":"Rifles","skin":"Vulcan","rarity":"Covert","stattrak":false,"asset":"images/ak-47-vulcan.webp","source":"screenshot"},{"id":"ak-47-gold-arabesque","weapon":"AK-47","category":"Rifles","skin":"Gold Arabesque","rarity":"Covert","stattrak":false,"asset":"images/ak-47-gold-arabesque.webp","source":"screenshot"},{"id":"ak-47-neon-revolution-st","weapon":"AK-47","category":"Rifles","skin":"Neon Revolution","rarity":"Covert","stattrak":true,"asset":"images/ak-47-neon-revolution-st.webp","source":"screenshot"},{"id":"ak-47-neon-revolution","weapon":"AK-47","category":"Rifles","skin":"Neon Revolution","rarity":"Covert","stattrak":false,"asset":"images/ak-47-neon-revolution.webp","source":"screenshot"},{"id":"ak-47-aquamarine-st","weapon":"AK-47","category":"Rifles","skin":"Aquamarine","rarity":"Covert","stattrak":true,"asset":"images/ak-47-aquamarine-st.webp","source":"screenshot"},{"id":"ak-47-fire-serpent-st","weapon":"AK-47","category":"Rifles","skin":"Fire Serpent","rarity":"Covert","stattrak":true,"asset":"images/ak-47-fire-serpent-st.webp","source":"screenshot"},{"id":"ak-47-wild-lotus","weapon":"AK-47","category":"Rifles","skin":"Wild Lotus","rarity":"Covert","stattrak":false,"asset":"images/ak-47-wild-lotus.webp","source":"screenshot"},{"id":"ak-47-fuel-injector-st","weapon":"AK-47","category":"Rifles","skin":"Fuel Injector","rarity":"Covert","stattrak":true,"asset":"images/ak-47-fuel-injector-st.webp","source":"screenshot"},{"id":"ak-47-aquamarine","weapon":"AK-47","category":"Rifles","skin":"Aquamarine","rarity":"Covert","stattrak":false,"asset":"images/ak-47-aquamarine.webp","source":"screenshot"},{"id":"ak-47-empress","weapon":"AK-47","category":"Rifles","skin":"Empress","rarity":"Classified","stattrak":false,"asset":"images/ak-47-empress.webp","source":"screenshot"},{"id":"ak-47-empress-2","weapon":"AK-47","category":"Rifles","skin":"Empress","rarity":"Classified","stattrak":false,"asset":"images/ak-47-empress-2.webp","source":"screenshot"},{"id":"ak-47-colony-eradicator","weapon":"AK-47","category":"Rifles","skin":"Colony Eradicator","rarity":"Classified","stattrak":false,"asset":"images/ak-47-colony-eradicator.webp","source":"screenshot"},{"id":"m4a4-the-emperor-st","weapon":"M4A4","category":"Rifles","skin":"The Emperor","rarity":"Covert","stattrak":true,"asset":"images/m4a4-the-emperor-st.webp","source":"screenshot"},{"id":"m4a4-howl-st","weapon":"M4A4","category":"Rifles","skin":"Howl","rarity":"Contraband","stattrak":true,"asset":"images/m4a4-howl-st.webp","source":"screenshot"},{"id":"m4a4-howl","weapon":"M4A4","category":"Rifles","skin":"Howl","rarity":"Contraband","stattrak":false,"asset":"images/m4a4-howl.webp","source":"screenshot"},{"id":"m4a4-eye-of-horus","weapon":"M4A4","category":"Rifles","skin":"Eye of Horus","rarity":"Covert","stattrak":false,"asset":"images/m4a4-eye-of-horus.webp","source":"screenshot"},{"id":"m4a4-the-emperor","weapon":"M4A4","category":"Rifles","skin":"The Emperor","rarity":"Covert","stattrak":false,"asset":"images/m4a4-the-emperor.webp","source":"screenshot"},{"id":"m4a4-neo-noir-st","weapon":"M4A4","category":"Rifles","skin":"Neo-Noir","rarity":"Covert","stattrak":true,"asset":"images/m4a4-neo-noir-st.webp","source":"screenshot"},{"id":"m4a4-dragon-king-st","weapon":"M4A4","category":"Rifles","skin":"Dragon King","rarity":"Classified","stattrak":true,"asset":"images/m4a4-dragon-king-st.webp","source":"screenshot"},{"id":"m4a4-industry","weapon":"M4A4","category":"Rifles","skin":"Industry","rarity":"Covert","stattrak":false,"asset":"images/m4a4-industry.webp","source":"screenshot"},{"id":"m4a4-neo-noir","weapon":"M4A4","category":"Rifles","skin":"Neo-Noir","rarity":"Covert","stattrak":false,"asset":"images/m4a4-neo-noir.webp","source":"screenshot"},{"id":"m4a4-dragon-king","weapon":"M4A4","category":"Rifles","skin":"Dragon King","rarity":"Classified","stattrak":false,"asset":"images/m4a4-dragon-king.webp","source":"screenshot"},{"id":"m4a4-temukau-st","weapon":"M4A4","category":"Rifles","skin":"Temukau","rarity":"Covert","stattrak":true,"asset":"images/m4a4-temukau-st.webp","source":"screenshot"},{"id":"m4a4-poseidon-st","weapon":"M4A4","category":"Rifles","skin":"Poseidon","rarity":"Covert","stattrak":true,"asset":"images/m4a4-poseidon-st.webp","source":"screenshot"},{"id":"m4a1-s-chantico-s-fire","weapon":"M4A1-S","category":"Rifles","skin":"Chantico's Fire","rarity":"Covert","stattrak":false,"asset":"images/m4a1-s-chantico-s-fire.webp","source":"screenshot"},{"id":"m4a1-s-decimator-st","weapon":"M4A1-S","category":"Rifles","skin":"Decimator","rarity":"Classified","stattrak":true,"asset":"images/m4a1-s-decimator-st.webp","source":"screenshot"},{"id":"m4a1-s-next-technology-st","weapon":"M4A1-S","category":"Rifles","skin":"Next Technology","rarity":"Classified","stattrak":true,"asset":"images/m4a1-s-next-technology-st.webp","source":"screenshot"},{"id":"m4a1-s-printstream-st","weapon":"M4A1-S","category":"Rifles","skin":"Printstream","rarity":"Covert","stattrak":true,"asset":"images/m4a1-s-printstream-st.webp","source":"screenshot"},{"id":"m4a1-s-decimator","weapon":"M4A1-S","category":"Rifles","skin":"Decimator","rarity":"Classified","stattrak":false,"asset":"images/m4a1-s-decimator.webp","source":"screenshot"},{"id":"m4a1-s-next-technology","weapon":"M4A1-S","category":"Rifles","skin":"Next Technology","rarity":"Classified","stattrak":false,"asset":"images/m4a1-s-next-technology.webp","source":"screenshot"},{"id":"m4a1-s-printstream","weapon":"M4A1-S","category":"Rifles","skin":"Printstream","rarity":"Covert","stattrak":false,"asset":"images/m4a1-s-printstream.webp","source":"screenshot"},{"id":"m4a1-s-hot-rod-st","weapon":"M4A1-S","category":"Rifles","skin":"Hot Rod","rarity":"Covert","stattrak":true,"asset":"images/m4a1-s-hot-rod-st.webp","source":"screenshot"},{"id":"m4a1-s-nightmare","weapon":"M4A1-S","category":"Rifles","skin":"Nightmare","rarity":"Classified","stattrak":false,"asset":"images/m4a1-s-nightmare.webp","source":"screenshot"},{"id":"m4a1-s-hot-rod","weapon":"M4A1-S","category":"Rifles","skin":"Hot Rod","rarity":"Covert","stattrak":false,"asset":"images/m4a1-s-hot-rod.webp","source":"screenshot"},{"id":"m4a1-s-master-piece-st","weapon":"M4A1-S","category":"Rifles","skin":"Master Piece","rarity":"Covert","stattrak":true,"asset":"images/m4a1-s-master-piece-st.webp","source":"screenshot"},{"id":"m4a1-s-briefing-st","weapon":"M4A1-S","category":"Rifles","skin":"Briefing","rarity":"Classified","stattrak":true,"asset":"images/m4a1-s-briefing-st.webp","source":"screenshot"},{"id":"desert-eagle-code-red","weapon":"Desert Eagle","category":"Pistols","skin":"Code Red","rarity":"Covert","stattrak":false,"asset":"images/desert-eagle-code-red.webp","source":"screenshot"},{"id":"desert-eagle-code-red-st","weapon":"Desert Eagle","category":"Pistols","skin":"Code Red","rarity":"Covert","stattrak":true,"asset":"images/desert-eagle-code-red-st.webp","source":"screenshot"},{"id":"usp-s-kill-confirmed","weapon":"USP-S","category":"Pistols","skin":"Kill Confirmed","rarity":"Covert","stattrak":false,"asset":"images/usp-s-kill-confirmed.webp","source":"screenshot"},{"id":"desert-eagle-printstream","weapon":"Desert Eagle","category":"Pistols","skin":"Printstream","rarity":"Covert","stattrak":false,"asset":"images/desert-eagle-printstream.webp","source":"screenshot"},{"id":"desert-eagle-blaze-st","weapon":"Desert Eagle","category":"Pistols","skin":"Blaze","rarity":"Covert","stattrak":true,"asset":"images/desert-eagle-blaze-st.webp","source":"screenshot"},{"id":"desert-eagle-ocean-drive-st","weapon":"Desert Eagle","category":"Pistols","skin":"Ocean Drive","rarity":"Covert","stattrak":true,"asset":"images/desert-eagle-ocean-drive-st.webp","source":"screenshot"},{"id":"usp-s-flashback-st","weapon":"USP-S","category":"Pistols","skin":"Flashback","rarity":"Covert","stattrak":true,"asset":"images/usp-s-flashback-st.webp","source":"screenshot"},{"id":"desert-eagle-blaze","weapon":"Desert Eagle","category":"Pistols","skin":"Blaze","rarity":"Covert","stattrak":false,"asset":"images/desert-eagle-blaze.webp","source":"screenshot"},{"id":"desert-eagle-sandstorm","weapon":"Desert Eagle","category":"Pistols","skin":"Sandstorm","rarity":"Covert","stattrak":false,"asset":"images/desert-eagle-sandstorm.webp","source":"screenshot"},{"id":"desert-eagle-ocean-drive","weapon":"Desert Eagle","category":"Pistols","skin":"Ocean Drive","rarity":"Covert","stattrak":false,"asset":"images/desert-eagle-ocean-drive.webp","source":"screenshot"},{"id":"usp-s-printstream-st","weapon":"USP-S","category":"Pistols","skin":"Printstream","rarity":"Covert","stattrak":true,"asset":"images/usp-s-printstream-st.webp","source":"screenshot"},{"id":"usp-s-cortex-st","weapon":"USP-S","category":"Pistols","skin":"Cortex","rarity":"Classified","stattrak":true,"asset":"images/usp-s-cortex-st.webp","source":"screenshot"},{"id":"karambit-bright-water","weapon":"Karambit","category":"Knives","skin":"Bright Water","rarity":"Rare","stattrak":false,"asset":"images/karambit-bright-water.webp","source":"screenshot"},{"id":"karambit-freehand","weapon":"Karambit","category":"Knives","skin":"Freehand","rarity":"Rare","stattrak":false,"asset":"images/karambit-freehand.webp","source":"screenshot"},{"id":"karambit-gamma-doppler","weapon":"Karambit","category":"Knives","skin":"Gamma Doppler","rarity":"Rare","stattrak":false,"asset":"images/karambit-gamma-doppler.webp","source":"screenshot"},{"id":"karambit-fade","weapon":"Karambit","category":"Knives","skin":"Fade","rarity":"Rare","stattrak":false,"asset":"images/karambit-fade.webp","source":"screenshot"},{"id":"karambit-black-laminate","weapon":"Karambit","category":"Knives","skin":"Black Laminate","rarity":"Rare","stattrak":false,"asset":"images/karambit-black-laminate.webp","source":"screenshot"},{"id":"butterfly-knife-emerald","weapon":"Butterfly Knife","category":"Knives","skin":"Emerald","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-emerald.webp","source":"screenshot"},{"id":"butterfly-knife-marble-fade","weapon":"Butterfly Knife","category":"Knives","skin":"Marble Fade","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-marble-fade.webp","source":"screenshot"},{"id":"karambit-lore","weapon":"Karambit","category":"Knives","skin":"Lore","rarity":"Rare","stattrak":false,"asset":"images/karambit-lore.webp","source":"screenshot"},{"id":"karambit-crimson-web","weapon":"Karambit","category":"Knives","skin":"Crimson Web","rarity":"Rare","stattrak":false,"asset":"images/karambit-crimson-web.webp","source":"screenshot"},{"id":"karambit-tiger-tooth","weapon":"Karambit","category":"Knives","skin":"Tiger Tooth","rarity":"Rare","stattrak":false,"asset":"images/karambit-tiger-tooth.webp","source":"screenshot"},{"id":"talon-knife-marble-fade","weapon":"Talon Knife","category":"Knives","skin":"Marble Fade","rarity":"Rare","stattrak":false,"asset":"images/talon-knife-marble-fade.webp","source":"screenshot"},{"id":"skeleton-knife-fade","weapon":"Skeleton Knife","category":"Knives","skin":"Fade","rarity":"Rare","stattrak":false,"asset":"images/skeleton-knife-fade.webp","source":"screenshot"},{"id":"m9-bayonet-autotronic","weapon":"M9 Bayonet","category":"Knives","skin":"Autotronic","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-autotronic.webp","source":"screenshot"},{"id":"m9-bayonet-flame-tester","weapon":"M9 Bayonet","category":"Knives","skin":"Flame Tester","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-flame-tester.webp","source":"screenshot"},{"id":"m9-bayonet-lore","weapon":"M9 Bayonet","category":"Knives","skin":"Lore","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-lore.webp","source":"screenshot"},{"id":"m9-bayonet-black-laminate","weapon":"M9 Bayonet","category":"Knives","skin":"Black Laminate","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-black-laminate.webp","source":"screenshot"},{"id":"m9-bayonet-doppler","weapon":"M9 Bayonet","category":"Knives","skin":"Doppler","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-doppler.webp","source":"screenshot"},{"id":"m9-bayonet-bright-water","weapon":"M9 Bayonet","category":"Knives","skin":"Bright Water","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-bright-water.webp","source":"screenshot"},{"id":"m9-bayonet-sapphire","weapon":"M9 Bayonet","category":"Knives","skin":"Sapphire","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-sapphire.webp","source":"screenshot"},{"id":"m9-bayonet-freehand","weapon":"M9 Bayonet","category":"Knives","skin":"Freehand","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-freehand.webp","source":"screenshot"},{"id":"m9-bayonet-gamma-doppler","weapon":"M9 Bayonet","category":"Knives","skin":"Gamma Doppler","rarity":"Rare","stattrak":false,"asset":"images/m9-bayonet-gamma-doppler.webp","source":"screenshot"},{"id":"butterfly-knife-lore","weapon":"Butterfly Knife","category":"Knives","skin":"Lore","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-lore.webp","source":"screenshot"},{"id":"butterfly-knife-crimson-web","weapon":"Butterfly Knife","category":"Knives","skin":"Crimson Web","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-crimson-web.webp","source":"screenshot"},{"id":"butterfly-knife-marble-fade-2","weapon":"Butterfly Knife","category":"Knives","skin":"Marble Fade","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-marble-fade-2.webp","source":"screenshot"},{"id":"butterfly-knife-emerald-2","weapon":"Butterfly Knife","category":"Knives","skin":"Emerald","rarity":"Rare","stattrak":false,"asset":"images/butterfly-knife-emerald-2.webp","source":"screenshot"},{"id":"stiletto-knife-ultraviolet","weapon":"Stiletto Knife","category":"Knives","skin":"Ultraviolet","rarity":"Rare","stattrak":false,"asset":"images/stiletto-knife-ultraviolet.webp","source":"screenshot"},{"id":"stiletto-knife-tiger-tooth","weapon":"Stiletto Knife","category":"Knives","skin":"Tiger Tooth","rarity":"Rare","stattrak":false,"asset":"images/stiletto-knife-tiger-tooth.webp","source":"screenshot"},{"id":"flip-knife-autotronic","weapon":"Flip Knife","category":"Knives","skin":"Autotronic","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-autotronic.webp","source":"screenshot"},{"id":"flip-knife-fade","weapon":"Flip Knife","category":"Knives","skin":"Fade","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-fade.webp","source":"screenshot"},{"id":"flip-knife-ultraviolet","weapon":"Flip Knife","category":"Knives","skin":"Ultraviolet","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-ultraviolet.webp","source":"screenshot"},{"id":"flip-knife-gamma-doppler","weapon":"Flip Knife","category":"Knives","skin":"Gamma Doppler","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-gamma-doppler.webp","source":"screenshot"},{"id":"flip-knife-black-laminate","weapon":"Flip Knife","category":"Knives","skin":"Black Laminate","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-black-laminate.webp","source":"screenshot"},{"id":"flip-knife-bright-water","weapon":"Flip Knife","category":"Knives","skin":"Bright Water","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-bright-water.webp","source":"screenshot"},{"id":"flip-knife-lore","weapon":"Flip Knife","category":"Knives","skin":"Lore","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-lore.webp","source":"screenshot"},{"id":"flip-knife-fade-st","weapon":"Flip Knife","category":"Knives","skin":"Fade","rarity":"Rare","stattrak":true,"asset":"images/flip-knife-fade-st.webp","source":"screenshot"},{"id":"flip-knife-freehand","weapon":"Flip Knife","category":"Knives","skin":"Freehand","rarity":"Rare","stattrak":false,"asset":"images/flip-knife-freehand.webp","source":"screenshot"},{"id":"kukri-knife-vanilla","weapon":"Kukri Knife","category":"Knives","skin":"Vanilla","rarity":"Rare","stattrak":false,"asset":"images/kukri-knife-vanilla.webp","source":"screenshot"},{"id":"concept-ak-47-neon-rider","weapon":"AK-47","category":"Rifles","skin":"Neon Rider","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-ak-47-bloodsport","weapon":"AK-47","category":"Rifles","skin":"Bloodsport","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-ak-47-redline","weapon":"AK-47","category":"Rifles","skin":"Redline","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-m4a1-s-hyper-beast","weapon":"M4A1-S","category":"Rifles","skin":"Hyper Beast","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-m4a4-asiimov","weapon":"M4A4","category":"Rifles","skin":"Asiimov","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-awp-dragon-lore","weapon":"AWP","category":"Snipers","skin":"Dragon Lore","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-awp-asiimov","weapon":"AWP","category":"Snipers","skin":"Asiimov","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-awp-medusa","weapon":"AWP","category":"Snipers","skin":"Medusa","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-awp-hyper-beast","weapon":"AWP","category":"Snipers","skin":"Hyper Beast","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-glock-18-fade","weapon":"Glock-18","category":"Pistols","skin":"Fade","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-glock-18-water-elemental","weapon":"Glock-18","category":"Pistols","skin":"Water Elemental","rarity":"Covert","stattrak":false,"asset":"","source":"concept"},{"id":"concept-karambit-doppler","weapon":"Karambit","category":"Knives","skin":"Doppler","rarity":"Rare","stattrak":false,"asset":"","source":"concept"},{"id":"concept-butterfly-knife-slaughter","weapon":"Butterfly Knife","category":"Knives","skin":"Slaughter","rarity":"Rare","stattrak":false,"asset":"","source":"concept"},{"id":"concept-sport-gloves-pandora-s-box","weapon":"Sport Gloves","category":"Gloves","skin":"Pandora's Box","rarity":"Rare","stattrak":false,"asset":"","source":"concept"},{"id":"concept-sport-gloves-vice","weapon":"Sport Gloves","category":"Gloves","skin":"Vice","rarity":"Rare","stattrak":false,"asset":"","source":"concept"},{"id":"concept-specialist-gloves-crimson-kimono","weapon":"Specialist Gloves","category":"Gloves","skin":"Crimson Kimono","rarity":"Rare","stattrak":false,"asset":"","source":"concept"}])skin";
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_pelican_skinlab_SkinBridge_nativeCatalog(JNIEnv* e,jclass) {
 return e->NewStringUTF(catalogJson);
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_pelican_skinlab_SkinBridge_nativeValidItem(JNIEnv* e,jclass,jstring s) {
 if (!s) return JNI_FALSE;
 const char* chars=e->GetStringUTFChars(s,nullptr);
 if (!chars) return JNI_FALSE;
 const std::string id(chars);
 e->ReleaseStringUTFChars(s,chars);
 return std::any_of(std::begin(ids),std::end(ids),[&](const char* i){return id==i;}) ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_pelican_skinlab_SkinBridge_nativeEngineInfo(JNIEnv* e,jclass) {
 return e->NewStringUTF("SkinLab Redline 3.2 | C++17 | 85 market captures | Local visual catalog");
}
